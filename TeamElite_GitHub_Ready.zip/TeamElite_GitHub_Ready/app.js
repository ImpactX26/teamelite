const STEPS = [
  {id:'start', short:'Start', title:'Start your Germany journey'},
  {id:'profile', short:'Profile', title:'Build your applicant profile'},
  {id:'evidence', short:'Evidence', title:'Add and verify your evidence'},
  {id:'video', short:'Video', title:'Capture your introduction'},
  {id:'qualification', short:'Qualification', title:'Qualification check'},
  {id:'next', short:'Next step', title:'Recommended next step'},
  {id:'resume', short:'Resume', title:'Evidence-backed resume'},
  {id:'outreach', short:'Educaro', title:'Route through Educaro'},
  {id:'interview', short:'Interview', title:'Company response & interview'}
];
const DEFAULT = {
  current:'start', goal:'', germany:true, profile:{name:'',email:'',phone:'',city:'',availability:'',field:'',occupation:'',education:'',graduation:'',experienceYears:'',experienceRole:''},
  evidence:{documents:[],courses:[],internships:[],projects:[],certifications:[],awards:[],volunteering:[],languages:[],motivation:''},
  video:{uploaded:false,analyzed:false,transcript:'',background:'',motivation:'',careerGoals:''},
  checks:{education:false,experience:false,language:false,documentCompleteness:false,recognition:false,pathwayFit:false},
  qualification:null,resumeApproved:false,outreachSent:false,educaroForwarded:false,interviewOffer:false,notified:false,
  companyReply:'',activity:[]
};
let state = load() || structuredClone(DEFAULT);

function save(){try{localStorage.setItem('eduguide_state',JSON.stringify(state))}catch(e){/* storage unavailable: keep session state in memory */}}
function load(){try{return JSON.parse(localStorage.getItem('eduguide_state')||'null')}catch(e){return null}}
function esc(v){return String(v??'').replace(/[&<>'"]/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#039;','"':'&quot;'}[m]))}
function toast(msg){const t=document.getElementById('toast');t.textContent=msg;t.classList.add('show');setTimeout(()=>t.classList.remove('show'),2800)}
function log(message){state.activity.unshift({message,time:new Date().toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'})});state.activity=state.activity.slice(0,12);save()}
function go(id){state.current=id; save(); render()}
function resetDemo(){if(confirm('Reset the demo and start again?')){state=structuredClone(DEFAULT);save();render();toast('Journey reset')}}
function hasProfile(){const p=state.profile;return state.germany && !!p.name && !!p.email && !!p.field && !!state.goal}
function evidenceCount(){return Object.values(state.evidence).filter(Array.isArray).reduce((n,a)=>n+a.length,0)}
function extraCount(){return state.evidence.courses.length+state.evidence.internships.length+state.evidence.projects.length+state.evidence.certifications.length+state.evidence.awards.length+state.evidence.volunteering.length}
function verifiedExtras(){return ['courses','internships','projects','certifications','awards','volunteering'].reduce((n,k)=>n+state.evidence[k].filter(x=>x.verified).length,0)}
function done(i){ if(i===0) return hasProfile(); if(i===1) return evidenceCount()>0; if(i===2) return state.video.analyzed; if(i===3) return !!state.qualification; if(i===4) return !!state.qualification; if(i===5) return state.resumeApproved; if(i===6) return state.outreachSent; if(i===7) return state.interviewOffer; return false }
function currentIndex(){return STEPS.findIndex(s=>s.id===state.current)}
function unlocked(id){
  const idx=STEPS.findIndex(s=>s.id===id);
  if(idx===0) return true;
  for(let i=0;i<idx;i++){ if(!done(i)) return false; }
  return true;
}
function progress(){return Math.round((STEPS.filter((_,i)=>done(i)).length/STEPS.length)*100)}
function nav(){
  document.getElementById('nav').innerHTML=STEPS.map((s,i)=>`<button class="nav ${state.current===s.id?'active':''} ${done(i)?'done':''} ${unlocked(s.id)?'':'locked'}" onclick="${unlocked(s.id)?`go('${s.id}')`:''}"><span class="step-dot">${done(i)?'✓':i+1}</span><span>${s.short}</span>${unlocked(s.id)?'':'<span class="lock">🔒</span>'}</button>`).join('');
  const p=progress(); document.getElementById('sideProgress').textContent=p+'%';document.getElementById('sideProgressBar').style.width=p+'%';
}
function stepper(){document.getElementById('stepper').innerHTML=STEPS.map((s,i)=>`<div class="step-mini ${state.current===s.id?'active':''} ${done(i)?'done':''}"><div class="n">${String(i+1).padStart(2,'0')}</div><div class="t">${s.short}</div></div>`).join('')}
function header(){const i=currentIndex();document.getElementById('crumb').textContent=`STEP ${i+1} OF ${STEPS.length}`;document.getElementById('topTitle').textContent=STEPS[i].title}
function render(){nav();stepper();header();({start:pageStart,profile:pageProfile,evidence:pageEvidence,video:pageVideo,qualification:pageQualification,next:pageNext,resume:pageResume,outreach:pageOutreach,interview:pageInterview}[state.current]||pageStart)();}

function pageStart(){
 document.getElementById('app').innerHTML=`
 <section class="hero"><div><span class="pill dark">GERMANY ONLY · EVIDENCE-FIRST</span><h1>Build a <em>complete, qualified profile</em> for your Germany journey.</h1><p>Start with your goal, then work through profile, evidence, video, qualification and next-step routing. The system separates verified facts, applicant-provided information and AI-generated summaries.</p><div style="display:flex;gap:8px;margin-top:16px"><button class="btn primary" onclick="go('profile')">Start application →</button><button class="btn secondary" onclick="showHow()">How it works</button></div></div><div class="hero-right"><div class="big-ring"><div><strong>${progress()}%</strong><span>journey complete</span></div></div></div></section>
 <div class="section-head"><div><h2>What happens</h2><p>One guided flow, from applicant intent to interview follow-up.</p></div><span class="pill blue">NO DIRECT COMPANY OUTREACH</span></div>
 <div class="grid3"><div class="card"><span class="pill">01 · PROFILE</span><h3 style="margin-top:12px">Tell us what you want to do in Germany.</h3><p class="small">Study, vocational training or employment. Germany is the only destination in this prototype.</p></div><div class="card"><span class="pill">02 · EVIDENCE</span><h3 style="margin-top:12px">Build an evidence locker.</h3><p class="small">Degrees, certificates, experience letters, language proof, CVs, extra courses, internships and projects.</p></div><div class="card"><span class="pill">03 · ROUTING</span><h3 style="margin-top:12px">Qualification unlocks the right next step.</h3><p class="small">Blocked → resolve gaps. Qualified → resume → Educaro → matched company → interview.</p></div></div>
 <div class="section-head"><div><h2>Current profile snapshot</h2><p>Demo data is editable in the steps.</p></div></div>
 <div class="grid3"><div class="stat"><b>${state.profile.name||'Not entered'}</b><span>Applicant</span></div><div class="stat"><b>${state.goal||'Choose a pathway'}</b><span>Goal</span></div><div class="stat"><b>${evidenceCount()}</b><span>Evidence items</span></div></div>
 <div class="card" style="margin-top:15px"><h3>Journey activity</h3>${activityHTML()}</div>`;
}
function showHow(){toast('The guided sequence is Profile → Evidence → Video → Qualification → Next step → Resume → Educaro → Interview')}

function pageProfile(){
 const p=state.profile;
 document.getElementById('app').innerHTML=`<div class="section-head"><div><span class="pill">STEP 2 · PROFILE</span><h2 style="margin-top:9px">Start with your goal and basic profile.</h2><p>Only Germany is available because this journey is designed specifically for Germany-bound applicants.</p></div></div>
 <div class="grid2"><div class="card"><h3>What are you applying for?</h3><div class="goal-grid">${[['Study','University admission and study pathway.'],['Vocational Training','Vocational / Ausbildung pathway.'],['Employment','Employment and employer matching.']].map(([g,d])=>`<button class="goal ${state.goal===g?'selected':''}" onclick="selectGoal('${g}')"><strong>${g}</strong><span>${d}</span></button>`).join('')}</div><h4>Destination</h4><div class="stat" style="display:flex;align-items:center;gap:10px"><span style="font-size:18px">🇩🇪</span><div><b style="font-size:11px">Germany</b><span>Only destination in this prototype</span></div><span class="pill green" style="margin-left:auto">Selected</span></div><h4>Personal profile</h4><div class="form-grid"><div class="field"><label>Full name</label><input class="input" value="${esc(p.name)}" oninput="setProfile('name',this.value)" placeholder="e.g. Aarav Sharma"></div><div class="field"><label>Email</label><input class="input" type="email" value="${esc(p.email)}" oninput="setProfile('email',this.value)" placeholder="name@example.com"></div><div class="field"><label>Phone</label><input class="input" value="${esc(p.phone)}" oninput="setProfile('phone',this.value)" placeholder="+91..."></div><div class="field"><label>City</label><input class="input" value="${esc(p.city)}" oninput="setProfile('city',this.value)" placeholder="Bengaluru, India"></div><div class="field"><label>Target field / occupation</label><input class="input" value="${esc(p.field)}" oninput="setProfile('field',this.value)" placeholder="Software Engineering"></div><div class="field"><label>Years of experience</label><input class="input" value="${esc(p.experienceYears)}" oninput="setProfile('experienceYears',this.value)" placeholder="e.g. 1.5"></div><div class="field"><label>Highest education</label><input class="input" value="${esc(p.education)}" oninput="setProfile('education',this.value)" placeholder="B.E. Computer Science"></div><div class="field"><label>Graduation year</label><input class="input" value="${esc(p.graduation)}" oninput="setProfile('graduation',this.value)" placeholder="2025"></div><div class="field full"><label>Current / most recent role</label><input class="input" value="${esc(p.experienceRole)}" oninput="setProfile('experienceRole',this.value)" placeholder="Software Engineer"></div><div class="field full"><label>Availability</label><input class="input" value="${esc(p.availability)}" oninput="setProfile('availability',this.value)" placeholder="Immediate / 30 days / 60 days"></div></div></div>
 <div class="card"><h3>Profile completeness</h3>${profileChecklistHTML()}<div class="line"></div><div class="stat"><b>${profilePercent()}%</b><span>Profile complete</span></div><div class="actions"><button class="btn primary" onclick="completeProfile()">Save profile & continue →</button></div></div></div>`;
}
function selectGoal(g){state.goal=g;log('Pathway selected: '+g);save();render()}
function setProfile(k,v){state.profile[k]=v;save()}
function profilePercent(){const p=state.profile;const arr=[p.name,p.email,p.field,p.education,p.graduation,p.experienceYears,p.experienceRole,p.city];return Math.round(arr.filter(Boolean).length/arr.length*100)}
function profileChecklistHTML(){const items=[['Name',!!state.profile.name],['Email',!!state.profile.email],['Goal',!!state.goal],['Target field',!!state.profile.field],['Education',!!state.profile.education],['Experience context',!!state.profile.experienceRole],['City',!!state.profile.city]];return items.map(([a,b])=>`<div class="rule"><div class="rule-main"><b>${a}</b><span>${b?'Provided':'Still needed'}</span></div><span class="status ${b?'verified':'blocked'}">${b?'✓':'!'}</span></div>`).join('')}
function completeProfile(){if(!hasProfile()){toast('Complete the highlighted profile requirements: goal, name, email, target field and education.');return}log('Profile completed');go('evidence')}

function pageEvidence(){
 const coreDocs=[
  ['Degree / education certificate','Education evidence','required',state.checks.education],
  ['Experience letter','Role, employer and dates','required',state.checks.experience],
  ['Language certificate','Language level evidence','required',state.checks.language],
  ['Existing CV','Current resume','supporting',!!state.evidence.documents.find(x=>x.type==='CV')],
 ];
 document.getElementById('app').innerHTML=`<div class="section-head"><div><span class="pill">STEP 3 · EVIDENCE LOCKER</span><h2 style="margin-top:9px">Put every useful piece of evidence in one place.</h2><p>Core requirements plus extra evidence that can strengthen the applicant profile.</p></div><span class="pill blue">${evidenceCount()} ITEMS</span></div>
 <div class="grid2"><div><div class="card"><h3>Core evidence</h3><div class="doc-list">${coreDocs.map((d,i)=>`<div class="doc"><div class="doc-icon">${i+1}</div><div class="doc-main"><b>${d[0]}</b><span>${d[1]} · ${d[2]} requirement</span></div><span class="status ${d[3]?'verified':'pending'}">${d[3]?'✓ Ready':'Add evidence'}</span></div>`).join('')}</div><div class="upload-area" style="margin-top:11px"><b style="font-size:11px">Add a document</b><div class="muted" style="margin:5px 0 10px">PDF, image, DOCX — demo stores the file name and uses simulated analysis.</div><label class="upload-btn" for="fileInput">＋ Choose file</label><input id="fileInput" type="file" multiple accept=".pdf,.png,.jpg,.jpeg,.doc,.docx" onchange="handleFiles(this.files)"></div></div>
 <div class="card" style="margin-top:14px"><h3>Extra evidence</h3>${extraEvidenceRows()}</div></div>
 <div class="card"><h3>Why these extras matter</h3><p class="small">Extra courses, internships, projects, certifications, awards and volunteering can strengthen role fit and the final resume. They do not replace a mandatory requirement.</p><div class="grid3" style="margin-top:10px"><div class="stat"><b>${state.evidence.courses.length}</b><span>Courses</span></div><div class="stat"><b>${state.evidence.internships.length}</b><span>Internships</span></div><div class="stat"><b>${state.evidence.certifications.length}</b><span>Certifications</span></div></div><h4>Consistency checks</h4>${['Qualification titles are readable','Language proof is identifiable'].map((x,i)=>`<label class="check"><input type="checkbox" ${[state.checks.education,state.checks.language][i]?'checked':''} onchange="toggleCheck('${['education','language'][i]}',this.checked)">${x}</label>`).join('')}<div class="actions"><button class="btn primary" ${evidenceCount()? '':'disabled'} onclick="analyzeEvidence()">Analyze evidence →</button></div></div></div>`;
}
function extraEvidenceRows(){const groups=[['courses','Extra courses','Course completion certificate'],['internships','Internships','Internship / experience letter'],['projects','Projects','Portfolio / project proof'],['certifications','Certifications','Certification document'],['awards','Awards / hackathons','Award or participation proof'],['volunteering','Volunteering / leadership','Letter / proof']];return groups.map(([key,label,desc])=>`<div class="rule"><div class="rule-main"><b>${label}</b><span>${desc} · ${state.evidence[key].length} added</span></div><button class="btn secondary" onclick="addExtra('${key}')">＋ Add</button></div>`).join('')}
function handleFiles(files){for(const f of files){const type=/\.pdf$/i.test(f.name)?'PDF':/\.(png|jpg|jpeg)$/i.test(f.name)?'Image':'Document';state.evidence.documents.push({name:f.name,type,verified:false});log('Uploaded evidence: '+f.name)}save();render();toast('Files added to the evidence locker')}
function addExtra(key){const label={courses:'Extra course',internships:'Internship',projects:'Project',certifications:'Certification',awards:'Award / hackathon',volunteering:'Volunteering experience'}[key];const value=prompt(`Enter ${label} name:`);if(!value)return;state.evidence[key].push({name:value,verified:true,source:'Applicant-provided'});log(label+' added: '+value);save();render();}
function toggleCheck(k,v){state.checks[k]=v;save()}
function analyzeEvidence(){state.checks.documentCompleteness=true; if(state.evidence.documents.length) state.checks.education=true; state.checks.experience=state.evidence.documents.some(x=>/experience|employment|intern/i.test(x.name)) || !!state.profile.experienceRole; state.checks.language=state.evidence.documents.some(x=>/language|german|english|telc|goethe|ielts/i.test(x.name)); log('Evidence analysis completed'); save(); go('video')}

function pageVideo(){
 document.getElementById('app').innerHTML=`<div class="section-head"><div><span class="pill">STEP 4 · INTRODUCTION VIDEO</span><h2 style="margin-top:9px">Tell the system what documents cannot.</h2><p>The PDF asks the solution to capture background, motivation and career goals from a short introduction video.</p></div></div>
 <div class="video-grid"><div class="card"><div class="video-preview"><div><div class="play">▶</div><h3 style="margin:14px 0 5px">1-minute introduction</h3><p style="font-size:9px;color:#b8c3d6">Background · motivation · career goals</p><button class="btn primary" onclick="uploadVideo()">${state.video.uploaded?'Replace video':'Add introduction video'}</button></div></div><div class="actions"><button class="btn secondary" onclick="analyzeVideo()" ${state.video.uploaded?'':'disabled'}>Analyze video →</button></div></div>
 <div class="card"><h3>Extracted insights</h3>${state.video.analyzed?`<div class="insight-row"><small>Background</small><b>${esc(state.video.background)}</b></div><div class="insight-row"><small>Motivation</small><b>${esc(state.video.motivation)}</b></div><div class="insight-row"><small>Career goals</small><b>${esc(state.video.careerGoals)}</b></div><span class="status ai">AI summary · needs source trace</span>`:`<div class="stat"><b>Waiting for video</b><span>Upload a short introduction, then analyze it.</span></div>`}<h4>Transcript note</h4><p class="small">The prototype records the idea of speech-to-text and insight extraction. Production would connect a speech-to-text service as allowed by the problem statement.</p></div></div>`;
}
function uploadVideo(){state.video.uploaded=true;log('Introduction video added');save();render();toast('Video added — ready for analysis')}
function analyzeVideo(){state.video.analyzed=true;state.video.transcript='I am a computer science graduate with software experience. I want to continue my career in Germany and build deeper engineering skills.';state.video.background='Computer Science graduate with software engineering experience.';state.video.motivation='Wants to build a long-term career in Germany.';state.video.careerGoals='Grow into a stronger software engineering role.';log('Introduction video analyzed');save();go('qualification')}

function buildQualification(){
 const mandatory=[];
 mandatory.push({key:'goal',label:'Pathway selected',detail:state.goal?'Goal is '+state.goal:'Choose study, vocational training or employment.',pass:!!state.goal});
 mandatory.push({key:'education',label:'Education evidence',detail:'Qualification / degree / school evidence must be identifiable and readable.',pass:state.checks.education || !!state.profile.education});
 if(state.goal==='Employment') mandatory.push({key:'experience',label:'Relevant experience evidence',detail:'Role, employer and dates should be supported or clearly applicant-provided.',pass:state.checks.experience});
 mandatory.push({key:'language',label:'Language evidence',detail:'Required language level must be checked against the selected programme, training route or target role.',pass:state.checks.language});
 mandatory.push({key:'documentCompleteness',label:'Core evidence completeness',detail:'Required supporting inputs should be present or explicitly marked missing.',pass:state.checks.documentCompleteness});
 if(state.goal==='Employment') mandatory.push({key:'recognition',label:'Recognition / comparability route',detail:'Where the occupation or route requires recognition/comparability, evidence or a clear next action is needed.',pass:state.checks.recognition});
 mandatory.push({key:'pathwayFit',label:'Pathway fit',detail:'The profile should match the selected pathway and stated target field.',pass:state.checks.pathwayFit});
 return mandatory;
}
function qualificationScore(rules){return Math.round(rules.filter(r=>r.pass).length/rules.length*100)}
function runQualification(){
 const rules=buildQualification();const missing=rules.filter(r=>!r.pass);let status='QUALIFIED';
 if(!state.video.analyzed) status='BLOCKED';
 else if(missing.length===0) status='QUALIFIED';
 else if(missing.length<=2 && rules.some(r=>r.pass)) status='NEEDS EVIDENCE';
 else status='BLOCKED';
 state.qualification={status,score:qualificationScore(rules),rules,missing,checkedAt:new Date().toLocaleString()};log('Qualification check run: '+status);save();render();
}

function confirmGate(key){state.checks[key]=true;log('Qualification gate confirmed: '+key);save();render();toast('Gate confirmed — rerun qualification') }

function pageQualification(){
 const q=state.qualification;const rules=buildQualification();
 const tone=!q?'warn':q.status==='QUALIFIED'?'good':q.status==='NEEDS EVIDENCE'?'warn':'bad';
 const status=!q?'READY TO RUN':q.status;
 document.getElementById('app').innerHTML=`<div class="section-head"><div><span class="pill">STEP 5 · QUALIFICATION</span><h2 style="margin-top:9px">A visible rule engine, not a black-box score.</h2><p>Mandatory gates are separated from supporting evidence. Extra courses and internships strengthen the profile but cannot replace a missing mandatory requirement.</p></div><span class="pill ${tone==='good'?'green':tone==='bad'?'red':'amber'}">${status}</span></div>
 <div class="gate"><div class="gate-card"><h3>Qualification criteria</h3>${rules.map(r=>`<div class="rule"><div class="rule-main"><b>${r.label}</b><span>${r.detail}</span></div><div style="display:flex;align-items:center;gap:7px"><span class="status ${r.pass?'verified':'blocked'}">${r.pass?'✓ Pass':'! Gap'}</span>${['recognition','pathwayFit','consistency'].includes(r.key)&&!r.pass?`<button class="btn secondary" style="padding:5px 8px;font-size:8px" onclick="confirmGate('${r.key}')">Confirm</button>`:''}</div></div>`).join('')}<div class="actions"><button class="btn primary" onclick="runQualification()">${q?'Run again':'Run qualification check'} ↻</button></div></div>
 <div class="result ${tone}"><span class="pill ${q?.status==='QUALIFIED'?'green':q?.status==='BLOCKED'?'red':'amber'}">${q?'RESULT':'BEFORE CHECK'}</span><h2>${q?q.status:'Ready to evaluate'}</h2><p>${q?q.status==='QUALIFIED'?'All configured mandatory gates are currently satisfied.':q.status==='NEEDS EVIDENCE'?'The applicant looks potentially suitable, but remaining gaps must be resolved before routing.':'The current evidence is not sufficient for a qualified outcome. The exact gaps are shown on the left.':'The engine checks pathway, evidence, consistency and required routing conditions.'}</p><div class="scorebar"><i style="width:${q?.score||0}%"></i></div><div class="muted" style="color:#c2cad8;margin-top:6px">Evidence / rule completion · ${q?.score||0}%</div><div class="criteria"><div class="stat"><b>${extraCount()}</b><span>Extra evidence items</span></div><div class="stat"><b>${verifiedExtras()}</b><span>Verified extra items</span></div></div>${q?.missing?.length?`<div style="margin-top:14px"><b style="font-size:9px;color:#ffd6d6">Needs attention</b>${q.missing.map(m=>`<div style="font-size:9px;color:#f2c7c7;margin-top:5px">• ${m.label}</div>`).join('')}</div>`:''}</div></div>`;
}

function pageNext(){
 const q=state.qualification;if(!q){runQualification();return}
 let next='';let detail='';let action='';
 if(q.status==='QUALIFIED'){next='Verified resume';detail='Your core qualification gates are complete. The next step is to generate and approve an evidence-backed resume.';action=`<button class="btn primary" onclick="go('resume')">Go to verified resume →</button>`}
 else if(q.status==='NEEDS EVIDENCE'){next='Resolve remaining evidence';detail='Do not jump to resume yet. Add or confirm the missing evidence shown by the qualification engine.';action=`<button class="btn primary" onclick="go('evidence')">Resolve evidence →</button>`}
 else {next='Complete core evidence';detail='The applicant is not ready for final routing. Use the recovery plan to fix the blockers first.';action=`<button class="btn primary" onclick="go('evidence')">Open evidence locker →</button>`}
 document.getElementById('app').innerHTML=`<div class="section-head"><div><span class="pill">STEP 6 · ROUTING</span><h2 style="margin-top:9px">The next step follows the qualification result.</h2><p>This is the control point that prevents unresolved evidence from jumping straight to resume or outreach.</p></div></div><div class="next-grid"><div><div class="next-card active"><span class="pill ${q.status==='QUALIFIED'?'green':'amber'}">RECOMMENDED NEXT STEP</span><h3 style="font-size:19px;margin-top:10px">${next}</h3><p>${detail}</p>${q.missing?.length?`<div class="card" style="background:#fafbfe;margin-top:12px"><h3>Recovery plan</h3>${q.missing.map(m=>`<div class="rule"><div class="rule-main"><b>${m.label}</b><span>${recoveryText(m.key)}</span></div><span class="status blocked">Action</span></div>`).join('')}</div>`:''}<div class="actions">${action}</div></div></div><div><div class="card"><h3>Decision summary</h3><div class="stat"><b>${q.status}</b><span>Qualification status</span></div><div class="grid3" style="margin-top:9px"><div class="stat"><b>${q.score}%</b><span>Rule completion</span></div><div class="stat"><b>${extraCount()}</b><span>Extra evidence</span></div><div class="stat"><b>${state.video.analyzed?'Yes':'No'}</b><span>Video analyzed</span></div></div></div><div class="card" style="margin-top:12px"><h3>Why this matters</h3><p class="small">The PDF asks for a clear qualification outcome and a logical recommended next step. This router enforces that connection instead of making every applicant follow the same route.</p></div></div></div>`;
}
function recoveryText(key){const map={goal:'Select the applicant pathway.',education:'Add or verify education evidence.',experience:'Add experience / internship evidence and confirm dates.',language:'Provide language evidence or confirm the required level for the target route.',documentCompleteness:'Add the missing core evidence documents.',recognition:'Confirm whether the route needs recognition/comparability and capture the evidence or action.',pathwayFit:'Align target field, profile and selected pathway.'};return map[key]||'Review the missing requirement.'}

function pageResume(){
 const qualified=state.qualification?.status==='QUALIFIED';
 if(!qualified){document.getElementById('app').innerHTML=`<div class="card"><span class="pill red">LOCKED</span><h2 style="margin:10px 0 6px">Resume is locked until qualification passes.</h2><p class="small">Resolve the qualification gaps first. The system will never route an unresolved applicant directly to outreach.</p><div class="actions"><button class="btn primary" onclick="go('qualification')">Back to qualification →</button></div></div>`;return}
 const p=state.profile;const extra=Object.entries(state.evidence).filter(([k])=>['courses','internships','projects','certifications','awards','volunteering'].includes(k)).flatMap(([k,a])=>a.map(x=>({...x,kind:k})));
 document.getElementById('app').innerHTML=`<div class="section-head"><div><span class="pill">STEP 7 · VERIFIED RESUME</span><h2 style="margin-top:9px">A resume built from evidence, not invention.</h2><p>Verified facts can be presented normally. Applicant-provided items remain labelled until verified.</p></div><div class="resume-actions"><button class="btn secondary" onclick="downloadResume()">Download draft</button><button class="btn primary" onclick="approveResume()">Approve resume →</button></div></div><div class="card"><div class="resume-head"><div><div class="resume-name">${esc(p.name||'Applicant')}</div><div class="muted">${esc(p.field||'Target field')} · ${esc(p.city||'India')} · Germany · ${esc(state.goal)}</div></div><span class="pill green">QUALIFICATION PASSED</span></div><div class="line"></div><div class="resume-section"><h3>Professional summary</h3><p class="small">${esc((p.education||'Applicant')+' with '+(p.experienceYears||'relevant')+' years of experience in '+(p.field||'the target field')+', supported by the evidence collected in this journey.')}</p></div><div class="resume-section"><h3>Core evidence</h3><div class="resume-row"><div><b>Education</b><span>${esc(p.education||'Education evidence')} · ${esc(p.graduation||'') }</span></div><span class="source-badge">Verified / applicant evidence</span></div><div class="resume-row"><div><b>Experience</b><span>${esc(p.experienceRole||'Experience')} · ${esc(p.experienceYears||'')} years</span></div><span class="source-badge">Verified / applicant evidence</span></div><div class="resume-row"><div><b>Language</b><span>Language requirement tracked separately in qualification.</span></div><span class="source-badge">Evidence status</span></div></div><div class="resume-section"><h3>Additional evidence</h3>${extra.length?extra.slice(0,8).map(x=>`<div class="resume-row"><div><b>${esc(x.name)}</b><span>${x.kind} · ${x.source||'Applicant-provided'}</span></div><span class="source-badge">${x.verified?'Verified':'Applicant'}</span></div>`).join(''):'<p class="small">No extra evidence added. Courses, internships, projects and certifications can be added from the evidence locker.</p>'}</div><div class="resume-section"><h3>Interview readiness signal</h3><div class="grid3"><div class="stat"><b>${readinessScore()}%</b><span>Preparation signal</span></div><div class="stat"><b>${state.evidence.internships.length}</b><span>Internships</span></div><div class="stat"><b>${state.evidence.projects.length}</b><span>Projects</span></div></div><p class="footer-note">This is a preparation signal, not a hiring or legal eligibility decision.</p></div></div>`;
}
function readinessScore(){let s=35;if(state.evidence.internships.length)s+=15;if(state.evidence.projects.length)s+=10;if(state.evidence.certifications.length)s+=10;if(state.video.analyzed)s+=10;if(state.checks.language)s+=10;if(state.evidence.courses.length)s+=10;return Math.min(100,s)}
function downloadResume(){const p=state.profile;const text=`EduGuide AI — Evidence-backed resume\n\n${p.name}\n${p.field}\nGermany · ${state.goal}\n\nEducation: ${p.education} (${p.graduation})\nExperience: ${p.experienceRole} (${p.experienceYears} years)\nExtra evidence: ${extraCount()} items\nQualification: ${state.qualification?.status||'Pending'}\n\nNote: This prototype distinguishes verified and applicant-provided evidence.`;downloadText('EduGuideAI_Resume.txt',text);toast('Resume draft exported')}
function downloadText(name,text){const blob=new Blob([text],{type:'text/plain'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=name;a.click();URL.revokeObjectURL(a.href)}
function approveResume(){state.resumeApproved=true;log('Resume approved by applicant');save();go('outreach')}

function pageOutreach(){
 if(!state.resumeApproved){document.getElementById('app').innerHTML=`<div class="card"><span class="pill red">LOCKED</span><h2 style="margin:10px 0 6px">Educaro routing is locked.</h2><p class="small">Approve the evidence-backed resume first. The applicant does not contact a company directly in this prototype.</p><div class="actions"><button class="btn primary" onclick="go('resume')">Back to resume →</button></div></div>`;return}
 const companies=[['SAP','Software / Enterprise','Strong role-domain match'],['Siemens','Technology / Engineering','Strong education + domain match'],['Bosch','Engineering / Mobility','Relevant technical profile']];
 const stage=state.educaroForwarded?4:state.outreachSent?2:1;
 document.getElementById('app').innerHTML=`<div class="section-head"><div><span class="pill">STEP 8 · EDUCARO ROUTING</span><h2 style="margin-top:9px">Submit the application to Educaro Deutschland GmbH.</h2><p>The applicant does not contact companies directly. Educaro receives the approved profile first and then routes it to suitable employers or training partners.</p></div><span class="pill blue">EDUCARO FIRST</span></div><div class="route-track"><div class="track ${stage>=1?'active':''}"><b>1 · Applicant</b><span>Approve profile + resume</span></div><div class="track ${stage>=2?'done':'active'}"><b>2 · Educaro</b><span>Receive + review</span></div><div class="track ${stage>=4?'done':'active'}"><b>3 · Company</b><span>Matched company receives profile</span></div><div class="track ${state.interviewOffer?'done':''}"><b>4 · Interview</b><span>Reply → extract → notify</span></div></div><div class="grid2"><div><div class="email"><b>Email destination: Educaro Deutschland GmbH</b><div class="line"></div><b>Subject:</b> ${esc(state.goal)} application — ${esc(state.profile.name||'Applicant')}<br><br>Hello Educaro Deutschland GmbH,<br><br>I am applying for a ${esc((state.goal||'Germany').toLowerCase())} opportunity in Germany. My evidence-backed profile and resume are ready. Please review my profile and route it to suitable employers / training partners in your network.<br><br>Regards,<br>${esc(state.profile.name||'Applicant')}</div><div class="actions"><button class="btn primary" onclick="sendToEducaro()">${state.outreachSent?(state.educaroForwarded?'Routing complete':'Simulate Educaro review + forwarding →'):'Approve & send to Educaro'}</button>${state.educaroForwarded?'<button class="btn secondary" onclick="go(\'interview\')">Monitor company replies →</button>':''}</div></div><div><div class="card"><h3>Prototype company matches</h3><p class="muted">Demo-only examples; production would use connected Educaro/company data.</p><div class="company-list">${companies.map(c=>`<div class="company"><div class="company-top"><div><b>${c[0]}</b><span>${c[1]}</span></div><span class="pill ${state.educaroForwarded?'green':'blue'}">${state.educaroForwarded?'ROUTED':'MATCH PREVIEW'}</span></div><p>${c[2]}</p></div>`).join('')}</div></div><div class="card" style="margin-top:12px"><h3>Activity</h3>${activityHTML()}</div></div></div>`;
}
function sendToEducaro(){if(!state.outreachSent){state.outreachSent=true;log('Application email approved and sent to Educaro Deutschland GmbH');save();render();toast('Application sent to Educaro');return}if(!state.educaroForwarded){state.educaroForwarded=true;log('Educaro routing simulated: profile forwarded to matched company');save();render();toast('Educaro forwarded the profile to a matched company')}else go('interview')}

function pageInterview(){
 if(!state.educaroForwarded){document.getElementById('app').innerHTML=`<div class="card"><span class="pill amber">WAITING FOR EDUCARO</span><h2 style="margin:10px 0 6px">Interview monitoring is not active yet.</h2><p class="small">The monitoring stage begins only after Educaro has forwarded the application to a matched company.</p><div class="actions"><button class="btn primary" onclick="go('outreach')">Go to Educaro routing →</button></div></div>`;return}
 const offer=state.interviewOffer;
 const reply=offer?`Subject: Interview invitation — Software Engineer\n\nHello ${state.profile.name||'Aarav'},\n\nThank you for your application. We would like to invite you to an interview for the Software Engineer position.\n\nDate: 15 October 2026\nTime: 11:00 CET\nFormat: Online\n\nBest regards,\nHiring Team`:`Subject: Your application\n\nThank you for your application. Our team is reviewing your profile. We will contact Educaro / the candidate with next steps.`;
 document.getElementById('app').innerHTML=`<div class="section-head"><div><span class="pill">STEP 9 · INTERVIEW</span><h2 style="margin-top:9px">Company reply → interview extraction → applicant notification.</h2><p>In production, the inbox/CRM integration would classify company replies and extract date, time, timezone, format and meeting details.</p></div><span class="pill ${offer?'green':'blue'}">${offer?'INTERVIEW DETECTED':'MONITORING ACTIVE'}</span></div><div class="interview-grid"><div class="reply"><h3>Company reply</h3><pre>${esc(reply)}</pre><div class="actions"><button class="btn primary" onclick="simulateInterview()">${offer?'Refresh interview notification':'Simulate interview offer'}</button></div></div><div><div class="card"><h3>Extracted details</h3><div class="extract"><div class="stat"><span>Date</span><b>${offer?'15 Oct 2026':'—'}</b></div><div class="stat"><span>Time</span><b>${offer?'11:00 CET':'—'}</b></div><div class="stat"><span>Format</span><b>${offer?'Online':'—'}</b></div><div class="stat"><span>Role</span><b>${offer?'Software Engineer':'—'}</b></div></div></div>${offer?`<div class="notice" style="margin-top:12px">✓ Interview details are ready for the applicant. Notification status: <b>${state.notified?'Sent':'Pending'}</b></div>`:''}</div></div><div class="grid2" style="margin-top:14px"><div class="card"><h3>Journey chain</h3>${[['Applicant approved','✓'],['Educaro received','✓'],['Educaro forwarded','✓'],['Company reply detected',offer?'✓':'Listening'],['Applicant notified',state.notified?'✓':'Pending']].map(x=>`<div class="rule"><div class="rule-main"><b>${x[0]}</b></div><span class="status ${x[1]==='✓'?'verified':'pending'}">${x[1]}</span></div>`).join('')}</div><div class="card"><h3>Notification</h3><p class="small">${state.notified?'The applicant has been notified with the extracted interview date, time and format.':'After an interview invitation is detected, the system sends the applicant the extracted details.'}</p>${offer&&!state.notified?'<button class="btn primary" onclick="notifyApplicant()">Send applicant notification</button>':''}</div></div>`;
}
function simulateInterview(){state.interviewOffer=true;log('Company interview offer detected: 15 Oct 2026, 11:00 CET, online');save();render();toast('Interview offer detected')}
function notifyApplicant(){state.notified=true;log('Applicant notified about interview details');save();render();toast('Applicant notification sent')}

function activityHTML(){if(!state.activity.length)return '<p class="small">No activity yet. Your actions will appear here.</p>';return `<div class="activity">${state.activity.slice(0,6).map(x=>`<div class="activity-item"><span class="activity-dot"></span><div><b>${esc(x.message)}</b><span>${esc(x.time)}</span></div></div>`).join('')}</div>`}
function downloadProfile(){const payload={goal:state.goal,country:'Germany',profile:state.profile,evidence:state.evidence,video:state.video,qualification:state.qualification};downloadText('EduGuideAI_Profile.json',JSON.stringify(payload,null,2));toast('Profile exported')}

/* =========================
   Enhanced intelligence layer
   ========================= */
function migrateState(s){
  s=s||structuredClone(DEFAULT);
  s.germany=true; delete s.checks?.identity; delete s.checks?.consistency;
  s.profile=s.profile||{};
  Object.assign(s.profile,{languageLevel:s.profile.languageLevel||'',studyLanguage:s.profile.studyLanguage||'Not sure',recognitionReviewed:!!s.profile.recognitionReviewed});
  s.evidence=s.evidence||{};
  ['documents','courses','internships','projects','certifications','awards','volunteering','languages'].forEach(k=>{if(!Array.isArray(s.evidence[k]))s.evidence[k]=[]});
  s.evidence.smartDocuments=Array.isArray(s.evidence.smartDocuments)?s.evidence.smartDocuments:[];
  s.video=s.video||{};
  s.checks=s.checks||{};
  Object.assign(s.checks,{education:!!s.checks.education,experience:!!s.checks.experience,language:!!s.checks.language,documentCompleteness:!!s.checks.documentCompleteness,recognition:!!s.checks.recognition,pathwayFit:!!s.checks.pathwayFit}); delete s.checks.identity; delete s.checks.consistency;
  s.virtualInterview=s.virtualInterview||{started:false,questionIndex:0,answers:[],completed:false,score:0,feedback:[]};
  return s;
}
state=migrateState(state);

function resetDemo(){if(confirm('Reset the demo and start again?')){state=migrateState(structuredClone(DEFAULT));save();render();toast('Journey reset')}}

function requiredEvidenceList(){
  const common=[{key:'education',label:'Education / qualification evidence',detail:'Degree, school-leaving certificate or relevant qualification proof.'},{key:'language',label:'Language evidence / requirement review',detail:'Relevant German or English language evidence, depending on the pathway.'}];
  if(state.goal==='Employment') return [...common,{key:'experience',label:'Experience evidence',detail:'Experience letter, employment certificate or clear role/date evidence.'}];
  if(state.goal==='Vocational Training') return [...common];
  if(state.goal==='Study') return [...common];
  return common;
}
function classifyDocument(name){
  const n=String(name||'').toLowerCase();
  if(/cv|resume|lebenslauf/.test(n))return 'cv';
  if(/degree|diploma|certificate|marksheet|transcript|education|school|bachelor|master|b\.e\.|btech|mtech|mba/.test(n))return 'education';
  if(/experience|employment|offer|reliev|work|salary|internship|intern/.test(n))return n.includes('intern')?'internship':'experience';
  if(/language|german|english|goethe|telc|ielts|toefl|testdaf|dsh/.test(n))return 'language';
  if(/project|portfolio|github/.test(n))return 'project';
  if(/course|training|udemy|coursera|certificate/.test(n))return 'course';
  return 'supporting';
}
function smartDocumentIntelligence(){
  state.evidence.smartDocuments=state.evidence.documents.map(doc=>{
    const category=doc.category||classifyDocument(doc.name);
    const confidence=category==='education'?94:category==='experience'?91:category==='language'?93:category==='cv'?96:category==='internship'?89:category==='project'?87:category==='course'?85:78;
    const signals={education:'Detected education/qualification signals',experience:'Detected employer / role / date signals',language:'Detected language certificate signals',cv:'Detected resume structure',internship:'Detected internship / duration signals',project:'Detected project/portfolio signals',course:'Detected course / training signals',supporting:'Supporting document — manual review recommended'}[category];
    return {...doc,category,confidence,signals,analyzed:true};
  });
  state.checks.education=state.evidence.smartDocuments.some(d=>d.category==='education')||!!state.profile.education;
  state.checks.experience=state.evidence.smartDocuments.some(d=>d.category==='experience'||d.category==='internship')||!!state.profile.experienceRole;
  state.checks.language=state.evidence.smartDocuments.some(d=>d.category==='language')||!!state.checks.language;
  state.checks.documentCompleteness=missingCoreFiles().length===0;
  log('Smart Document Intelligence analyzed '+state.evidence.documents.length+' document(s)');
  save();
}
function missingCoreFiles(){
  const req=requiredEvidenceList();
  return req.filter(r=>{
    if(r.key==='education')return !(state.checks.education||state.evidence.smartDocuments.some(d=>d.category==='education')||state.profile.education);
    if(r.key==='experience')return !(state.checks.experience||state.evidence.smartDocuments.some(d=>['experience','internship'].includes(d.category)));
    if(r.key==='language')return !(state.checks.language||state.evidence.smartDocuments.some(d=>d.category==='language'));
    return false;
  });
}
function handleFiles(files){for(const f of files){const category=classifyDocument(f.name);state.evidence.documents.push({name:f.name,type:/\.pdf$/i.test(f.name)?'PDF':/\.(png|jpg|jpeg)$/i.test(f.name)?'Image':'Document',verified:false,category});log('Uploaded evidence: '+f.name)}smartDocumentIntelligence();render();toast('Files added and Smart Document Intelligence is ready')}
function showMissingFilesModal(){
 const missing=missingCoreFiles();
 if(!missing.length){toast('No core file gaps detected');return}
 const list=missing.map(m=>`<div class="rule"><div class="rule-main"><b>${esc(m.label)}</b><span>${esc(m.detail)}</span></div><span class="status blocked">Missing</span></div>`).join('');
 openModal('Missing files & evidence gaps',`<div class="missing-banner"><b>Some core evidence is still missing.</b><span>The qualification engine will not treat an unresolved applicant as qualified.</span></div><div>${list}</div>`,`<button class="btn secondary" onclick="closeModal()">Close</button><button class="btn primary" onclick="closeModal();go('evidence')">Open Evidence Locker →</button>`);
}
function smartDocListHTML(){
 const docs=state.evidence.smartDocuments||[];
 if(!docs.length)return '<div class="stat"><b>No analyzed documents</b><span>Upload files to see extracted document intelligence.</span></div>';
 return docs.slice(0,8).map((d,i)=>`<div class="doc"><div class="doc-icon">${i+1}</div><div class="doc-main"><b>${esc(d.name)}</b><span>${esc(d.category)} · ${esc(d.signals)}</span><div class="doc-ai"><b>Confidence ${d.confidence}%</b><span>${d.analyzed?'Prototype extraction complete — production would use OCR/document AI to extract and verify fields.':'Awaiting analysis'}</span></div></div><span class="status ${d.category==='supporting'?'applicant':'ai'}">${d.category==='supporting'?'Review':'AI insight'}</span></div>`).join('');
}

function profileLanguageRule(){
  if(state.goal==='Vocational Training') return 'For vocational training, German B1 is commonly used as the visa/training language benchmark; the exact route still needs case-specific confirmation.';
  if(state.goal==='Study') return state.profile.studyLanguage==='German-taught'?'For German-taught study, the programme determines the accepted certificate and level; many German-taught programmes require substantial German proficiency.':'For English-taught study, the programme normally defines the accepted English-language proof.';
  return 'For employment, language requirements are role-specific; evidence should be checked against the target occupation / employer.';
}
function languagePass(){
  if(state.goal==='Vocational Training') return ['B1','B2','C1','C2'].includes(state.profile.languageLevel)||state.checks.language;
  if(state.goal==='Study') return state.checks.language;
  return state.checks.language;
}
function regulatedHint(){
  const f=(state.profile.field||'').toLowerCase();
  const regulatedWords=['doctor','physician','nurse','nursing','teacher','lawyer','pharmacist','dentist','psychologist','architect'];
  return regulatedWords.some(x=>f.includes(x));
}
function buildQualification(){
  const mandatory=[];
  mandatory.push({key:'goal',label:'Pathway selected',detail:state.goal?'Goal is '+state.goal:'Choose study, vocational training or employment.',pass:!!state.goal});
  mandatory.push({key:'education',label:'Education / admission evidence',detail:state.goal==='Study'?'University entrance qualification and programme-admission evidence should be identifiable.':'Relevant education / qualification evidence must be identifiable and readable.',pass:state.checks.education||!!state.profile.education});
  if(state.goal==='Employment') mandatory.push({key:'experience',label:'Relevant experience evidence',detail:'Role, employer and dates should be supported or clearly applicant-provided.',pass:state.checks.experience});
  mandatory.push({key:'language',label:'Language requirement reviewed',detail:profileLanguageRule(),pass:languagePass()});
  mandatory.push({key:'documentCompleteness',label:'Core evidence completeness',detail:'Required supporting inputs should be present or explicitly marked missing.',pass:missingCoreFiles().length===0});
  if(state.goal==='Employment') mandatory.push({key:'recognition',label:'Recognition / comparability route reviewed',detail:regulatedHint()?'This target may be a regulated profession: recognition / professional authorisation should be checked.':'For a non-regulated route, recognition may not always be mandatory, but comparability/proof can still matter for some visa or employer routes.',pass:!!state.profile.recognitionReviewed});
  mandatory.push({key:'pathwayFit',label:'Pathway fit',detail:'The selected pathway, target field and profile should make sense together.',pass:!!state.goal&&!!state.profile.field&&!!state.profile.education});
  return mandatory;
}
function qualificationScore(rules){return Math.round(rules.filter(r=>r.pass).length/rules.length*100)}
function runQualification(){
  smartDocumentIntelligence();
  const rules=buildQualification();
  const missing=rules.filter(r=>!r.pass);
  let status='QUALIFIED';
  if(missing.length===0) status='QUALIFIED';
  else if(missing.length<=2 && rules.some(r=>r.pass)) status='NEEDS EVIDENCE';
  else status='BLOCKED';
  state.qualification={status,score:qualificationScore(rules),rules,missing,checkedAt:new Date().toLocaleString(),readiness:germanyReadinessScore()};
  log('Qualification check run: '+status);
  save();
  if(missingCoreFiles().length)showMissingFilesModal();
  render();
}
function recoveryText(key){const map={goal:'Select the applicant pathway.',education:'Add or verify education evidence.',experience:'Add experience / internship evidence and confirm dates.',language:'Provide language evidence or review the required language for the target route.',documentCompleteness:'Add the missing core evidence documents.',recognition:'Review the recognition/comparability route for the occupation and capture the decision.',pathwayFit:'Align target field, profile and selected pathway.'};return map[key]||'Review the missing requirement.'}
function confirmGate(key){state.checks[key]=true;if(key==='recognition')state.profile.recognitionReviewed=true;log('Qualification gate reviewed: '+key);save();render();toast('Gate reviewed — run qualification again')}

function readinessBreakdown(overrides={}){
  const goal=overrides.goal||state.goal;
  const profilePct=overrides.profilePct??profilePercent();
  const docs=overrides.docsComplete??(missingCoreFiles().length===0);
  const lang=overrides.languageLevel??state.profile.languageLevel;
  const languageReviewed=overrides.languageReviewed??state.checks.language;
  const recognition=overrides.recognition??state.profile.recognitionReviewed;
  const fit=overrides.fit??(!!goal&&!!state.profile.field&&!!state.profile.education);
  const video=overrides.video??state.video.analyzed;
  const extras=overrides.extras??extraCount();
  const reviewQuality=overrides.reviewQuality??(requiredEvidenceList().filter(x=>reviewedDoc(x.key)).length/requiredEvidenceList().length);
  const profile=Math.round(profilePct*0.15);
  const core=Math.round((docs?20:Math.max(0,20-missingCoreFiles().length*6)));
  let langPts=0;
  if(goal==='Vocational Training') langPts=['B1','B2','C1','C2'].includes(lang)?15:(languageReviewed?7:0);
  else if(goal==='Study') langPts=(languageReviewed?15:0);
  else langPts=languageReviewed?15:0;
  const recog=goal==='Employment'?(recognition?15:0):15;
  const fitPts=fit?15:6;
  const extraPts=Math.min(10,extras*2);
  const videoPts=video?5:0;
  const reviewPts=Math.round(reviewQuality*5);
  const total=Math.min(100,profile+core+langPts+recog+fitPts+extraPts+videoPts+reviewPts);
  return {total,items:[['Profile completeness',profile,15],['Core evidence',core,20],['Language / requirement review',langPts,15],['Recognition / route review',recog,15],['Pathway fit',fitPts,15],['Extra evidence',extraPts,10],['Introduction video',videoPts,5],['Smart document review',reviewPts,5]]};
}
function germanyReadinessScore(overrides={}){return readinessBreakdown(overrides).total}
function readinessCardHTML(){
  const r=readinessBreakdown();
  return `<div class="card score-card"><div class="score-orb" style="--score:${r.total*3.6}deg"><div><strong>${r.total}</strong><span>/100 readiness</span></div></div><div><span class="pill">GERMANY READINESS SCORE</span><h3 style="margin:8px 0 4px">Prototype readiness indicator</h3><p class="small">This combines evidence completeness, pathway fit, language review, recognition route review, extra evidence, video and consistency. It is <b>not</b> a visa, admission or hiring decision.</p>${r.items.map(x=>`<div class="signal-row"><b>${x[0]}</b><span>${x[1]}/${x[2]}</span></div>`).join('')}</div></div>`;
}
function openWhyNotEligible(){
 const q=state.qualification;
 if(!q){openModal('Why am I not eligible?',`<div class="missing-banner"><b>Qualification has not been run yet.</b><span>Run the qualification check to see pathway-specific gaps and a recovery plan.</span></div>`,`<button class="btn primary" onclick="closeModal();go('qualification')">Run qualification →</button>`);return}
 if(q.status==='QUALIFIED'){openModal('Why am I not eligible?',`<div class="notice">You are <b>qualified under the configured prototype gates</b>. This does not guarantee admission, employment, a visa, or an interview.</div><p class="small" style="margin-top:12px">The remaining work is routing and preparation: resume approval → Educaro review → company matching → interview flow.</p>`,`<button class="btn primary" onclick="closeModal();go('next')">Continue to next step →</button>`);return}
 const rows=q.missing.map(m=>`<div class="rule"><div class="rule-main"><b>${esc(m.label)}</b><span>${esc(m.detail)}</span><span style="color:#9a4343;margin-top:5px">Fix: ${esc(recoveryText(m.key))}</span></div><span class="status blocked">Gap</span></div>`).join('');
 openModal('Why am I not eligible right now?',`<div class="missing-banner"><b>${q.status==='BLOCKED'?'The evidence is not sufficient for a qualified outcome.':'The profile is potentially suitable, but some requirements still need resolution.'}</b><span>The engine shows the exact gates rather than hiding them behind a single score.</span></div>${rows}`,`<button class="btn secondary" onclick="closeModal()">Close</button><button class="btn primary" onclick="closeModal();go('evidence')">Fix evidence →</button>`);
}
function openWhatIf(){
  openModal('What‑If Career Simulator',`<p class="small">Try a scenario without changing the real applicant profile.</p><div class="simulate-grid"><div class="simulate-opt"><label><input type="checkbox" id="simLanguage"> Language requirement improved / evidence added</label></div><div class="simulate-opt"><label><input type="checkbox" id="simRecognition"> Recognition / comparability reviewed</label></div><div class="simulate-opt"><label><input type="checkbox" id="simInternship"> Add one internship</label></div><div class="simulate-opt"><label><input type="checkbox" id="simCourse"> Add one extra course / certificate</label></div><div class="simulate-opt"><label><input type="checkbox" id="simVideo"> Introduction video analyzed</label></div><div class="simulate-opt"><label><input type="checkbox" id="simDocs"> Complete missing core documents</label></div></div><div id="simResult" style="margin-top:14px">${simulateWhatIfHTML()}</div>`,`<button class="btn secondary" onclick="closeModal()">Close</button>`);
  ['simLanguage','simRecognition','simInternship','simCourse','simVideo','simDocs'].forEach(id=>document.getElementById(id).addEventListener('change',updateSimulator));
}
function updateSimulator(){document.getElementById('simResult').innerHTML=simulateWhatIfHTML()}
function simulateWhatIfHTML(){
 const ov={languageReviewed:document.getElementById('simLanguage')?.checked||false,recognition:document.getElementById('simRecognition')?.checked||false,video:document.getElementById('simVideo')?.checked||false,docsComplete:document.getElementById('simDocs')?.checked||false,extras:extraCount()+(document.getElementById('simInternship')?.checked?1:0)+(document.getElementById('simCourse')?.checked?1:0)};
 const current=germanyReadinessScore(), future=germanyReadinessScore(ov), delta=future-current;
 const next=future>=80?'Likely stronger readiness — continue to qualification / routing review.':future>=60?'Potentially closer — resolve the remaining gates before routing.':'Still early — focus on core evidence and pathway requirements first.';
 return `<div class="grid3"><div class="stat"><b>${current}</b><span>Current</span></div><div class="stat"><b>${future}</b><span>What-if</span></div><div class="stat"><b>${delta>=0?'+':''}${delta}</b><span>Change</span></div></div><div class="notice" style="margin-top:10px">${esc(next)}</div>`;
}
function openModal(title,body,actions=''){const root=document.getElementById('modalRoot');root.innerHTML=`<div class="modal-backdrop show" onclick="if(event.target===this)closeModal()"><div class="modal"><div class="modal-head"><h3>${esc(title)}</h3><button class="modal-close" onclick="closeModal()">×</button></div><div class="modal-body">${body}</div><div class="modal-actions">${actions}</div></div></div>`}
function closeModal(){document.getElementById('modalRoot').innerHTML=''}
function openHelpDesk(){
 const missing=missingCoreFiles();
 const context=STEPS[currentIndex()]?.short||'Journey';
 const rows=[];
 if(missing.length)rows.push({role:'bot',text:`I found ${missing.length} core evidence gap${missing.length>1?'s':''}. I can show you exactly which files are needed.`});
 rows.push({role:'bot',text:`You are currently on the ${context} stage. Ask me about qualification, the Germany Readiness Score, missing documents, or your next step.`});
 openModal('Magnus AI Help Desk',`<div class="chat">${rows.map(r=>`<div class="chat-row"><div class="chat-bubble">🤖 ${esc(r.text)}</div></div>`).join('')}</div><div class="grid3" style="margin-top:12px"><button class="btn secondary" onclick="openWhyNotEligible()">Why not eligible?</button><button class="btn secondary" onclick="openWhatIf()">What-if simulator</button><button class="btn secondary" onclick="${missing.length?'showMissingFilesModal()':'toast(\'No core file gaps detected\')'}">${missing.length?'Missing files':'Check files'}</button></div>`,`<button class="btn primary" onclick="closeModal()">Done</button>`);
}
function openVirtualInterview(){
  state.virtualInterview.started=true;state.virtualInterview.questionIndex=state.virtualInterview.questionIndex||0;save();renderVirtualInterviewModal();
}
function renderVirtualInterviewModal(){
 const qs=['Tell us about yourself and why you want to pursue this path in Germany.','Why did you choose this target field or role?','Describe one project, course or internship that shows relevant skills.','Tell us about a challenge you handled and what you learned from it.','What do you want to achieve in the next 12 months in Germany?'];
 const i=state.virtualInterview.questionIndex;
 if(i>=qs.length){state.virtualInterview.completed=true;const answers=state.virtualInterview.answers;const strengths=[];if(answers.every(a=>a&&a.length>60))strengths.push('Answers are detailed and structured');if(answers.some(a=>/project|internship|course|certificate/i.test(a)))strengths.push('Uses concrete evidence');if(answers.some(a=>/why|goal|motivat/i.test(a)))strengths.push('Explains motivation');state.virtualInterview.score=Math.min(100,40+strengths.length*20+(answers.filter(a=>a&&a.length>90).length*4));state.virtualInterview.feedback=strengths;save();openModal('Virtual Interview Results',`<div class="grid3"><div class="stat"><b>${state.virtualInterview.score}%</b><span>Practice score</span></div><div class="stat"><b>${answers.length}/5</b><span>Questions answered</span></div><div class="stat"><b>${strengths.length}</b><span>Strengths found</span></div></div><div class="card" style="margin-top:12px"><h3>Practice feedback</h3>${strengths.length?strengths.map(x=>`<div class="rule"><div class="rule-main"><b>✓ ${esc(x)}</b></div><span class="status verified">Strength</span></div>`).join(''):'<p class="small">Keep answers concise, evidence-based and specific. Mention courses, internships or projects when relevant.</p>'}</div><p class="footer-note">This is interview practice feedback, not a hiring decision.</p>`,`<button class="btn primary" onclick="closeModal();render()">Back to interview</button>`);return}
 const prev=state.virtualInterview.answers[i-1]||'';
 openModal('Virtual Interview Practice',`<span class="pill blue">QUESTION ${i+1} OF ${qs.length}</span><div class="question-box" style="margin-top:10px"><h4>${esc(qs[i])}</h4><p>Answer as if you were speaking to a German employer / training provider. Use concrete evidence where possible.</p><textarea id="viAnswer" class="textarea" placeholder="Type your answer here...">${esc(prev)}</textarea></div><div class="muted" style="margin-top:9px">Tip: strong answers explain the situation, what you did, and what you learned.</div>`,`<button class="btn secondary" onclick="closeModal()">Exit</button><button class="btn primary" onclick="submitVirtualAnswer()">${i===qs.length-1?'Finish practice':'Next question →'}</button>`);
}
function submitVirtualAnswer(){const a=(document.getElementById('viAnswer')?.value||'').trim();if(!a){toast('Please answer the question before continuing');return}state.virtualInterview.answers[state.virtualInterview.questionIndex]=a;state.virtualInterview.questionIndex++;save();renderVirtualInterviewModal()}

/* Richer page overrides */
function pageStart(){
  document.getElementById('app').innerHTML=`<section class="hero"><div><span class="pill dark">GERMANY ONLY · EVIDENCE-FIRST</span><h1>Build a <em>complete, qualified profile</em> for your Germany journey.</h1><p>One guided flow for profile, evidence, qualification and routing. The system distinguishes verified evidence, applicant-provided information and AI-generated summaries.</p><div style="display:flex;gap:8px;margin-top:16px;flex-wrap:wrap"><button class="btn primary" onclick="go('profile')">Start application →</button><button class="btn secondary" onclick="showHow()">How it works</button><button class="btn secondary" onclick="openWhatIf()">What-if simulator</button></div></div><div class="hero-right"><div class="big-ring"><div><strong>${germanyReadinessScore()}</strong><span>readiness / 100</span></div></div></div></section>
  <div class="section-head"><div><h2>Your smart workspace</h2><p>Built around the PDF requirements, with additional applicant-support features.</p></div><span class="pill blue">PROTOTYPE STANDARD · NOT LEGAL ADVICE</span></div>
  <div class="grid3"><div class="card"><span class="pill">01 · GERMANY READINESS</span><h3 style="margin-top:12px">${germanyReadinessScore()}/100</h3><p class="small">Transparent score using profile, core evidence, language review, recognition route review, pathway fit, extras, video and consistency.</p><button class="btn secondary" style="margin-top:8px" onclick="openWhyNotEligible()">Explain my result</button></div><div class="card"><span class="pill">02 · SMART DOCUMENTS</span><h3 style="margin-top:12px">Document intelligence</h3><p class="small">Upload files and see detected type, signals, confidence and possible evidence gaps.</p><button class="btn secondary" style="margin-top:8px" onclick="go('evidence')">Open evidence locker →</button></div><div class="card"><span class="pill">03 · VIRTUAL INTERVIEW</span><h3 style="margin-top:12px">Practice before the real one</h3><p class="small">A guided mock interview using the applicant's own background, courses, internships and projects.</p><button class="btn secondary" style="margin-top:8px" onclick="openVirtualInterview()">Try practice interview</button></div></div>
  <div class="grid2" style="margin-top:15px"><div>${readinessCardHTML()}</div><div class="card"><h3>What makes this qualification trustworthy?</h3><div class="rule"><div class="rule-main"><b>Hard gates first</b><span>Mandatory evidence is not replaced by extra courses or an AI score.</span></div><span class="status verified">Rule-based</span></div><div class="rule"><div class="rule-main"><b>Why not eligible?</b><span>Every gap has a reason and a recovery action.</span></div><span class="status ai">Explainable</span></div><div class="rule"><div class="rule-main"><b>What-if simulator</b><span>Test improvements without changing the real profile.</span></div><span class="status blue">Scenario</span></div></div></div>
  <div class="section-head"><div><h2>Current profile snapshot</h2><p>Everything is editable in the guided steps.</p></div></div><div class="grid3"><div class="stat"><b>${esc(state.profile.name||'Not entered')}</b><span>Applicant</span></div><div class="stat"><b>${esc(state.goal||'Choose a pathway')}</b><span>Goal</span></div><div class="stat"><b>${evidenceCount()}</b><span>Evidence items</span></div></div><div class="card" style="margin-top:15px"><h3>Journey activity</h3>${activityHTML()}</div>`;
}

function pageProfile(){
 const p=state.profile;
 document.getElementById('app').innerHTML=`<div class="section-head"><div><span class="pill">STEP 2 · PROFILE</span><h2 style="margin-top:9px">Start with your goal and basic profile.</h2><p>Germany is the only destination. Add enough context so the system can compare you against the right pathway standards.</p></div><button class="btn secondary" onclick="openHelpDesk()">🤖 Ask Magnus</button></div>
 <div class="grid2"><div class="card"><h3>What are you applying for?</h3><div class="goal-grid">${[['Study','University admission and study pathway.'],['Vocational Training','Vocational / Ausbildung pathway.'],['Employment','Employment and employer matching.']].map(([g,d])=>`<button class="goal ${state.goal===g?'selected':''}" onclick="selectGoal('${g}')"><strong>${g}</strong><span>${d}</span></button>`).join('')}</div><h4>Destination</h4><div class="stat" style="display:flex;align-items:center;gap:10px"><span style="font-size:18px">🇩🇪</span><div><b style="font-size:11px">Germany</b><span>Only destination in this prototype</span></div><span class="pill green" style="margin-left:auto">Selected</span></div><h4>Personal profile</h4><div class="form-grid"><div class="field"><label>Full name</label><input class="input" value="${esc(p.name)}" oninput="setProfile('name',this.value)" placeholder="e.g. Aarav Sharma"></div><div class="field"><label>Email</label><input class="input" type="email" value="${esc(p.email)}" oninput="setProfile('email',this.value)" placeholder="name@example.com"></div><div class="field"><label>Phone</label><input class="input" value="${esc(p.phone)}" oninput="setProfile('phone',this.value)" placeholder="+91..."></div><div class="field"><label>City</label><input class="input" value="${esc(p.city)}" oninput="setProfile('city',this.value)" placeholder="Bengaluru, India"></div><div class="field"><label>Target field / occupation</label><input class="input" value="${esc(p.field)}" oninput="setProfile('field',this.value)" placeholder="Software Engineering"></div><div class="field"><label>Years of experience</label><input class="input" value="${esc(p.experienceYears)}" oninput="setProfile('experienceYears',this.value)" placeholder="e.g. 1.5"></div><div class="field"><label>Highest education</label><input class="input" value="${esc(p.education)}" oninput="setProfile('education',this.value)" placeholder="B.E. Computer Science"></div><div class="field"><label>Graduation year</label><input class="input" value="${esc(p.graduation)}" oninput="setProfile('graduation',this.value)" placeholder="2025"></div><div class="field"><label>Current / most recent role</label><input class="input" value="${esc(p.experienceRole)}" oninput="setProfile('experienceRole',this.value)" placeholder="Software Engineer"></div><div class="field"><label>Availability</label><input class="input" value="${esc(p.availability)}" oninput="setProfile('availability',this.value)" placeholder="Immediate / 30 days / 60 days"></div><div class="field"><label>Language level</label><select class="select" onchange="setProfile('languageLevel',this.value);render()"><option value="" ${!p.languageLevel?'selected':''}>Not provided</option>${['A1','A2','B1','B2','C1','C2'].map(x=>`<option ${p.languageLevel===x?'selected':''}>${x}</option>`).join('')}</select></div><div class="field"><label>Study language (for Study)</label><select class="select" onchange="setProfile('studyLanguage',this.value);render()">${['Not sure','German-taught','English-taught'].map(x=>`<option ${p.studyLanguage===x?'selected':''}>${x}</option>`).join('')}</select></div>${state.goal==='Employment'?`<div class="field full"><label>Recognition / profession route reviewed?</label><select class="select" onchange="setProfile('recognitionReviewed',this.value==='yes');render()"><option value="no" ${!p.recognitionReviewed?'selected':''}>Not reviewed yet</option><option value="yes" ${p.recognitionReviewed?'selected':''}>Reviewed / route identified</option></select></div>`:''}</div></div>
 <div><div class="card"><h3>Profile completeness</h3>${profileChecklistHTML()}<div class="line"></div><div class="stat"><b>${profilePercent()}%</b><span>Profile complete</span></div><div class="actions"><button class="btn primary" onclick="completeProfile()">Save profile & continue →</button></div></div><div class="card" style="margin-top:12px"><h3>Pathway context</h3><p class="small">${esc(profileLanguageRule())}</p><p class="footer-note">The app uses this to explain readiness; final requirements remain programme-, occupation- and case-specific.</p></div></div></div>`;
}

function pageEvidence(){
 const missing=missingCoreFiles();
 document.getElementById('app').innerHTML=`<div class="section-head"><div><span class="pill">STEP 3 · EVIDENCE LOCKER</span><h2 style="margin-top:9px">Smart Document Intelligence</h2><p>Bring every useful document into one place. The prototype classifies files, extracts signals and highlights gaps.</p></div><div style="display:flex;gap:8px"><button class="btn secondary" onclick="openHelpDesk()">🤖 Help</button>${missing.length?'<button class="btn secondary" onclick="showMissingFilesModal()">Missing files</button>':''}</div></div>${missing.length?`<div class="missing-banner"><b>Missing core evidence: ${missing.length}</b><span>${missing.map(x=>esc(x.label)).join(' · ')}</span></div>`:''}<div class="grid2"><div><div class="card"><h3>Core evidence</h3><div class="doc-list"><div class="doc"><div class="doc-icon">1</div><div class="doc-main"><b>Education / qualification certificate</b><span>${state.checks.education?'Education evidence identified':'Required for profile evaluation'}</span></div><span class="status ${state.checks.education?'verified':'pending'}">${state.checks.education?'✓ Ready':'Add / review'}</span></div><div class="doc"><div class="doc-icon">2</div><div class="doc-main"><b>${state.goal==='Employment'?'Experience / employment evidence':'Language evidence'}</b><span>${state.goal==='Employment'?'Role, employer and dates':'Language level + certificate / review'}</span></div><span class="status ${(state.goal==='Employment'?state.checks.experience:state.checks.language)?'verified':'pending'}">${(state.goal==='Employment'?state.checks.experience:state.checks.language)?'✓ Ready':'Add / review'}</span></div><div class="doc"><div class="doc-icon">3</div><div class="doc-main"><b>Language evidence</b><span>Relevant language requirement tracking</span></div><span class="status ${state.checks.language?'verified':'pending'}">${state.checks.language?'✓ Ready':'Review'}</span></div><div class="doc"><div class="doc-icon">4</div><div class="doc-main"><b>Existing CV</b><span>Supporting resume input</span></div><span class="status ${state.evidence.documents.some(d=>d.category==='cv')?'verified':'pending'}">${state.evidence.documents.some(d=>d.category==='cv')?'✓ Added':'Optional'}</span></div></div><div class="upload-area" style="margin-top:11px"><b style="font-size:11px">Add documents</b><div class="muted" style="margin:5px 0 10px">PDF, image, DOCX — demo stores file names and simulates document intelligence.</div><label class="upload-btn" for="fileInput">＋ Choose files</label><input id="fileInput" type="file" multiple accept=".pdf,.png,.jpg,.jpeg,.doc,.docx" onchange="handleFiles(this.files)"></div></div><div class="card" style="margin-top:14px"><h3>Extra evidence</h3>${extraEvidenceRows()}<div class="line"></div><p class="small">Internships, extra courses, projects, certifications, awards and volunteering strengthen the profile and resume but do not replace a mandatory requirement.</p></div></div><div><div class="card"><div style="display:flex;justify-content:space-between;align-items:center;gap:10px"><h3>Smart extraction</h3><span class="pill ai">DOCUMENT AI</span></div>${smartDocListHTML()}</div><div class="card" style="margin-top:12px"><h3>Document review checks</h3>${['Qualification titles are readable','Language proof is identifiable'].map((x,i)=>`<label class="check"><input type="checkbox" ${[state.checks.education,state.checks.language][i]?'checked':''} onchange="toggleCheck('${['education','language'][i]}',this.checked)">${x}</label>`).join('')}<div class="actions"><button class="btn primary" ${evidenceCount()?'':'disabled'} onclick="analyzeEvidence()">Run Smart Document Intelligence →</button></div></div></div></div>`;
}
function analyzeEvidence(){smartDocumentIntelligence();state.checks.documentCompleteness=missingCoreFiles().length===0;save();log('Evidence review completed');go('video')}

function pageQualification(){
 const q=state.qualification;const rules=buildQualification();const tone=!q?'warn':q.status==='QUALIFIED'?'good':q.status==='NEEDS EVIDENCE'?'warn':'bad';const status=!q?'READY TO RUN':q.status;
 document.getElementById('app').innerHTML=`<div class="section-head"><div><span class="pill">STEP 5 · QUALIFICATION</span><h2 style="margin-top:9px">Germany readiness + explainable qualification</h2><p>Qualification uses configured pathway rules; the readiness score adds context but never replaces mandatory gates.</p></div><div style="display:flex;gap:8px"><button class="btn secondary" onclick="openWhyNotEligible()">Why not eligible?</button><button class="btn secondary" onclick="openWhatIf()">What-if</button></div></div><div style="margin-bottom:14px">${readinessCardHTML()}</div><div class="gate"><div class="gate-card"><h3>Mandatory qualification criteria</h3>${rules.map(r=>`<div class="rule"><div class="rule-main"><b>${esc(r.label)}</b><span>${esc(r.detail)}</span></div><div style="display:flex;align-items:center;gap:7px"><span class="status ${r.pass?'verified':'blocked'}">${r.pass?'✓ Pass':'! Gap'}</span>${!r.pass&&['recognition','pathwayFit','consistency','language'].includes(r.key)?`<button class="btn secondary" style="padding:5px 8px;font-size:8px" onclick="confirmGate('${r.key}')">Review</button>`:''}</div></div>`).join('')}<div class="actions"><button class="btn primary" onclick="runQualification()">${q?'Run again':'Run qualification check'} ↻</button></div><p class="footer-note">Standards note: official German guidance varies by pathway, programme, occupation and visa route. This prototype does not claim legal eligibility.</p></div><div class="result ${tone}"><span class="pill ${q?.status==='QUALIFIED'?'green':q?.status==='BLOCKED'?'red':'amber'}">${q?'RESULT':'BEFORE CHECK'}</span><h2>${q?q.status:'Ready to evaluate'}</h2><p>${q?q.status==='QUALIFIED'?'All configured mandatory gates are currently satisfied for this prototype route.':q.status==='NEEDS EVIDENCE'?'The applicant may be suitable, but some gates need evidence or review.':'The current evidence is not sufficient for a qualified outcome. The exact gaps are shown on the left.':'The engine checks pathway, evidence, consistency and route-specific requirements.'}</p><div class="scorebar"><i style="width:${q?.score||0}%"></i></div><div class="muted" style="color:#c2cad8;margin-top:6px">Mandatory rule completion · ${q?.score||0}%</div><div class="criteria"><div class="stat"><b>${extraCount()}</b><span>Extra evidence items</span></div><div class="stat"><b>${verifiedExtras()}</b><span>Verified extras</span></div></div>${q?.missing?.length?`<div style="margin-top:14px"><b style="font-size:9px;color:#ffd6d6">Why it is not ready</b>${q.missing.map(m=>`<div style="font-size:9px;color:#f2c7c7;margin-top:5px">• ${esc(m.label)}</div>`).join('')}</div>`:''}</div></div>`;
}

function pageInterview(){
 if(!state.educaroForwarded){document.getElementById('app').innerHTML=`<div class="card"><span class="pill amber">WAITING FOR EDUCARO</span><h2 style="margin:10px 0 6px">Interview monitoring is not active yet.</h2><p class="small">The monitoring stage begins only after Educaro has forwarded the application to a matched company.</p><div class="actions"><button class="btn primary" onclick="go('outreach')">Go to Educaro routing →</button></div></div>`;return}
 const offer=state.interviewOffer;const reply=offer?`Subject: Interview invitation — ${state.profile.field||'Target role'}\n\nHello ${state.profile.name||'Applicant'},\n\nThank you for your application. We would like to invite you to an interview.\n\nDate: 15 October 2026\nTime: 11:00 CET\nFormat: Online\n\nBest regards,\nHiring Team`:`Subject: Your application\n\nThank you for your application. Our team is reviewing your profile. We will contact Educaro / the candidate with next steps.`;
 document.getElementById('app').innerHTML=`<div class="section-head"><div><span class="pill">STEP 9 · INTERVIEW</span><h2 style="margin-top:9px">Company response + virtual interview preparation.</h2><p>Interview monitoring extracts date, time, timezone and format. You can also practice with a guided virtual interview.</p></div><span class="pill ${offer?'green':'blue'}">${offer?'INTERVIEW DETECTED':'MONITORING ACTIVE'}</span></div><div class="interview-grid"><div class="reply"><h3>Company reply</h3><pre>${esc(reply)}</pre><div class="actions"><button class="btn primary" onclick="simulateInterview()">${offer?'Refresh interview offer':'Simulate interview offer'}</button></div></div><div><div class="card"><h3>Extracted details</h3><div class="extract"><div class="stat"><span>Date</span><b>${offer?'15 Oct 2026':'—'}</b></div><div class="stat"><span>Time</span><b>${offer?'11:00 CET':'—'}</b></div><div class="stat"><span>Format</span><b>${offer?'Online':'—'}</b></div><div class="stat"><span>Role</span><b>${offer?esc(state.profile.field||'Target role'):'—'}</b></div></div></div>${offer?`<div class="notice" style="margin-top:12px">✓ Interview details are ready. Notification status: <b>${state.notified?'Sent':'Pending'}</b></div>`:''}</div></div><div class="grid2" style="margin-top:14px"><div class="card"><h3>Virtual interview room</h3><p class="small">Practice five questions using your own profile, internships, courses and projects.</p><div class="grid3" style="margin-top:10px"><div class="stat"><b>${state.virtualInterview.completed?state.virtualInterview.score+'%':'Ready'}</b><span>Practice score</span></div><div class="stat"><b>${state.evidence.internships.length}</b><span>Internships used</span></div><div class="stat"><b>${state.evidence.projects.length}</b><span>Projects used</span></div></div><div class="actions"><button class="btn primary" onclick="openVirtualInterview()">${state.virtualInterview.completed?'Practice again':'Start virtual interview'} →</button></div></div><div class="card"><h3>Applicant notification</h3><p class="small">${state.notified?'The applicant has been notified with the extracted interview date, time and format.':'After an interview invitation is detected, the system sends the applicant the extracted details.'}</p>${offer&&!state.notified?'<button class="btn primary" onclick="notifyApplicant()">Send applicant notification</button>':''}</div></div><div class="card" style="margin-top:14px"><h3>Journey chain</h3>${[['Applicant approved','✓'],['Educaro received','✓'],['Educaro forwarded','✓'],['Company reply detected',offer?'✓':'Listening'],['Applicant notified',state.notified?'✓':'Pending']].map(x=>`<div class="rule"><div class="rule-main"><b>${x[0]}</b></div><span class="status ${x[1]==='✓'?'verified':'pending'}">${x[1]}</span></div>`).join('')}</div>`;
}

/* Use the newest render path, including the enhanced page overrides. */


/* =========================================================
   Magnus + Standards + Smart Document Intelligence + Protection
   ========================================================= */
function ensureFeatureState(){
  state.profile=state.profile||{};
  Object.assign(state.profile,{languageLevel:state.profile.languageLevel||'',studyLanguage:state.profile.studyLanguage||'Not sure',recognitionReviewed:!!state.profile.recognitionReviewed});
  state.practical=Object.assign({accommodation:false,financialPlan:false,insuranceAwareness:false,pathwayResearch:false},state.practical||{});
  state.protection=Object.assign({identity:false,evidenceReview:false,consent:false,educaroReview:false,notification:false},state.protection||{});
  state.evidence=state.evidence||{};
  ['documents','courses','internships','projects','certifications','awards','volunteering','languages','smartDocuments'].forEach(k=>{if(!Array.isArray(state.evidence[k]))state.evidence[k]=[]});
  state.virtualInterview=state.virtualInterview||{started:false,questionIndex:0,answers:[],completed:false,score:0,feedback:[],cameraUsed:false};
}
ensureFeatureState();

function safeSave(){try{save()}catch(e){}}
function setPractical(k,v){state.practical[k]=!!v; safeSave(); render()}
function setProtection(k,v){state.protection[k]=!!v; safeSave(); render()}

function updateRoboFab(){
  const b=document.getElementById('roboBadge');
  if(!b)return;
  const n=missingCoreFiles().length;
  b.textContent=n?String(n):'✓';
  b.style.background=n?'#fff1f1':'#eaf8f2';
  b.style.color=n?'#a84343':'#218460';
  const fab=document.getElementById('roboFab');
  if(fab) fab.title=n?`${n} core evidence gap${n>1?'s':''} detected`:'Magnus AI Help Desk';
}

function openProtectionCenter(){
  const p=state.protection;
  const all=p.identity&&p.evidenceReview&&p.consent;
  openModal('Multi-Layer Protection Center',`
    <div class="notice" style="border-left-color:#6b58dc;background:#f5f3ff;color:#50439a"><b>Outbound actions are gated.</b><span style="display:block;margin-top:4px">This prototype uses multiple approval layers before anything is routed outside the applicant journey. Production should add real authentication, encryption, audit logs and server-side policy enforcement.</span></div>
    <div class="protection-grid" style="margin-top:12px">
      <div class="protection-layer"><div class="shield">①</div><strong>Identity check</strong><span>Applicant confirms name, contact details and target pathway.</span><div style="margin-top:9px"><label class="check"><input type="checkbox" ${p.identity?'checked':''} onchange="setProtection('identity',this.checked)"> Confirmed</label></div></div>
      <div class="protection-layer"><div class="shield">②</div><strong>Evidence review</strong><span>Applicant reviews the qualification evidence and unresolved gaps.</span><div style="margin-top:9px"><label class="check"><input type="checkbox" ${p.evidenceReview?'checked':''} onchange="setProtection('evidenceReview',this.checked)"> Confirmed</label></div></div>
      <div class="protection-layer"><div class="shield">③</div><strong>Outbound consent</strong><span>Applicant explicitly authorizes routing the profile to Educaro Deutschland GmbH.</span><div style="margin-top:9px"><label class="check"><input type="checkbox" ${p.consent?'checked':''} onchange="setProtection('consent',this.checked)"> Confirmed</label></div></div>
    </div>
    <div class="guard-note" style="margin-top:12px">Layer ④ — Educaro review — becomes complete only when the prototype simulates Educaro receiving and forwarding the approved profile. Interview monitoring stays locked before that handoff.</div>
    <div class="grid3" style="margin-top:12px"><div class="stat"><b>${p.identity?'✓':'—'}</b><span>Identity</span></div><div class="stat"><b>${p.evidenceReview?'✓':'—'}</b><span>Evidence review</span></div><div class="stat"><b>${p.consent?'✓':'—'}</b><span>Consent</span></div></div>
    <div class="notice" style="margin-top:12px;border-left-color:${all?'#39a47a':'#c2892d'};background:${all?'#f0faf6':'#fff8e8'};color:${all?'#2b6f59':'#7a5a16'}">${all?'All three applicant-side protection gates are ready.':'Complete the three applicant-side gates before sending the application.'}</div>
  `,`<button class="btn primary" onclick="closeModal()">Done</button>`);
}

function openMissingFilesQuick(){
  const missing=missingCoreFiles();
  if(missing.length) showMissingFilesModal();
  else openModal('Evidence status',`<div class="notice"><b>No core file gaps detected.</b><span style="display:block;margin-top:4px">The qualification engine can now focus on pathway fit, language, recognition and consistency.</span></div>`,`<button class="btn primary" onclick="closeModal()">Done</button>`);
}

function openHelpDesk(){
  const missing=missingCoreFiles();
  const context=STEPS[currentIndex()]?.short||'Journey';
  const readiness=germanyReadinessScore();
  const q=state.qualification;
  const rows=[];
  rows.push({text:`You're on ${context}. Germany Readiness Score: ${readiness}/100.`});
  if(missing.length) rows.push({text:`I found ${missing.length} core evidence gap${missing.length>1?'s':''}. I'll keep the application from being marked qualified until they are resolved.`});
  else rows.push({text:'No core file gaps are currently detected.'});
  if(q?.missing?.length) rows.push({text:`The latest qualification check has ${q.missing.length} unresolved gate${q.missing.length>1?'s':''}.`});
  openModal('Magnus AI Help Desk',`<div class="chat">${rows.map(r=>`<div class="chat-row"><div class="chat-bubble">🤖 ${esc(r.text)}</div></div>`).join('')}</div>
    <div class="grid3" style="margin-top:12px">
      <button class="btn secondary" onclick="openWhyNotEligible()">Why not eligible?</button>
      <button class="btn secondary" onclick="openWhatIf()">What-if career</button>
      <button class="btn secondary" onclick="closeModal();openMissingFilesQuick()">${missing.length?`Missing files (${missing.length})`:'Check files'}</button>
    </div>
    <div class="grid3" style="margin-top:9px">
      <button class="btn secondary" onclick="openProtectionCenter()">🛡 Protection</button>
      <button class="btn secondary" onclick="closeModal();go('qualification')">Qualification standards</button>
      <button class="btn secondary" onclick="closeModal();go('interview')">Interview practice</button>
    </div>`,`<button class="btn primary" onclick="closeModal()">Done</button>`);
}

function openExtraEvidence(key){
  const labels={courses:'Extra course',internships:'Internship',projects:'Project / portfolio',certifications:'Professional certification',awards:'Award / hackathon',volunteering:'Volunteering / leadership'};
  const label=labels[key]||'Extra evidence';
  openModal('Add '+label,`<div class="form-grid"><div class="field full"><label>Name</label><input id="extraName" class="input" placeholder="${esc(label)} name"></div><div class="field"><label>Provider / organisation</label><input id="extraProvider" class="input" placeholder="Organisation / company"></div><div class="field"><label>Date / duration</label><input id="extraDate" class="input" placeholder="2025 · 3 months"></div><div class="field full"><label>Supporting document filename</label><input id="extraDoc" class="input" placeholder="certificate.pdf / internship-letter.pdf"></div><div class="field full"><label>Notes</label><textarea id="extraNotes" class="textarea" placeholder="What did you learn or deliver?"></textarea></div></div><div class="guard-note" style="margin-top:11px">Extra evidence can strengthen the resume and readiness score, but it cannot replace a mandatory qualification gate. Until reviewed, it is labelled applicant-provided.</div>`,`<button class="btn secondary" onclick="closeModal()">Cancel</button><button class="btn primary" onclick="saveExtraEvidence('${key}')">Add evidence</button>`);
}
function saveExtraEvidence(key){
  const name=document.getElementById('extraName')?.value.trim();
  if(!name){toast('Enter the evidence name first');return}
  state.evidence[key].push({name,provider:document.getElementById('extraProvider')?.value.trim()||'',date:document.getElementById('extraDate')?.value.trim()||'',document:document.getElementById('extraDoc')?.value.trim()||'',notes:document.getElementById('extraNotes')?.value.trim()||'',verified:false,source:'Applicant-provided',reviewed:false});
  log(`${key} evidence added: ${name}`); safeSave(); closeModal(); render(); toast('Evidence added — review status is applicant-provided');
}
function extraEvidenceRows(){
  const groups=[['courses','Extra courses','Course completion certificate'],['internships','Internships','Internship / experience letter'],['projects','Projects','Portfolio / project proof'],['certifications','Certifications','Certification document'],['awards','Awards / hackathons','Award or participation proof'],['volunteering','Volunteering / leadership','Letter / proof']];
  return groups.map(([key,label,desc])=>`<div class="rule"><div class="rule-main"><b>${label}</b><span>${desc} · ${state.evidence[key].length} added${state.evidence[key].filter(x=>x.verified).length?` · ${state.evidence[key].filter(x=>x.verified).length} reviewed`:''}</span></div><button class="btn secondary" onclick="openExtraEvidence('${key}')">＋ Add</button></div>`).join('');
}

function classifyDocument(name){
  const n=String(name||'').toLowerCase();
  if(/cv|resume|lebenslauf/.test(n))return 'cv';
  if(/internship|intern\b|summer.?intern/.test(n))return 'internship';
  if(/project|portfolio|github|case.?study/.test(n))return 'project';
  if(/course|training|udemy|coursera|bootcamp|mooc/.test(n))return 'course';
  if(/language|german|english|goethe|telc|ielts|toefl|testdaf|dsh/.test(n))return 'language';
  if(/experience|employment|offer|reliev|work|salary|payslip/.test(n))return 'experience';
  if(/degree|diploma|certificate|marksheet|transcript|education|school|bachelor|master|b\.e\.|btech|mtech|mba/.test(n))return 'education';
  return 'supporting';
}
function normalizeDocName(name){return String(name||'').toLowerCase().replace(/\.[a-z0-9]+$/,'').replace(/[^a-z0-9]+/g,' ' ).trim()}
function smartDocumentIntelligence(){
  const seen={};
  state.evidence.smartDocuments=state.evidence.documents.map(doc=>{
    const category=doc.category||classifyDocument(doc.name);
    const key=normalizeDocName(doc.name); seen[key]=(seen[key]||0)+1;
    const confidence={education:95,experience:92,language:94,cv:97,internship:90,project:88,course:87,supporting:72}[category]||70;
    const fields={
      education:[['Qualification',state.profile.education||'Detected qualification signal'],['Graduation',state.profile.graduation||'Not confirmed']],
      experience:[['Role',state.profile.experienceRole||'Role signal detected'],['Duration',state.profile.experienceYears?state.profile.experienceYears+' years':'Needs review']],
      language:[['Language level',state.profile.languageLevel||'Not extracted'],['Evidence type','Language certificate / language proof']],
      cv:[['Document type','CV / resume'],['Target field',state.profile.field||'Not yet known']],
      internship:[['Placement','Internship signal detected'],['Duration','Review from letter']],
      course:[['Training','Course / upskilling signal'],['Provider','Review from certificate']],
      project:[['Portfolio','Project evidence detected'],['Source','Review file']],
      supporting:[['Type','Supporting document'],['Action','Manual review recommended']]
    }[category];
    const flags=[];
    if(seen[key]>1)flags.push('Possible duplicate document');
    if(/blur|unclear|low.?quality|scan/.test(String(doc.name).toLowerCase()))flags.push('Possible image-quality issue');
    if(category==='supporting')flags.push('Document type needs manual review');
    return {...doc,category,confidence,fields,flags,signals:{education:'Qualification / education signals',experience:'Employer / role / date signals',language:'Language proof signals',cv:'Resume structure',internship:'Internship placement / duration',project:'Portfolio / project evidence',course:'Course / training evidence',supporting:'Supporting document'}[category],analyzed:true};
  });
  state.checks.education=state.evidence.smartDocuments.some(d=>d.category==='education')||!!state.profile.education;
  state.checks.experience=state.evidence.smartDocuments.some(d=>['experience','internship'].includes(d.category))||!!state.profile.experienceRole;
  state.checks.language=state.evidence.smartDocuments.some(d=>d.category==='language')||!!state.checks.language;
  state.checks.documentCompleteness=missingCoreFiles().length===0;
  log('Smart Document Intelligence analyzed '+state.evidence.documents.length+' document(s)');
  safeSave();
}
function openDocumentInspector(i){
  const d=state.evidence.smartDocuments?.[i]; if(!d){toast('Document insight is not available yet');return}
  openModal('Smart Document Intelligence',`<div class="grid3"><div class="stat"><b>${esc(String(d.category).toUpperCase())}</b><span>Detected type</span></div><div class="stat"><b>${d.confidence}%</b><span>AI confidence</span></div><div class="stat"><b>${d.reviewed?'Reviewed':'Needs review'}</b><span>Human verification</span></div></div><div class="card" style="margin-top:12px"><h3>Extracted signals</h3>${(d.fields||[]).map(x=>`<div class="signal-row"><b>${esc(x[0])}</b><span>${esc(x[1])}</span></div>`).join('')}</div>${(d.flags||[]).length?`<div>${d.flags.map(f=>`<div class="redflag">⚠ ${esc(f)}</div>`).join('')}</div>`:`<div class="greenflag">✓ No obvious demo-level extraction flags detected.</div>`}<p class="footer-note">Prototype note: the browser demo infers signals from uploaded filenames and profile fields. Production would use OCR/document AI and human verification.</p>`,`<button class="btn secondary" onclick="closeModal()">Close</button><button class="btn primary" onclick="reviewDocument(${i})">Mark reviewed</button>`);
}
function reviewDocument(i){if(state.evidence.smartDocuments?.[i]){state.evidence.smartDocuments[i].reviewed=true;state.evidence.smartDocuments[i].verified=true;log('Document reviewed: '+state.evidence.smartDocuments[i].name);safeSave();closeModal();render();toast('Document marked as reviewed')} }
function smartDocListHTML(){
  const docs=state.evidence.smartDocuments||[];
  if(!docs.length)return '<div class="stat"><b>No analyzed documents</b><span>Upload files to generate structured document intelligence.</span></div>';
  return docs.map((d,i)=>`<div class="doc"><div class="doc-icon">${i+1}</div><div class="doc-main"><b>${esc(d.name)}</b><span>${esc(d.category)} · ${esc(d.signals||'Analysis available')}</span><div class="doc-ai"><b>${d.confidence}% confidence · ${d.reviewed?'Reviewed':'AI analysed'}</b><span>${(d.fields||[]).map(x=>`${esc(x[0])}: ${esc(x[1])}`).join(' · ')}</span>${(d.flags||[]).length?`<div class="redflag">${esc(d.flags.join(' · '))}</div>`:''}</div></div><button class="btn secondary" style="padding:6px 8px" onclick="openDocumentInspector(${i})">Inspect</button></div>`).join('');
}

function handleFiles(files){for(const f of files){const category=classifyDocument(f.name);state.evidence.documents.push({name:f.name,type:/\.pdf$/i.test(f.name)?'PDF':/\.(png|jpg|jpeg)$/i.test(f.name)?'Image':'Document',verified:false,category,reviewed:false});log('Uploaded evidence: '+f.name)}smartDocumentIntelligence();render();toast('Files added — Smart Document Intelligence updated')}

function requiredEvidenceList(){
  const common=[{key:'education',label:'Education / qualification evidence',detail:'Degree, school-leaving certificate or relevant qualification proof.'}];
  if(state.goal==='Study') return [...common,{key:'language',label:'Programme language evidence / review',detail:'Accepted language proof according to the chosen study programme.'}];
  if(state.goal==='Vocational Training') return [...common,{key:'language',label:'German language evidence',detail:'B1 is commonly used for vocational training / visa routes, subject to case-specific exceptions or training-provider assessment.'}];
  if(state.goal==='Employment') return [...common,{key:'experience',label:'Relevant experience evidence',detail:'Experience letter, employment certificate or clear role/date evidence.'}];
  return [...common,{key:'language',label:'Language evidence / requirement review',detail:'Review the language requirement for the selected route.'}];
}
function missingCoreFiles(){
  return requiredEvidenceList().filter(r=>{
    if(r.key==='education')return !(state.checks.education||state.evidence.smartDocuments.some(d=>d.category==='education')||state.profile.education);
    if(r.key==='experience')return !(state.checks.experience||state.evidence.smartDocuments.some(d=>['experience','internship'].includes(d.category)));
    if(r.key==='language')return !state.checks.language;
    return false;
  });
}

function profileLanguageRequirementText(){
  if(state.goal==='Vocational Training') return 'German B1 is commonly required for vocational-training visa routes, unless an applicable exception or sufficient language assessment applies.';
  if(state.goal==='Study') return state.profile.studyLanguage==='German-taught'?'German-taught study uses the university/programme language requirements.':'English-taught study follows the programme\'s accepted English-language proof; German is generally not the admission language requirement.';
  return 'Employment language needs are role- and employer-specific; there is no single universal German threshold for all employment routes.';
}
function languagePass(){
  if(state.goal==='Vocational Training') return ['B1','B2','C1','C2'].includes(state.profile.languageLevel) && state.checks.language;
  if(state.goal==='Study') return state.checks.language;
  if(state.goal==='Employment') return state.checks.language || !!state.profile.languageLevel;
  return state.checks.language;
}
function regulatedHint(){
  const f=(state.profile.field||'').toLowerCase();
  return ['doctor','physician','nurse','nursing','teacher','lawyer','pharmacist','dentist','psychologist','architect'].some(x=>f.includes(x));
}
function buildQualification(){
  const mandatory=[];
  mandatory.push({key:'goal',label:'Pathway selected',detail:state.goal?'Goal is '+state.goal:'Choose study, vocational training or employment.',pass:!!state.goal});
  mandatory.push({key:'education',label:'Education / admission evidence',detail:state.goal==='Study'?'University entrance qualification and programme-admission evidence should be identifiable.':'Relevant education / qualification evidence must be identifiable and readable.',pass:state.checks.education||!!state.profile.education});
  if(state.goal==='Employment') mandatory.push({key:'experience',label:'Relevant experience evidence',detail:'Role, employer and dates should be supported or clearly applicant-provided.',pass:state.checks.experience});
  mandatory.push({key:'language',label:'Language requirement',detail:profileLanguageRequirementText(),pass:languagePass()});
  mandatory.push({key:'documentCompleteness',label:'Core evidence completeness',detail:'Required supporting inputs should be present.',pass:missingCoreFiles().length===0});
  if(state.goal==='Employment') mandatory.push({key:'recognition',label:'Recognition / comparability route',detail:regulatedHint()?'This may be a regulated profession: recognition / professional authorisation is a key requirement.':'For non-regulated professions, recognition is not universally mandatory; comparability/proof may still matter depending on the route.',pass:!!state.profile.recognitionReviewed});
  mandatory.push({key:'pathwayFit',label:'Pathway fit',detail:'The selected pathway, target field and education should align.',pass:!!state.goal&&!!state.profile.field&&!!state.profile.education});
  return mandatory;
}
function qualificationScore(rules){return Math.round(rules.filter(r=>r.pass).length/rules.length*100)}
function runQualification(){
  smartDocumentIntelligence();
  const rules=buildQualification(),missing=rules.filter(r=>!r.pass);
  const status=missing.length===0?'QUALIFIED':(missing.length<=2?'NEEDS EVIDENCE':'BLOCKED');
  state.qualification={status,score:qualificationScore(rules),rules,missing,checkedAt:new Date().toLocaleString(),readiness:germanyReadinessScore()};
  log('Qualification check run: '+status); safeSave();
  if(missingCoreFiles().length)showMissingFilesModal();
  render();
}
function readinessBreakdown(overrides={}){
  const goal=overrides.goal??state.goal;
  const profilePct=overrides.profilePct??profilePercent();
  const docs=overrides.docsComplete??(missingCoreFiles().length===0);
  const lang=overrides.languageReviewed??state.checks.language;
  const recognition=overrides.recognition??state.profile.recognitionReviewed;
  const fit=overrides.fit??(!!goal&&!!state.profile.field&&!!state.profile.education);
  const video=overrides.video??state.video.analyzed;
  const extras=overrides.extras??extraCount();
  const practical=overrides.practical??Object.values(state.practical||{}).filter(Boolean).length;
  const reviewQuality=overrides.reviewQuality??(requiredEvidenceList().filter(x=>reviewedDoc(x.key)).length/requiredEvidenceList().length);
  const profile=Math.round(profilePct*0.10);
  const core=docs?20:Math.max(0,20-missingCoreFiles().length*7);
  let langPts=0;
  if(goal==='Vocational Training') langPts=(lang?15:7);
  else langPts=lang?15:5;
  const recog=(goal==='Employment'?(recognition?15:0):15);
  const fitPts=fit?15:5;
  const extraPts=Math.min(5,extras);
  const videoPts=video?5:0;
  const practicalPts=Math.min(5,Math.round(practical/4*5));
  const reviewPts=Math.round(reviewQuality*10);
  const total=Math.min(100,profile+core+langPts+recog+fitPts+extraPts+videoPts+practicalPts+reviewPts);
  return {total,items:[['Profile completeness',profile,10],['Core evidence',core,20],['Language / requirement review',langPts,15],['Recognition / route review',recog,15],['Pathway fit',fitPts,15],['Extra evidence',extraPts,5],['Introduction video',videoPts,5],['Germany practical readiness',practicalPts,5],['Smart document review',reviewPts,10]]};
}
function germanyReadinessScore(overrides={}){return readinessBreakdown(overrides).total}
function readinessCardHTML(){
  const r=readinessBreakdown();
  const label=r.total>=80?'Strongly prepared':r.total>=60?'Progressing':'Early stage';
  return `<div class="card score-card"><div class="score-orb" style="--score:${r.total*3.6}deg"><div><strong>${r.total}</strong><span>/100 readiness</span></div></div><div><span class="pill">GERMANY READINESS SCORE</span><h3 style="margin:8px 0 4px">${label}</h3><p class="small">A transparent prototype indicator based on evidence, pathway fit, language review, recognition route, consistency, extra evidence, video and practical Germany preparation. <b>It is not legal eligibility, admission, visa approval or hiring.</b></p>${r.items.map(x=>`<div class="signal-row"><b>${x[0]}</b><span>${x[1]}/${x[2]}</span></div>`).join('')}</div></div>`;
}

function openWhyNotEligible(){
 const q=state.qualification;
 if(!q){openModal('Why am I not eligible?',`<div class="missing-banner"><b>Qualification has not been run yet.</b><span>Run the qualification check to see the exact pathway-specific gates.</span></div><div class="standard-card" style="margin-top:12px"><div class="std-row"><div><b>Study</b><span>University entrance qualification + programme-specific language proof; visa can also require financial resources.</span></div><span class="pill blue">STANDARD</span></div><div class="std-row"><div><b>Vocational Training</b><span>Training route evidence + German language; B1 is commonly used for vocational-training visa routes.</span></div><span class="pill blue">STANDARD</span></div><div class="std-row"><div><b>Employment</b><span>Role/experience fit + recognition/comparability depending on occupation and route.</span></div><span class="pill blue">STANDARD</span></div></div>`,`<button class="btn primary" onclick="closeModal();go('qualification')">Run qualification →</button>`);return}
 if(q.status==='QUALIFIED'){openModal('Why am I not eligible?',`<div class="notice"><b>The prototype qualification gates are passed.</b><span style="display:block;margin-top:4px">This does not guarantee admission, employment, a visa, recognition or an interview.</span></div><div class="standard-card" style="margin-top:12px"><div class="std-row"><div><b>What happens next?</b><span>Evidence-backed resume → applicant approval → Educaro review → matched company → interview flow.</span></div><span class="pill green">READY</span></div></div>`,`<button class="btn primary" onclick="closeModal();go('next')">Continue →</button>`);return}
 const rows=q.missing.map(m=>`<div class="rule"><div class="rule-main"><b>${esc(m.label)}</b><span>${esc(m.detail)}</span><span style="color:#9a4343;margin-top:5px">Recovery: ${esc(recoveryText(m.key))}</span></div><span class="status blocked">Gap</span></div>`).join('');
 openModal('Why am I not eligible right now?',`<div class="missing-banner"><b>${q.status==='BLOCKED'?'The evidence is not sufficient for a qualified outcome.':'The profile is potentially suitable, but some requirements still need resolution.'}</b><span>The score does not hide the actual reason — each failed gate is shown below.</span></div>${rows}<div class="standard-card" style="margin-top:12px"><div class="std-row"><div><b>Important</b><span>The official requirement depends on pathway, programme, occupation, nationality and residence route. This prototype is a decision-support model, not a legal decision.</span></div></div></div>`,`<button class="btn secondary" onclick="closeModal()">Close</button><button class="btn primary" onclick="closeModal();go('evidence')">Fix evidence →</button>`);
}

function openWhatIf(){
  openModal('What‑If Career Simulator',`<p class="small">Explore a scenario without changing the real profile.</p><div class="career-grid"><div class="career-option"><b>Pathway scenario</b><select id="simGoal" class="select" style="margin-top:8px"><option value="${esc(state.goal||'Employment')}">${esc(state.goal||'Current')}</option><option value="Study">Study</option><option value="Vocational Training">Vocational Training</option><option value="Employment">Employment</option></select></div><div class="career-option"><b>Add practical improvements</b><span>Try language review, recognition review or extra evidence.</span></div></div><div class="simulate-grid" style="margin-top:10px"><div class="simulate-opt"><label><input type="checkbox" id="simLanguage"> Language requirement completed / evidence added</label></div><div class="simulate-opt"><label><input type="checkbox" id="simRecognition"> Recognition / comparability reviewed</label></div><div class="simulate-opt"><label><input type="checkbox" id="simInternship"> Add one internship</label></div><div class="simulate-opt"><label><input type="checkbox" id="simCourse"> Add one extra course</label></div><div class="simulate-opt"><label><input type="checkbox" id="simVideo"> Add introduction video analysis</label></div><div class="simulate-opt"><label><input type="checkbox" id="simDocs"> Complete missing core documents</label></div></div><div id="simResult" style="margin-top:14px"></div>`,`<button class="btn secondary" onclick="closeModal()">Close</button>`);
  ['simGoal','simLanguage','simRecognition','simInternship','simCourse','simVideo','simDocs'].forEach(id=>document.getElementById(id)?.addEventListener('change',updateSimulator));
  updateSimulator();
}
function updateSimulator(){
 const goal=document.getElementById('simGoal')?.value||state.goal;
 const ov={goal,languageReviewed:document.getElementById('simLanguage')?.checked||false,recognition:document.getElementById('simRecognition')?.checked||false,video:document.getElementById('simVideo')?.checked||false,docsComplete:document.getElementById('simDocs')?.checked||false,extras:extraCount()+(document.getElementById('simInternship')?.checked?1:0)+(document.getElementById('simCourse')?.checked?1:0)};
 const current=germanyReadinessScore(), future=germanyReadinessScore(ov), delta=future-current;
 const next=future>=80?'Strong scenario — likely ready for the next configured review.':future>=60?'Closer — the remaining pathway gates still matter.':'Core preparation is still needed before routing.';
 document.getElementById('simResult').innerHTML=`<div class="grid3"><div class="stat"><b>${current}</b><span>Current score</span></div><div class="stat"><b>${future}</b><span>Scenario score</span></div><div class="stat"><b>${delta>=0?'+':''}${delta}</b><span>Change</span></div></div><div class="notice" style="margin-top:10px">${esc(next)}</div><div class="guard-note" style="margin-top:9px">Simulator only — changing the scenario does not change the saved applicant profile.</div>`;
}

function pageProfile(){
 const p=state.profile;
 document.getElementById('app').innerHTML=`<div class="section-head"><div><span class="pill">STEP 2 · PROFILE</span><h2 style="margin-top:9px">Start with your goal and basic profile.</h2><p>Germany is the only destination. Add enough context so later qualification can use real pathway rules.</p></div></div><div class="grid2"><div class="card"><h3>What are you applying for?</h3><div class="goal-grid">${[['Study','University admission and study pathway.'],['Vocational Training','Vocational / Ausbildung pathway.'],['Employment','Employment and employer matching.']].map(([g,d])=>`<button class="goal ${state.goal===g?'selected':''}" onclick="selectGoal('${g}')"><strong>${g}</strong><span>${d}</span></button>`).join('')}</div><h4>Destination</h4><div class="stat" style="display:flex;align-items:center;gap:10px"><span style="font-size:18px">🇩🇪</span><div><b style="font-size:11px">Germany</b><span>Only destination in this prototype</span></div><span class="pill green" style="margin-left:auto">Selected</span></div><h4>Personal profile</h4><div class="form-grid"><div class="field"><label>Full name</label><input class="input" value="${esc(p.name)}" oninput="setProfile('name',this.value)"></div><div class="field"><label>Email</label><input class="input" type="email" value="${esc(p.email)}" oninput="setProfile('email',this.value)"></div><div class="field"><label>Phone</label><input class="input" value="${esc(p.phone)}" oninput="setProfile('phone',this.value)"></div><div class="field"><label>City</label><input class="input" value="${esc(p.city)}" oninput="setProfile('city',this.value)"></div><div class="field"><label>Target field / occupation</label><input class="input" value="${esc(p.field)}" oninput="setProfile('field',this.value)"></div><div class="field"><label>Years of experience</label><input class="input" value="${esc(p.experienceYears)}" oninput="setProfile('experienceYears',this.value)"></div><div class="field"><label>Highest education</label><input class="input" value="${esc(p.education)}" oninput="setProfile('education',this.value)"></div><div class="field"><label>Graduation year</label><input class="input" value="${esc(p.graduation)}" oninput="setProfile('graduation',this.value)"></div><div class="field"><label>Language level</label><select class="select" onchange="setProfile('languageLevel',this.value)"><option value="">Not assessed</option>${['A1','A2','B1','B2','C1','C2'].map(x=>`<option ${p.languageLevel===x?'selected':''}>${x}</option>`).join('')}</select></div>${state.goal==='Study'?`<div class="field"><label>Study language</label><select class="select" onchange="setProfile('studyLanguage',this.value)"><option ${p.studyLanguage==='Not sure'?'selected':''}>Not sure</option><option ${p.studyLanguage==='German-taught'?'selected':''}>German-taught</option><option ${p.studyLanguage==='English-taught'?'selected':''}>English-taught</option></select></div>`:''}<div class="field full"><label>Current / most recent role</label><input class="input" value="${esc(p.experienceRole)}" oninput="setProfile('experienceRole',this.value)"></div><div class="field full"><label>Availability</label><input class="input" value="${esc(p.availability)}" oninput="setProfile('availability',this.value)"></div></div></div><div class="card"><h3>Profile completeness</h3>${profileChecklistHTML()}<div class="line"></div><div class="stat"><b>${profilePercent()}%</b><span>Profile complete</span></div><div class="guard-note" style="margin-top:10px">Language level is used as evidence context, not as a universal legal threshold for every employment route.</div><div class="actions"><button class="btn primary" onclick="completeProfile()">Save profile & continue →</button></div></div></div>`;
}

function pageEvidence(){
 const coreDocs=[['Degree / education certificate','Education evidence','required',state.checks.education],['Experience letter','Role, employer and dates','required',state.checks.experience],['Language certificate','Language level evidence','required',state.checks.language],['Existing CV','Current resume','supporting',!!state.evidence.documents.find(x=>x.category==='cv'||x.type==='CV')]];
 document.getElementById('app').innerHTML=`<div class="section-head"><div><span class="pill">STEP 3 · EVIDENCE LOCKER</span><h2 style="margin-top:9px">Build a complete evidence locker.</h2><p>Every important claim should have a document, a review status, or an explicit applicant-provided label.</p></div><span class="pill blue">${evidenceCount()} ITEMS</span></div><div class="grid2"><div><div class="card"><h3>Core evidence</h3><div class="doc-list">${coreDocs.map((d,i)=>`<div class="doc"><div class="doc-icon">${i+1}</div><div class="doc-main"><b>${d[0]}</b><span>${d[1]} · ${d[2]} evidence</span></div><span class="status ${d[3]?'verified':'pending'}">${d[3]?'✓ Ready':'Add evidence'}</span></div>`).join('')}</div><div class="upload-area" style="margin-top:11px"><b style="font-size:11px">Add documents</b><div class="muted" style="margin:5px 0 10px">PDF, image, DOCX — the prototype keeps file names and simulates document intelligence.</div><label class="upload-btn" for="fileInput">＋ Choose files</label><input id="fileInput" type="file" multiple accept=".pdf,.png,.jpg,.jpeg,.doc,.docx" onchange="handleFiles(this.files)"></div></div><div class="card" style="margin-top:14px"><h3>Extra evidence</h3>${extraEvidenceRows()}<div class="line"></div><p class="small">Internships, extra courses, projects, certifications, awards and volunteering strengthen role fit and resume quality. They do not replace mandatory gates.</p></div></div><div><div class="card"><div style="display:flex;justify-content:space-between;align-items:center;gap:10px"><h3>Smart Document Intelligence</h3><span class="pill ai">AI + HUMAN REVIEW</span></div>${smartDocListHTML()}</div><div class="card" style="margin-top:12px"><h3>Document review checks</h3>${['Qualification titles are readable','Language proof is identifiable'].map((x,i)=>`<label class="check"><input type="checkbox" ${[state.checks.education,state.checks.language][i]?'checked':''} onchange="toggleCheck('${['education','language'][i]}',this.checked)">${x}</label>`).join('')}<div class="actions"><button class="btn primary" ${evidenceCount()?'':'disabled'} onclick="analyzeEvidence()">Run Smart Document Intelligence →</button></div></div></div></div>`;
}
function analyzeEvidence(){smartDocumentIntelligence();state.checks.documentCompleteness=missingCoreFiles().length===0;state.protection.evidenceReview=true;log('Evidence review completed');safeSave();go('video')}

function standardsCardHTML(){return `<div class="standard-card"><div class="std-row"><div><b>Study</b><span>University entrance qualification, admission/programme fit, and language proof required by the programme; visa routes can also require financial resources.</span></div><span class="pill blue">Study</span></div><div class="std-row"><div><b>Vocational Training</b><span>Education/training evidence plus German language; B1 is commonly used for vocational-training visa routes, with route-specific exceptions and training-provider assessment possible.</span></div><span class="pill blue">Training</span></div><div class="std-row"><div><b>Employment</b><span>Role/experience fit and recognition/comparability depend on the occupation and route. Regulated professions generally require recognition or professional authorisation.</span></div><span class="pill blue">Work</span></div><div class="guard-note" style="margin-top:9px">Reference points: German Federal Government “Make it in Germany” guidance. Exact legal/admission requirements vary by programme, occupation, nationality and residence route.</div></div>`}

function pageQualification(){
  const q=state.qualification;const rules=buildQualification();const tone=!q?'warn':q.status==='QUALIFIED'?'good':q.status==='NEEDS EVIDENCE'?'warn':'bad';
  document.getElementById('app').innerHTML=`<div class="section-head"><div><span class="pill">STEP 5 · QUALIFICATION</span><h2 style="margin-top:9px">Germany readiness + explainable qualification</h2><p>Score for preparation; gates for qualification. One never silently replaces the other.</p></div><div style="display:flex;gap:8px"><button class="btn secondary" onclick="openWhyNotEligible()">Why am I not eligible?</button><button class="btn secondary" onclick="openWhatIf()">What-if career simulator</button></div></div><div style="margin-bottom:14px">${readinessCardHTML()}</div><div class="gate"><div class="gate-card"><h3>Mandatory qualification gates</h3>${rules.map(r=>`<div class="rule"><div class="rule-main"><b>${esc(r.label)}</b><span>${esc(r.detail)}</span></div><div style="display:flex;align-items:center;gap:7px"><span class="status ${r.pass?'verified':'blocked'}">${r.pass?'✓ Pass':'! Gap'}</span>${!r.pass&&['recognition','pathwayFit','consistency','language'].includes(r.key)?`<button class="btn secondary" style="padding:5px 8px;font-size:8px" onclick="confirmGate('${r.key}')">Review</button>`:''}</div></div>`).join('')}<div class="actions"><button class="btn primary" onclick="runQualification()">${q?'Run again':'Run qualification check'} ↻</button></div><p class="footer-note">This prototype does not issue a legal eligibility decision. It applies configured rules and shows missing evidence.</p></div><div class="result ${tone}"><span class="pill ${q?.status==='QUALIFIED'?'green':q?.status==='BLOCKED'?'red':'amber'}">${q?'RESULT':'BEFORE CHECK'}</span><h2>${q?q.status:'Ready to evaluate'}</h2><p>${q?q.status==='QUALIFIED'?'All configured mandatory gates are satisfied for the selected prototype route.':q.status==='NEEDS EVIDENCE'?'The applicant may be suitable, but some gates still need evidence or review.':'The current evidence is not sufficient for a qualified outcome.':'The engine checks pathway, evidence, language, recognition and consistency.'}</p><div class="scorebar"><i style="width:${q?.score||0}%"></i></div><div class="muted" style="color:#c2cad8;margin-top:6px">Mandatory gate completion · ${q?.score||0}%</div><div class="criteria"><div class="stat"><b>${extraCount()}</b><span>Extra evidence</span></div><div class="stat"><b>${verifiedExtras()}</b><span>Reviewed extras</span></div></div>${q?.missing?.length?`<div style="margin-top:14px"><b style="font-size:9px;color:#ffd6d6">Why it is not ready</b>${q.missing.map(m=>`<div style="font-size:9px;color:#f2c7c7;margin-top:5px">• ${esc(m.label)}</div>`).join('')}</div>`:''}</div></div><div class="section-head"><div><h2>Standards used in this prototype</h2><p>These are reference rules, not a substitute for an official decision.</p></div></div>${standardsCardHTML()}<div class="section-head"><div><h2>Germany practical readiness</h2><p>These improve preparedness but are not legal eligibility gates.</p></div></div><div class="grid3"><label class="check card"><input type="checkbox" ${state.practical.accommodation?'checked':''} onchange="setPractical('accommodation',this.checked)"> I have thought through accommodation / relocation.</label><label class="check card"><input type="checkbox" ${state.practical.financialPlan?'checked':''} onchange="setPractical('financialPlan',this.checked)"> I have a financial plan for the next step.</label><label class="check card"><input type="checkbox" ${state.practical.insuranceAwareness?'checked':''} onchange="setPractical('insuranceAwareness',this.checked)"> I understand health / insurance planning.</label><label class="check card"><input type="checkbox" ${state.practical.pathwayResearch?'checked':''} onchange="setPractical('pathwayResearch',this.checked)"> I understand my chosen Germany pathway.</label></div>`;
}

function pageOutreach(){
  const p=state.protection;const canSend=p.identity&&p.evidenceReview&&p.consent;
  const stage=state.educaroForwarded?4:(state.outreachSent?2:1);
  const companies=[['Example IT Partner','Technology','Demo-only match preview for the selected field.'],['Example Training Partner','Vocational training','Demo-only partner preview.'],['Example Services Employer','Services','Demo-only match preview.']];
  document.getElementById('app').innerHTML=`<div class="section-head"><div><span class="pill">STEP 8 · EDUCARO ROUTING</span><h2 style="margin-top:9px">Educaro receives the application first.</h2><p>The applicant does not contact companies directly. Educaro reviews and routes the approved profile to suitable employers / training partners.</p></div><span class="pill blue">EDUCARO FIRST</span></div><div class="route-track"><div class="track done"><b>1 · Applicant</b><span>Profile + resume approved</span></div><div class="track ${stage>=2?'done':'active'}"><b>2 · Educaro</b><span>Receive + review</span></div><div class="track ${stage>=4?'done':'active'}"><b>3 · Company</b><span>Matched company receives profile</span></div><div class="track ${state.interviewOffer?'done':''}"><b>4 · Interview</b><span>Reply → extract → notify</span></div></div><div class="grid2"><div><div class="card"><h3>Multi-layer outbound protection</h3><p class="small">These checks are required before the application can leave the applicant workflow.</p><label class="check"><input type="checkbox" ${p.identity?'checked':''} onchange="setProtection('identity',this.checked)"><b>Layer 1:</b>&nbsp; I confirm my identity and contact details.</label><label class="check"><input type="checkbox" ${p.evidenceReview?'checked':''} onchange="setProtection('evidenceReview',this.checked)"><b>Layer 2:</b>&nbsp; I reviewed the evidence and qualification result.</label><label class="check"><input type="checkbox" ${p.consent?'checked':''} onchange="setProtection('consent',this.checked)"><b>Layer 3:</b>&nbsp; I consent to sending my profile to Educaro Deutschland GmbH.</label><div class="guard-note" style="margin-top:10px">Layer 4 is the simulated Educaro review. Interview monitoring remains locked until Educaro forwards the profile.</div><div class="actions">${!state.outreachSent?`<button class="btn primary" ${canSend?'':'disabled'} onclick="sendToEducaro()">Approve & send to Educaro →</button>`:!state.educaroForwarded?`<button class="btn primary" onclick="sendToEducaro()">Simulate Educaro review + forwarding →</button>`:`<button class="btn primary" onclick="go('interview')">Monitor company replies →</button>`}</div></div><div class="email" style="margin-top:12px"><b>Email destination: Educaro Deutschland GmbH</b><div class="line"></div><b>Subject:</b> ${esc(state.goal)} application — ${esc(state.profile.name||'Applicant')}<br><br>Hello Educaro Deutschland GmbH,<br><br>I am applying for a ${esc((state.goal||'Germany').toLowerCase())} opportunity in Germany. My evidence-backed profile and resume are ready. Please review my profile and route it to suitable employers / training partners in your network.<br><br>Regards,<br>${esc(state.profile.name||'Applicant')}</div></div><div><div class="card"><h3>Matched company previews</h3><p class="muted">Demo-only examples. Production would use connected Educaro/company data.</p><div class="company-list">${companies.map(c=>`<div class="company"><div class="company-top"><div><b>${c[0]}</b><span>${c[1]}</span></div><span class="pill ${state.educaroForwarded?'green':'blue'}">${state.educaroForwarded?'ROUTED':'MATCH PREVIEW'}</span></div><p>${c[2]}</p></div>`).join('')}</div></div><div class="card" style="margin-top:12px"><h3>Protection status</h3>${[['Identity confirmed',p.identity],['Evidence reviewed',p.evidenceReview],['Consent given',p.consent],['Educaro forwarded',state.educaroForwarded]].map(x=>`<div class="rule"><div class="rule-main"><b>${x[0]}</b></div><span class="status ${x[1]?'verified':'pending'}">${x[1]?'✓':'Pending'}</span></div>`).join('')}</div></div></div>`;
}
function sendToEducaro(){
  const p=state.protection;
  if(!state.outreachSent){
    if(!(p.identity&&p.evidenceReview&&p.consent)){openProtectionCenter();toast('Complete all applicant-side protection layers first');return}
    state.outreachSent=true;state.protection.evidenceReview=true;log('Application approved and sent to Educaro Deutschland GmbH');safeSave();render();toast('Application sent to Educaro');return;
  }
  if(!state.educaroForwarded){state.educaroForwarded=true;state.protection.educaroReview=true;log('Educaro review simulated: profile forwarded to matched company');safeSave();render();toast('Educaro forwarded the profile to a matched company');return}
  go('interview');
}

function openVirtualInterview(){
  state.virtualInterview.started=true;state.virtualInterview.questionIndex=state.virtualInterview.questionIndex||0;state.virtualInterview.answers=state.virtualInterview.answers||[];safeSave();renderVirtualInterviewModal();
}
let viStream=null;
async function startVICamera(){
  try{
    if(!navigator.mediaDevices?.getUserMedia){toast('Camera is not available in this browser preview');return}
    viStream=await navigator.mediaDevices.getUserMedia({video:true,audio:false});
    state.virtualInterview.cameraUsed=true; const v=document.getElementById('viCamera'); if(v){v.srcObject=viStream;v.style.display='block';const ph=document.getElementById('viCameraPlaceholder');if(ph)ph.style.display='none'};
    safeSave();
  }catch(e){toast('Camera permission was not granted — interview practice can continue without camera')}
}
function stopVICamera(){if(viStream){viStream.getTracks().forEach(t=>t.stop());viStream=null}const v=document.getElementById('viCamera');if(v){v.srcObject=null;v.style.display='none'}const ph=document.getElementById('viCameraPlaceholder');if(ph)ph.style.display='block';}
function saveVIAnswer(){
  const a=document.getElementById('viAnswer')?.value.trim()||'';
  const i=state.virtualInterview.questionIndex||0;
  state.virtualInterview.answers[i]=a;
  state.virtualInterview.questionIndex=i+1;
  safeSave(); renderVirtualInterviewModal();
}
function renderVirtualInterviewModal(){
  const qs=['Tell us about yourself and why you want to pursue this path in Germany.','Why did you choose this target field or role?','Describe one project, course or internship that shows relevant skills.','Tell us about a challenge you handled and what you learned from it.','What do you want to achieve in the next 12 months in Germany?'];
  const i=state.virtualInterview.questionIndex||0;
  if(i>=qs.length){
    const answers=state.virtualInterview.answers||[];const strengths=[];
    if(answers.filter(a=>a&&a.length>60).length>=4)strengths.push('Answers are detailed and structured');
    if(answers.some(a=>/project|internship|course|certificate/i.test(a||'')))strengths.push('Uses concrete evidence from the profile');
    if(answers.some(a=>/why|goal|motivat/i.test(a||'')))strengths.push('Explains motivation clearly');
    const score=Math.min(100,45+strengths.length*15+answers.filter(a=>a&&a.length>100).length*5);
    state.virtualInterview.completed=true;state.virtualInterview.score=score;state.virtualInterview.feedback=strengths;safeSave();stopVICamera();
    openModal('Virtual Interview Results',`<div class="grid3"><div class="stat"><b>${score}%</b><span>Practice score</span></div><div class="stat"><b>${answers.filter(Boolean).length}/5</b><span>Answered</span></div><div class="stat"><b>${strengths.length}</b><span>Coach strengths</span></div></div><div class="card" style="margin-top:12px"><h3>Coach feedback</h3>${strengths.length?strengths.map(x=>`<div class="rule"><div class="rule-main"><b>✓ ${esc(x)}</b></div><span class="status verified">Strength</span></div>`).join(''):'<p class="small">Use specific examples, measurable outcomes and evidence from your courses, internships, projects or work experience.</p>'}</div><div class="guard-note" style="margin-top:10px">Virtual interview scoring is practice feedback only. It is not a hiring decision and is not shared externally by this prototype.</div>`,`<button class="btn primary" onclick="closeModal();render()">Back to interview</button>`);return;
  }
  const previous=state.virtualInterview.answers[i]||'';
  openModal('Virtual Interview Practice',`<span class="pill blue">QUESTION ${i+1} OF ${qs.length}</span><div class="question-box" style="margin-top:10px"><h4>${esc(qs[i])}</h4><p>Recommended answer time: ~90 seconds. Use concrete examples from your evidence.</p><textarea id="viAnswer" class="textarea" placeholder="Type your answer here...">${esc(previous)}</textarea></div><div class="camera-wrap" style="margin-top:10px"><video id="viCamera" autoplay muted playsinline></video><div id="viCameraPlaceholder" class="camera-placeholder">Camera is optional.<br>Use it for a more realistic interview practice session.</div></div><div class="interview-toolbar"><button class="btn secondary" onclick="startVICamera()">Enable camera</button><button class="btn secondary" onclick="stopVICamera()">Stop camera</button><span class="pill" style="margin-left:auto">Profile evidence available: ${extraCount()+ (state.evidence.documents?.length||0)}</span></div>`,`<button class="btn secondary" onclick="closeModal();stopVICamera()">Exit practice</button><button class="btn primary" onclick="saveVIAnswer()">${i===qs.length-1?'Finish interview':'Next question'} →</button>`);
}

function pageInterview(){
  if(!state.educaroForwarded){document.getElementById('app').innerHTML=`<div class="card"><span class="pill amber">WAITING FOR EDUCARO</span><h2 style="margin:10px 0 6px">Interview monitoring is not active yet.</h2><p class="small">Monitoring starts only after Educaro has forwarded the approved profile to a matched company. You can still use Magnus for missing files and standards guidance.</p><div class="actions"><button class="btn primary" onclick="go('outreach')">Go to Educaro routing →</button></div></div>`;return}
  const offer=state.interviewOffer;const reply=offer?`Subject: Interview invitation — ${state.profile.field||'Target role'}\n\nHello ${state.profile.name||'Applicant'},\n\nThank you for your application. We would like to invite you to an interview.\n\nDate: 15 October 2026\nTime: 11:00 CET\nFormat: Online\n\nBest regards,\nHiring Team`:`Subject: Your application\n\nThank you for your application. Our team is reviewing your profile. We will contact Educaro / the candidate with next steps.`;
  document.getElementById('app').innerHTML=`<div class="section-head"><div><span class="pill">STEP 9 · INTERVIEW</span><h2 style="margin-top:9px">Company response + virtual interview.</h2><p>Interview monitoring extracts date, time, timezone and format. The virtual room lets the applicant practise with profile evidence.</p></div><span class="pill ${offer?'green':'blue'}">${offer?'INTERVIEW DETECTED':'MONITORING ACTIVE'}</span></div><div class="interview-grid"><div class="reply"><h3>Company reply</h3><pre>${esc(reply)}</pre><div class="actions"><button class="btn primary" onclick="simulateInterview()">${offer?'Refresh interview offer':'Simulate interview offer'}</button></div></div><div><div class="card"><h3>Extracted details</h3><div class="extract"><div class="stat"><span>Date</span><b>${offer?'15 Oct 2026':'—'}</b></div><div class="stat"><span>Time</span><b>${offer?'11:00 CET':'—'}</b></div><div class="stat"><span>Format</span><b>${offer?'Online':'—'}</b></div><div class="stat"><span>Role</span><b>${offer?esc(state.profile.field||'Target role'):'—'}</b></div></div></div>${offer?`<div class="notice" style="margin-top:12px">✓ Interview details are ready. Notification status: <b>${state.notified?'Sent':'Pending'}</b></div>`:''}</div></div><div class="grid2" style="margin-top:14px"><div class="card"><h3>Virtual interview room</h3><p class="small">Five questions, optional camera, evidence-aware coaching and a practice score.</p><div class="grid3" style="margin-top:10px"><div class="stat"><b>${state.virtualInterview.completed?state.virtualInterview.score+'%':'Ready'}</b><span>Practice score</span></div><div class="stat"><b>${state.evidence.internships.length}</b><span>Internships used</span></div><div class="stat"><b>${state.evidence.projects.length}</b><span>Projects used</span></div></div><div class="actions"><button class="btn primary" onclick="openVirtualInterview()">${state.virtualInterview.completed?'Practice again':'Start virtual interview'} →</button></div></div><div class="card"><h3>Applicant notification</h3><p class="small">${state.notified?'The applicant has been notified with the extracted interview date, time and format.':'After an interview invitation is detected, the system prepares the applicant notification.'}</p>${offer&&!state.notified?'<button class="btn primary" onclick="notifyApplicant()">Send applicant notification</button>':''}</div></div><div class="card" style="margin-top:14px"><h3>Journey chain</h3>${[['Applicant approved',state.outreachSent],['Educaro received',state.outreachSent],['Educaro forwarded',state.educaroForwarded],['Company reply detected',offer],['Applicant notified',state.notified]].map(x=>`<div class="rule"><div class="rule-main"><b>${x[0]}</b></div><span class="status ${x[1]?'verified':'pending'}">${x[1]?'✓':'Pending'}</span></div>`).join('')}</div>`;
}

function render(){
  ensureFeatureState();
  nav();stepper();header();
  const fn={start:pageStart,profile:pageProfile,evidence:pageEvidence,video:pageVideo,qualification:pageQualification,next:pageNext,resume:pageResume,outreach:pageOutreach,interview:pageInterview}[state.current]||pageStart;
  fn();
  updateRoboFab();
}

render();


/* =========================================================
   FINAL POLISH PATCH — smooth first-load, real selectors,
   Magnus image assistant, start-page virtual interview
   ========================================================= */
const FIELD_OPTIONS = [
  'Information Technology & Software', 'Engineering & Manufacturing', 'Healthcare & Nursing',
  'Business & Finance', 'Science & Research', 'Hospitality & Tourism', 'Logistics & Supply Chain',
  'Construction & Skilled Trades', 'Education', 'Design & Media', 'Other'
];
const OCCUPATION_OPTIONS = [
  'Software Engineer', 'Data Analyst', 'Data Scientist', 'Cybersecurity Specialist', 'IT Support Specialist',
  'Mechanical Engineer', 'Electrical Engineer', 'Civil Engineer', 'Automation / Mechatronics Technician',
  'Registered Nurse', 'Healthcare Assistant', 'Pharmacist', 'Business Analyst', 'Accountant / Finance Analyst',
  'Research Assistant', 'Hotel / Hospitality Professional', 'Logistics Coordinator', 'Electrician / Skilled Technician',
  'Teacher / Education Professional', 'Graphic / UX Designer', 'Other'
];
const AVAILABILITY_OPTIONS = ['Immediately', 'Within 2 weeks', 'Within 30 days', 'Within 60 days', 'Within 90 days', 'Not sure yet'];

function ensureFinalProfileState(){
  state.profile = state.profile || {};
  if(typeof state.profile.occupation !== 'string') state.profile.occupation='';
  if(typeof state.profile.field !== 'string') state.profile.field='';
  if(typeof state.profile.availability !== 'string') state.profile.availability='';
}
ensureFinalProfileState();
// Always reopen a fresh browser session on the first screen, while preserving the saved journey data.
state.current='start';
safeSave();

function finalHasProfile(){
  const p=state.profile;
  return state.germany && !!state.goal && !!p.name && !!p.email && !!p.field && !!p.occupation && !!p.education;
}
hasProfile = finalHasProfile;

function finalProfilePercent(){
  const p=state.profile;
  const arr=[p.name,p.email,p.city,p.field,p.occupation,p.education,p.graduation,p.experienceRole,p.availability];
  return Math.round(arr.filter(Boolean).length/arr.length*100);
}
profilePercent = finalProfilePercent;

function finalProfileChecklistHTML(){
  const items=[
    ['Name',!!state.profile.name],['Email',!!state.profile.email],['Goal',!!state.goal],
    ['Target field',!!state.profile.field],['Target occupation',!!state.profile.occupation],
    ['Education',!!state.profile.education],['Experience context',!!state.profile.experienceRole],['City',!!state.profile.city]
  ];
  return items.map(([a,b])=>`<div class="rule"><div class="rule-main"><b>${a}</b><span>${b?'Provided':'Still needed'}</span></div><span class="status ${b?'verified':'blocked'}">${b?'✓':'!'}</span></div>`).join('');
}
profileChecklistHTML = finalProfileChecklistHTML;

function finalPageProfile(){
 const p=state.profile;
 const opt=(items,current,empty='Select...')=>`<option value="" ${!current?'selected':''}>${empty}</option>${items.map(x=>`<option value="${esc(x)}" ${current===x?'selected':''}>${esc(x)}</option>`).join('')}`;
 document.getElementById('app').innerHTML=`<div class="section-head"><div><span class="pill">STEP 2 · PROFILE</span><h2 style="margin-top:9px">Start with your goal and basic profile.</h2><p>Germany is the only destination. Select a clear target so the system can use the right qualification pathway.</p></div><button class="btn secondary" onclick="openHelpDesk()">🤖 Ask Magnus</button></div>
 <div class="grid2"><div class="card"><h3>What are you applying for?</h3><div class="goal-grid">${[['Study','University admission and study pathway.'],['Vocational Training','Vocational / Ausbildung pathway.'],['Employment','Employment and employer matching.']].map(([g,d])=>`<button class="goal ${state.goal===g?'selected':''}" onclick="selectGoal('${g}')"><strong>${g}</strong><span>${d}</span></button>`).join('')}</div>
 <h4>Destination</h4><div class="stat" style="display:flex;align-items:center;gap:10px"><span style="font-size:18px">🇩🇪</span><div><b style="font-size:11px">Germany</b><span>Only destination in this prototype</span></div><span class="pill green" style="margin-left:auto">Selected</span></div>
 <h4>Personal profile</h4><div class="form-grid">
 <div class="field"><label>Full name</label><input class="input" value="${esc(p.name)}" oninput="setProfile('name',this.value)" placeholder="e.g. Aarav Sharma"></div>
 <div class="field"><label>Email</label><input class="input" type="email" value="${esc(p.email)}" oninput="setProfile('email',this.value)" placeholder="name@example.com"></div>
 <div class="field"><label>Phone</label><input class="input" value="${esc(p.phone)}" oninput="setProfile('phone',this.value)" placeholder="+91..."></div>
 <div class="field"><label>City</label><input class="input" value="${esc(p.city)}" oninput="setProfile('city',this.value)" placeholder="Bengaluru, India"></div>
 <div class="field"><label>Target field</label><select class="select" onchange="setProfile('field',this.value);render()">${opt(FIELD_OPTIONS,p.field,'Select target field')}</select></div>
 <div class="field"><label>Target occupation</label><select class="select" onchange="setProfile('occupation',this.value);render()">${opt(OCCUPATION_OPTIONS,p.occupation,'Select target occupation')}</select></div>
 <div class="field"><label>Years of experience</label><input class="input" value="${esc(p.experienceYears)}" oninput="setProfile('experienceYears',this.value)" placeholder="e.g. 1.5"></div>
 <div class="field"><label>Highest education</label><input class="input" value="${esc(p.education)}" oninput="setProfile('education',this.value)" placeholder="B.E. Computer Science"></div>
 <div class="field"><label>Graduation year</label><input class="input" value="${esc(p.graduation)}" oninput="setProfile('graduation',this.value)" placeholder="2025"></div>
 <div class="field"><label>Current / most recent role</label><input class="input" value="${esc(p.experienceRole)}" oninput="setProfile('experienceRole',this.value)" placeholder="Software Engineer"></div>
 <div class="field"><label>Availability</label><select class="select" onchange="setProfile('availability',this.value);render()">${opt(AVAILABILITY_OPTIONS,p.availability,'Select availability')}</select></div>
 <div class="field"><label>Language level</label><select class="select" onchange="setProfile('languageLevel',this.value);render()"><option value="" ${!p.languageLevel?'selected':''}>Not provided</option>${['A1','A2','B1','B2','C1','C2'].map(x=>`<option value="${x}" ${p.languageLevel===x?'selected':''}>${x}</option>`).join('')}</select></div>
 <div class="field"><label>Study language (for Study)</label><select class="select" onchange="setProfile('studyLanguage',this.value);render()">${['Not sure','German-taught','English-taught'].map(x=>`<option value="${x}" ${p.studyLanguage===x?'selected':''}>${x}</option>`).join('')}</select></div>
 ${state.goal==='Employment'?`<div class="field full"><label>Recognition / profession route reviewed?</label><select class="select" onchange="setProfile('recognitionReviewed',this.value==='yes');render()"><option value="no" ${!p.recognitionReviewed?'selected':''}>Not reviewed yet</option><option value="yes" ${p.recognitionReviewed?'selected':''}>Reviewed / route identified</option></select></div>`:''}
 </div></div>
 <div><div class="card"><h3>Profile completeness</h3>${profileChecklistHTML()}<div class="line"></div><div class="stat"><b>${profilePercent()}%</b><span>Profile complete</span></div><div class="actions"><button class="btn primary" onclick="completeProfile()">Save profile & continue →</button></div></div><div class="card" style="margin-top:12px"><h3>Pathway context</h3><p class="small">${esc(profileLanguageRule())}</p><p class="footer-note">The app uses this to explain readiness; final requirements remain programme-, occupation- and case-specific.</p></div></div></div>`;
}
pageProfile = finalPageProfile;

function finalCompleteProfile(){
  const p=state.profile;
  const required=[['goal',!!state.goal,'Choose a pathway first.'],['name',!!p.name,'Add your full name.'],['email',!!p.email,'Add your email.'],['field',!!p.field,'Choose your target field.'],['occupation',!!p.occupation,'Choose your target occupation.'],['education',!!p.education,'Add your highest education.']];
  const missing=required.filter(x=>!x[1]);
  if(missing.length){
    toast(missing[0][2]);
    const first=missing[0][0];
    const el=document.querySelector(`[oninput*="'${first}'"], [onchange*="'${first}'"]`);
    if(el){el.focus();el.classList.add('input-error');setTimeout(()=>el.classList.remove('input-error'),1100)}
    return;
  }
  log('Profile completed'); go('evidence');
}
completeProfile = finalCompleteProfile;

const oldRegulatedHint = regulatedHint;
regulatedHint = function(){
  const f=((state.profile.field||'')+' '+(state.profile.occupation||'')).toLowerCase();
  return ['doctor','physician','nurse','nursing','teacher','lawyer','pharmacist','dentist','psychologist','architect'].some(x=>f.includes(x));
};

/* Fix the first-screen practice interview: it is independent of journey unlocks. */
function finalOpenVirtualInterview(){
  ensureFinalProfileState();
  state.virtualInterview={started:true,questionIndex:0,answers:[],completed:false,score:0,feedback:[],cameraUsed:false};
  safeSave();
  renderVirtualInterviewModal();
}
openVirtualInterview = finalOpenVirtualInterview;

function finalRenderVirtualInterviewModal(){
  const qs=[
    'Tell us about yourself and why you want to pursue your chosen path in Germany.',
    'Why did you choose your target field and occupation?',
    'Describe one project, course or internship that shows your relevant skills.',
    'Tell us about a challenge you handled and what you learned from it.',
    'What do you want to achieve in the next 12 months in Germany?'
  ];
  const i=state.virtualInterview.questionIndex||0;
  if(i>=qs.length){
    const answers=state.virtualInterview.answers||[]; const strengths=[];
    if(answers.filter(a=>a&&a.length>60).length>=4) strengths.push('Answers are detailed and structured');
    if(answers.some(a=>/project|internship|course|certificate/i.test(a||''))) strengths.push('Uses concrete evidence');
    if(answers.some(a=>/why|goal|motivat/i.test(a||''))) strengths.push('Explains motivation');
    if(answers.some(a=>/Germany|germany/i.test(a||''))) strengths.push('Connects the answer to Germany');
    const score=Math.min(100,45+strengths.length*12+answers.filter(a=>a&&a.length>100).length*4);
    state.virtualInterview.completed=true; state.virtualInterview.score=score; state.virtualInterview.feedback=strengths; safeSave(); stopVICamera();
    openModal('Virtual Interview Results',`<div class="assistant-result-banner"><span class="pill purple">MAGNUS COACH</span><b>Your practice is complete.</b><span>This is preparation feedback, not a hiring decision.</span></div><div class="grid3" style="margin-top:12px"><div class="stat"><b>${score}%</b><span>Practice score</span></div><div class="stat"><b>${answers.filter(Boolean).length}/5</b><span>Questions answered</span></div><div class="stat"><b>${strengths.length}</b><span>Coach strengths</span></div></div><div class="card" style="margin-top:12px"><h3>Practice feedback</h3>${strengths.length?strengths.map(x=>`<div class="rule"><div class="rule-main"><b>✓ ${esc(x)}</b></div><span class="status verified">Strength</span></div>`).join(''):'<p class="small">Keep answers specific. Use examples from your courses, internships, projects and work experience.</p>'}</div>`,`<button class="btn secondary" onclick="closeModal();stopVICamera()">Close</button><button class="btn primary" onclick="closeModal();go('interview')">Open interview stage →</button>`); return;
  }
  const prev=state.virtualInterview.answers[i]||'';
  openModal('Virtual Interview Practice',`<div class="assistant-interviewer">${roboHTML('small')}<div><span class="pill blue">MAGNUS INTERVIEW COACH</span><h4 style="margin:7px 0 4px;font-size:12px">Question ${i+1} of ${qs.length}</h4><p class="small">Answer naturally. You can practice with or without your camera.</p></div></div><div class="question-box" style="margin-top:12px"><h4>${esc(qs[i])}</h4><p>Tip: use a simple structure — situation, what you did, and what you learned.</p><textarea id="viAnswer" class="textarea" placeholder="Type your answer here...">${esc(prev)}</textarea></div><div class="camera-wrap" style="margin-top:10px"><video id="viCamera" autoplay muted playsinline></video><div id="viCameraPlaceholder" class="camera-placeholder">Camera is optional.<br>Enable it for a more realistic practice session.</div></div><div class="interview-toolbar"><button class="btn secondary" onclick="startVICamera()">Enable camera</button><button class="btn secondary" onclick="stopVICamera()">Stop camera</button><span class="pill" style="margin-left:auto">Evidence available: ${extraCount()+(state.evidence.documents?.length||0)}</span></div>`,`<button class="btn secondary" onclick="closeModal();stopVICamera()">Exit practice</button><button class="btn primary" onclick="submitVirtualAnswer()">${i===qs.length-1?'Finish practice':'Next question →'}</button>`);
}
renderVirtualInterviewModal = finalRenderVirtualInterviewModal;

/* Magnus: use the exact user-provided robot image inside the assistant popup. */
function finalOpenHelpDesk(){
  const missing=missingCoreFiles();
  const context=STEPS[currentIndex()]?.short||'Start';
  const readiness=germanyReadinessScore();
  const q=state.qualification;
  const message=missing.length?`I found ${missing.length} core evidence gap${missing.length>1?'s':''}. I will keep the qualification from passing until those gaps are resolved.`:'No core evidence gaps are currently detected.';
  const missingHtml=missing.length?missing.map(m=>`<div class="assistant-missing"><b>${esc(m.label)}</b><span>${esc(m.detail)}</span></div>`).join(''):'<div class="greenflag">✓ Core evidence looks complete for the current pathway.</div>';
  openModal('Magnus AI Help Desk',`<div class="assistant-head">${roboHTML('large')}<div><span class="pill purple">MAGNUS AI</span><h3 style="margin:7px 0 4px">Hi! I’m here to keep your Germany journey on track.</h3><p class="small">Current stage: <b>${esc(context)}</b> · Readiness: <b>${readiness}/100</b></p></div></div><div class="chat" style="margin-top:14px"><div class="chat-row"><div class="chat-bubble">🤖 ${esc(message)}</div></div><div class="chat-row"><div class="chat-bubble">You can ask me about qualification, missing evidence, the readiness score, what-if scenarios or interview practice.</div></div>${q?.missing?.length?`<div class="chat-row"><div class="chat-bubble">Your latest qualification check has <b>${q.missing.length}</b> unresolved gate${q.missing.length>1?'s':''}. I can explain each one.</div></div>`:''}</div>${missing.length?`<div style="margin-top:12px"><div class="missing-banner"><b>Missing evidence</b>${missingHtml}</div></div>`:''}<div class="grid3" style="margin-top:12px"><button class="btn secondary" onclick="openWhyNotEligible()">Why not eligible?</button><button class="btn secondary" onclick="openWhatIf()">What-if career</button><button class="btn secondary" onclick="closeModal();openMissingFilesQuick()">${missing.length?`Missing files (${missing.length})`:'Check files'}</button></div><div class="grid3" style="margin-top:9px"><button class="btn secondary" onclick="openProtectionCenter()">🛡 Protection</button><button class="btn secondary" onclick="closeModal();go('qualification')">Qualification</button><button class="btn secondary" onclick="closeModal();openVirtualInterview()">Practice interview</button></div>`,`<button class="btn primary" onclick="closeModal()">Done</button>`);
}
openHelpDesk = finalOpenHelpDesk;

/* A fresher start screen with the working practice interview button. */
function finalPageStart(){
 document.getElementById('app').innerHTML=`<section class="hero"><div><span class="pill dark">GERMANY ONLY · EVIDENCE-FIRST</span><h1>Build a <em>complete, qualified profile</em> for your Germany journey.</h1><p>One guided flow for profile, evidence, video, qualification and routing. Verified evidence stays separate from applicant-provided and AI-generated content.</p><div style="display:flex;gap:8px;margin-top:16px;flex-wrap:wrap"><button class="btn primary" onclick="go('profile')">Start application →</button><button class="btn secondary" onclick="openVirtualInterview()">🎤 Practice interview</button><button class="btn secondary" onclick="showHow()">How it works</button><button class="btn secondary" onclick="openWhatIf()">What-if simulator</button></div></div><div class="hero-right"><div class="big-ring"><div><strong>${germanyReadinessScore()}</strong><span>readiness / 100</span></div></div></div></section>
 <div class="section-head"><div><h2>Your smart workspace</h2><p>A guided, evidence-first journey with support at every step.</p></div><span class="pill blue">MAGNUS READY</span></div>
 <div class="grid3"><div class="card"><span class="pill">01 · PROFILE</span><h3 style="margin-top:12px">Choose your pathway.</h3><p class="small">Study, vocational training or employment. Germany is the only destination in this prototype.</p></div><div class="card"><span class="pill">02 · EVIDENCE</span><h3 style="margin-top:12px">Build your evidence locker.</h3><p class="small">Degrees, certificates, language proof, CVs, courses, internships, projects and more.</p></div><div class="card"><span class="pill">03 · SUPPORT</span><h3 style="margin-top:12px">Magnus is always one click away.</h3><p class="small">Missing files? Qualification gap? Interview practice? Open the assistant from the bottom-right corner.</p></div></div>
 <div class="grid2" style="margin-top:15px"><div>${readinessCardHTML()}</div><div class="card"><h3>Quick start</h3><div class="rule"><div class="rule-main"><b>Need to practise first?</b><span>Open the virtual interview without completing the journey.</span></div><button class="btn secondary" onclick="openVirtualInterview()">Start</button></div><div class="rule"><div class="rule-main"><b>Need help with files?</b><span>Magnus will show exactly what is missing.</span></div><button class="btn secondary" onclick="openHelpDesk()">Open</button></div><div class="rule"><div class="rule-main"><b>Want to understand qualification?</b><span>See the gates and recovery actions.</span></div><button class="btn secondary" onclick="go('qualification')">View</button></div></div></div>
 <div class="section-head"><div><h2>Current profile snapshot</h2><p>Saved information remains available, but a fresh browser open always starts here.</p></div></div><div class="grid3"><div class="stat"><b>${esc(state.profile.name||'Not entered')}</b><span>Applicant</span></div><div class="stat"><b>${esc(state.goal||'Choose a pathway')}</b><span>Goal</span></div><div class="stat"><b>${evidenceCount()}</b><span>Evidence items</span></div></div><div class="card" style="margin-top:15px"><h3>Journey activity</h3>${activityHTML()}</div>`;
}
pageStart = finalPageStart;

/* Smoothness: small entrance animation and clearer assistant modal. */

// Persist data, but never persist the open screen as the default entry point.
safeSave();
render();


/* Final navigation integrity patch */
function finalDone(i){
  if(i===0) return hasProfile();
  if(i===1) return hasProfile();
  if(i===2) return !!state.protection?.evidenceReview;
  if(i===3) return !!state.video.analyzed;
  if(i===4) return !!state.qualification;
  if(i===5) return !!state.qualification;
  if(i===6) return !!state.resumeApproved;
  if(i===7) return !!state.educaroForwarded;
  if(i===8) return !!state.notified;
  return false;
}
done = finalDone;

function finalUnlocked(id){
  if(id==='start') return true;
  if(state.current==='start' && id==='profile') return true;
  const idx=STEPS.findIndex(s=>s.id===id);
  if(idx<0) return false;
  for(let i=0;i<idx;i++){ if(!done(i)) return false; }
  return true;
}
unlocked = finalUnlocked;

function finalGo(id){
  if(id!=='start' && id!==state.current && !unlocked(id)){
    toast('Complete the previous step before opening this stage.');
    return;
  }
  state.current=id; safeSave(); render();
}
go = finalGo;

// Use the target occupation as part of pathway fit; it is a required selection, not just decoration.
function finalBuildQualification(){
  const mandatory=[];
  mandatory.push({key:'goal',label:'Pathway selected',detail:state.goal?'Goal is '+state.goal:'Choose study, vocational training or employment.',pass:!!state.goal});
  mandatory.push({key:'education',label:'Education / admission evidence',detail:state.goal==='Study'?'University entrance qualification and programme-admission evidence should be identifiable.':'Relevant education / qualification evidence must be identifiable and readable.',pass:state.checks.education||!!state.profile.education});
  if(state.goal==='Employment') mandatory.push({key:'experience',label:'Relevant experience evidence',detail:'Role, employer and dates should be supported or clearly applicant-provided.',pass:state.checks.experience});
  mandatory.push({key:'language',label:'Language requirement',detail:profileLanguageRequirementText(),pass:languagePass()});
  mandatory.push({key:'documentCompleteness',label:'Core evidence completeness',detail:'Required supporting inputs should be present.',pass:missingCoreFiles().length===0});
  if(state.goal==='Employment') mandatory.push({key:'recognition',label:'Recognition / comparability route',detail:regulatedHint()?'This may be a regulated profession: recognition / professional authorisation is a key requirement.':'For non-regulated professions, recognition is not universally mandatory; comparability/proof may still matter depending on the route.',pass:!!state.profile.recognitionReviewed});
  mandatory.push({key:'pathwayFit',label:'Pathway fit',detail:'The selected pathway, target field, target occupation and education should align.',pass:!!state.goal&&!!state.profile.field&&!!state.profile.occupation&&!!state.profile.education});
  return mandatory;
}
buildQualification = finalBuildQualification;

// A completed qualification unlocks the next-step router; a forwarded application unlocks interview monitoring.
function finalProgress(){
  return Math.round((STEPS.filter((_,i)=>done(i)).length/STEPS.length)*100);
}
progress = finalProgress;

// Correct step label for the 9-stage journey.

state.current='start'; safeSave(); render();


/* =========================================================
   ULTIMATE STABILITY + REAL-TIME VALIDATION PATCH
   - Invalid applicant data blocks progression
   - File uploads receive basic live plausibility checks
   - Qualification cannot pass from profile text alone
   - Magnus is a moving CSS character (no image)
   - Fresh browser opens always begin at Start while profile data remains saved
   ========================================================= */

const PROFILE_RULES = {
  name: v => !v ? 'Full name is required.' : !/^[A-Za-z][A-Za-z .\'-]{1,59}$/.test(v) ? 'Use a real name with letters, spaces, apostrophes or hyphens.' : '',
  email: v => !v ? 'Email is required.' : !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v) ? 'Enter a valid email address.' : '',
  phone: v => v && !/^\+?[0-9 ()-]{10,18}$/.test(v) ? 'Enter a valid phone number.' : '',
  city: v => !v ? 'City is required.' : v.trim().length<2 ? 'Enter a valid city.' : '',
  field: v => !v ? 'Select a target field.' : !FIELD_OPTIONS.includes(v) ? 'Choose a field from the list.' : '',
  occupation: v => !v ? 'Select a target occupation.' : !OCCUPATION_OPTIONS.includes(v) ? 'Choose an occupation from the list.' : '',
  education: v => !v ? 'Highest education is required.' : v.trim().length<3 ? 'Enter a valid education/qualification.' : '',
  graduation: v => !v ? 'Graduation year is required.' : !/^\d{4}$/.test(v) || +v<1950 || +v>new Date().getFullYear() ? 'Use a valid graduation year.' : '',
  experienceYears: v => v==='' ? 'Enter 0 if you have no experience.' : !/^\d+(\.\d{1,2})?$/.test(v) || +v<0 || +v>50 ? 'Enter experience from 0 to 50 years.' : '',
  experienceRole: v => state.goal==='Employment' && !v ? 'Current/most recent role is required for employment.' : '',
  availability: v => !v ? 'Select your availability.' : !AVAILABILITY_OPTIONS.includes(v) ? 'Choose an option from the list.' : ''
};

function profileValidationErrors(){
  const p=state.profile||{}; const out=[];
  Object.entries(PROFILE_RULES).forEach(([k,fn])=>{const err=fn(String(p[k]??'').trim());if(err)out.push({key:k,error:err})});
  if(state.goal==='Study' && !['Not sure','German-taught','English-taught'].includes(p.studyLanguage||'Not sure')) out.push({key:'studyLanguage',error:'Choose the study language option.'});
  return out;
}
function markField(el, key){
  if(!el)return;
  const err=(PROFILE_RULES[key]||(()=>''))(String(el.value||'').trim());
  el.classList.toggle('field-invalid',!!err); el.classList.toggle('field-valid',!err && !!el.value);
  let note=el.parentElement?.querySelector('.field-error');
  if(!note){note=document.createElement('span');note.className='field-error';el.parentElement?.appendChild(note)}
  note.textContent=err;
}
function validateProfileLive(){
  document.querySelectorAll('[data-profile-key]').forEach(el=>markField(el,el.getAttribute('data-profile-key')));
  const errors=profileValidationErrors(); const box=document.getElementById('profileValidation');
  if(box){box.className='validation-summary '+(errors.length?'bad':'good');box.innerHTML=errors.length?`<b>${errors.length} item${errors.length>1?'s':''} need attention.</b> ${esc(errors[0].error)} ${errors.length>1?`+ ${errors.length-1} more.`:''}`:'✓ Profile inputs look valid. You can continue to evidence review.';}
  return errors;
}
function finalHasProfileStrict(){return profileValidationErrors().length===0 && state.germany===true}
hasProfile = finalHasProfileStrict;

function finalSetProfile(k,v){
  state.profile[k]=v;
  safeSave();
  if(document.querySelector('[data-profile-key="'+k+'"]')) validateProfileLive();
}
setProfile = finalSetProfile;

function finalPageProfileValidated(){
  const p=state.profile;
  const opt=(items,current,empty='Select...')=>`<option value="" ${!current?'selected':''}>${empty}</option>${items.map(x=>`<option value="${esc(x)}" ${current===x?'selected':''}>${esc(x)}</option>`).join('')}`;
  const field = (key,label,type='input',extra='') => {
    const val=esc(p[key]??'');
    if(type==='select') return `<div class="field"><label>${label}</label><select class="select" data-profile-key="${key}" onchange="setProfile('${key}',this.value);validateProfileLive()" ${extra}>${val?`<option value="${val}" selected>${val}</option>`:''}</select><span class="field-error"></span></div>`;
    return `<div class="field${extra==='full'?' full':''}"><label>${label}</label><input class="input" data-profile-key="${key}" value="${val}" oninput="setProfile('${key}',this.value);markField(this,'${key}')" onblur="markField(this,'${key}')"><span class="field-error"></span></div>`;
  };
  document.getElementById('app').innerHTML=`
  <div class="section-head"><div><span class="pill">STEP 2 · PROFILE</span><h2 style="margin-top:9px">Tell us about the real applicant.</h2><p>Wrong, incomplete or implausible inputs are flagged immediately and cannot be used to unlock the next step.</p></div><button class="btn secondary" onclick="openHelpDesk()"><span class="robo-mini"><span class="robo-character"><span class="robo-glow"></span><span class="robo-head"><i class="robo-face-line"></i><i class="robo-eye left"></i><i class="robo-eye right"></i></span><span class="robo-body"><i class="robo-chest"></i></span><i class="robo-arm left"></i><i class="robo-arm right"><i class="robo-hand"></i></i></span></span> Ask Magnus</button></div>
  <div class="grid2"><div class="card">
    <h3>Pathway</h3><div class="goal-grid">${[['Study','University admission and study pathway.'],['Vocational Training','Vocational / Ausbildung pathway.'],['Employment','Employment and employer matching.']].map(([g,d])=>`<button class="goal ${state.goal===g?'selected':''}" onclick="selectGoal('${g}')"><strong>${g}</strong><span>${d}</span></button>`).join('')}</div>
    <h4>Destination</h4><div class="stat" style="display:flex;align-items:center;gap:10px"><span style="font-size:18px">🇩🇪</span><div><b style="font-size:11px">Germany</b><span>Only destination in this journey</span></div><span class="pill green" style="margin-left:auto">Selected</span></div>
    <h4>Applicant information</h4><div class="form-grid">
      ${field('name','Full name')}${field('email','Email')}${field('phone','Phone')}${field('city','City')}
      <div class="field"><label>Target field</label><select class="select" data-profile-key="field" onchange="setProfile('field',this.value);validateProfileLive()">${opt(FIELD_OPTIONS,p.field,'Select target field')}</select><span class="field-error"></span></div>
      <div class="field"><label>Target occupation</label><select class="select" data-profile-key="occupation" onchange="setProfile('occupation',this.value);validateProfileLive()">${opt(OCCUPATION_OPTIONS,p.occupation,'Select target occupation')}</select><span class="field-error"></span></div>
      ${field('experienceYears','Years of experience')}${field('education','Highest education')}${field('graduation','Graduation year')}${field('experienceRole','Current / most recent role')}
      <div class="field"><label>Availability</label><select class="select" data-profile-key="availability" onchange="setProfile('availability',this.value);validateProfileLive()">${opt(AVAILABILITY_OPTIONS,p.availability,'Select availability')}</select><span class="field-error"></span></div>
      <div class="field"><label>Language level</label><select class="select" onchange="setProfile('languageLevel',this.value);safeSave()"><option value="">Not provided</option>${['A1','A2','B1','B2','C1','C2'].map(x=>`<option value="${x}" ${p.languageLevel===x?'selected':''}>${x}</option>`).join('')}</select></div>
      <div class="field"><label>Study language (if Study)</label><select class="select" onchange="setProfile('studyLanguage',this.value);safeSave()">${['Not sure','German-taught','English-taught'].map(x=>`<option value="${x}" ${p.studyLanguage===x?'selected':''}>${x}</option>`).join('')}</select></div>
      ${state.goal==='Employment'?`<div class="field full"><label>Recognition / profession route reviewed?</label><select class="select" onchange="setProfile('recognitionReviewed',this.value==='yes');safeSave();render()"><option value="no" ${!p.recognitionReviewed?'selected':''}>Not reviewed yet</option><option value="yes" ${p.recognitionReviewed?'selected':''}>Reviewed / route identified</option></select></div>`:''}
    </div>
    <div id="profileValidation" class="validation-summary"></div>
  </div>
  <div><div class="card"><h3>Profile readiness</h3>${profileChecklistHTML()}<div class="line"></div><div class="stat"><b>${profilePercent()}%</b><span>Profile completeness</span></div><div class="guard-note" style="margin-top:10px">The app will not use obviously invalid input to unlock the evidence stage. Qualification still requires supporting evidence.</div><div class="actions"><button class="btn primary" onclick="completeProfile()">Validate & continue →</button></div></div>
  <div class="card" style="margin-top:12px"><h3>Pathway context</h3><p class="small">${esc(profileLanguageRule())}</p><p class="footer-note">This is decision-support. Final admission, recognition, visa and employment decisions belong to the relevant German institution or authority.</p></div></div></div>`;
  validateProfileLive();
}
pageProfile=finalPageProfileValidated;

/* Profile entry: show the first missing/invalid field with Magnus immediately. */
const _profilePageWithMagnus = pageProfile;
pageProfile = function(){
  _profilePageWithMagnus();
  setTimeout(()=>{
    const first=profileValidationErrors()[0];
    if(first){
      roboSetAttention(first.error, roboSelectorForProfile(first.key));
    }
  }, 180);
};

function finalCompleteProfileStrict(){
  const errors=validateProfileLive();
  if(errors.length){toast(errors[0].error);const el=document.querySelector('[data-profile-key="'+errors[0].key+'"]');if(el){el.focus();el.classList.add('field-invalid')} return;}
  log('Profile validated successfully'); safeSave(); go('evidence');
}
completeProfile=finalCompleteProfileStrict;

/* Evidence upload guard: reject unsupported/empty files and obvious demo/fake names. */
function handleFilesStrict(files){
  const bad=[]; const accepted=[];
  [...(files||[])].forEach(f=>{
    const okType=/^(application\/pdf|application\/msword|application\/vnd\.openxmlformats-officedocument\.wordprocessingml\.document|image\/png|image\/jpeg)$/.test(f.type) || /\.(pdf|doc|docx|png|jpg|jpeg)$/i.test(f.name);
    if(!okType || !f.size){bad.push(`${f.name}: unsupported or empty file`);return;}
    if(f.size>15*1024*1024){bad.push(`${f.name}: file is larger than 15 MB`);return;}
    if(/(fake|sample|dummy|test|invalid|template)/i.test(f.name)){bad.push(`${f.name}: filename suggests a placeholder/test document`);return;}
    const category=classifyDocument(f.name);
    accepted.push({name:f.name,type:/\.pdf$/i.test(f.name)?'PDF':/\.(png|jpg|jpeg)$/i.test(f.name)?'Image':'Document',verified:false,category,reviewed:false});
  });
  if(bad.length)openModal('File check stopped these uploads',`<div class="missing-banner"><b>The system did not accept these files.</b>${bad.map(x=>`<div class="assistant-missing"><span>${esc(x)}</span></div>`).join('')}</div><p class="small">Use the original document files. This browser prototype checks type, size and obvious placeholder naming; production document AI should also inspect the actual document content.</p>`,`<button class="btn primary" onclick="closeModal()">Okay</button>`);
  accepted.forEach(d=>{state.evidence.documents.push(d);log('Accepted evidence file: '+d.name)});
  if(accepted.length) {smartDocumentIntelligence();toast(`${accepted.length} file${accepted.length>1?'s':''} accepted`)}
  safeSave(); render();
}
handleFiles=handleFilesStrict;

/* Stronger qualification: evidence must be reviewed, not merely typed into the profile. */
function reviewedDoc(category){return (state.evidence.smartDocuments||[]).some(d=>d.category===category && d.reviewed && !(d.flags||[]).length)}
function verifiedEvidenceFor(key){
  if(key==='education') return reviewedDoc('education');
  if(key==='experience') return reviewedDoc('experience') || reviewedDoc('internship');
  if(key==='language') return reviewedDoc('language');
  return false;
}
function finalBuildQualificationStrict(){
  const rules=[];
  rules.push({key:'goal',label:'Pathway selected',detail:state.goal?'Selected: '+state.goal:'Choose Study, Vocational Training or Employment.',pass:!!state.goal});
  rules.push({key:'profileIntegrity',label:'Profile integrity',detail:'Name, email, field, occupation, education, graduation year, experience value and availability must pass real-time validation.',pass:profileValidationErrors().length===0});
  rules.push({key:'education',label:'Verified education evidence',detail:'At least one education document must be Smart-analysed and human-reviewed. Typed profile text alone is not enough.',pass:verifiedEvidenceFor('education')});
  if(state.goal==='Employment') rules.push({key:'experience',label:'Verified experience evidence',detail:'Experience letter/employment evidence must be reviewed; an internship alone does not substitute for required employment evidence.',pass:verifiedEvidenceFor('experience')});
  rules.push({key:'language',label:'Language requirement',detail:profileLanguageRequirementText()+' Language claims need corresponding evidence or an explicit pathway-specific review.',pass:verifiedEvidenceFor('language') || (state.goal==='Employment' && !!state.profile.languageLevel && !!state.checks.language)});
  rules.push({key:'documentCompleteness',label:'Core evidence completeness',detail:'All mandatory evidence for the selected pathway should be present and reviewed.',pass:missingCoreFiles().length===0 && ['education','language'].every(k=>verifiedEvidenceFor(k)) && (state.goal!=='Employment' || verifiedEvidenceFor('experience'))});
  if(state.goal==='Employment') rules.push({key:'recognition',label:'Recognition / comparability route',detail:regulatedHint()?'This target may be regulated: recognition/professional authorisation must be reviewed.':'Recognition/comparability route must be reviewed for the selected occupation and route.',pass:!!state.profile.recognitionReviewed});
  rules.push({key:'pathwayFit',label:'Pathway fit',detail:'Goal, field, occupation and education must be coherent.',pass:!!state.goal&&!!state.profile.field&&!!state.profile.occupation&&!!state.profile.education});
  return rules;
}
buildQualification=finalBuildQualificationStrict;

function finalRunQualificationStrict(){
  validateProfileLive();
  if(profileValidationErrors().length){openModal('Qualification blocked by profile errors',`<div class="missing-banner"><b>Please correct the profile first.</b><span>The qualification engine does not treat invalid or incomplete profile data as eligible evidence.</span></div>${profileValidationErrors().map(x=>`<div class="rule"><div class="rule-main"><b>${esc(x.key)}</b><span>${esc(x.error)}</span></div><span class="status blocked">Fix</span></div>`).join('')}`,`<button class="btn primary" onclick="closeModal();go('profile')">Fix profile →</button>`);return}
  smartDocumentIntelligence();
  const rules=buildQualification(),missing=rules.filter(r=>!r.pass);
  const status=missing.length===0?'QUALIFIED':(missing.length<=3?'NEEDS EVIDENCE':'BLOCKED');
  state.qualification={status,score:qualificationScore(rules),rules,missing,checkedAt:new Date().toLocaleString(),readiness:germanyReadinessScore()};
  log('Qualification check run: '+status);
  safeSave(); render();
  if(status!=='QUALIFIED'){openWhyNotEligible()}
  else toast('Qualification passed — verified next step unlocked');
}
runQualification=finalRunQualificationStrict;

/* Animated Magnus markup. No image is used. */
function roboHTML(size='large'){
  return `<div class="robot-stage robot-${size}" aria-label="Magnus AI assistant" role="img"><div class="robo-character"><span class="robo-glow"></span><span class="robo-head"><i class="robo-face-line"></i><i class="robo-eye left"></i><i class="robo-eye right"></i></span><span class="robo-body"><i class="robo-chest"></i></span><i class="robo-arm left"></i><i class="robo-arm right"><i class="robo-hand"></i></i></div></div>`;
}

function finalRenderVirtualInterviewModalStrict(){
  const qs=['Tell us about yourself and why you want to pursue your chosen path in Germany.','Tell us about one course, internship, project or certification that prepared you for your target role.','What is a challenge you faced and how did you solve it?','Why Germany, and what are your realistic expectations for the move?','What would you like an employer or training provider to remember about you?'];
  const i=state.virtualInterview.questionIndex||0;
  if(i>=qs.length){
    const answers=state.virtualInterview.answers||[]; const strengths=[];
    if(answers.every(a=>a&&a.length>60))strengths.push('Answers are detailed and structured');
    if(answers.some(a=>/project|internship|course|certificate/i.test(a)))strengths.push('Uses concrete evidence');
    if(answers.some(a=>/why|goal|motivat/i.test(a)))strengths.push('Explains motivation');
    if(answers.some(a=>/result|impact|improv/i.test(a)))strengths.push('Mentions outcomes or impact');
    const score=Math.min(100,40+strengths.length*12+answers.filter(a=>a&&a.length>100).length*4);
    state.virtualInterview.completed=true; state.virtualInterview.score=score; state.virtualInterview.feedback=strengths; safeSave(); stopVICamera();
    openModal('Virtual Interview Results',`<div class="assistant-result-banner">${roboHTML('small')}<div><span class="pill">MAGNUS COACH</span><b>Your practice is complete.</b><span>This is preparation feedback, not a hiring decision.</span></div></div><div class="grid3" style="margin-top:12px"><div class="stat"><b>${score}%</b><span>Practice score</span></div><div class="stat"><b>${answers.filter(Boolean).length}/5</b><span>Questions answered</span></div><div class="stat"><b>${strengths.length}</b><span>Coach strengths</span></div></div><div class="card" style="margin-top:12px"><h3>Practice feedback</h3>${strengths.length?strengths.map(x=>`<div class="rule"><div class="rule-main"><b>✓ ${esc(x)}</b></div><span class="status verified">Strength</span></div>`).join(''):'<p class="small">Add specific examples from your real courses, internships, projects or work evidence.</p>'}</div><div class="guard-note">Magnus is a practice coach. It does not decide hiring, admission, visa or qualification.</div>`,`<button class="btn secondary" onclick="closeModal();stopVICamera()">Close</button><button class="btn primary" onclick="closeModal();go('interview')">Open interview stage →</button>`); return;
  }
  const prev=state.virtualInterview.answers[i]||'';
  openModal('Virtual Interview Practice',`<div class="assistant-interviewer">${roboHTML('small')}<div><span class="pill blue">MAGNUS INTERVIEW COACH</span><h4 style="margin:7px 0 4px;font-size:12px">Question ${i+1} of ${qs.length}</h4><div class="robo-status"><span class="dot"></span>Live practice coach · moving assistant</div><p class="small">Answer naturally. Real experience is expected; made-up examples are flagged in the feedback.</p></div></div><div class="question-box" style="margin-top:12px"><h4>${esc(qs[i])}</h4><p>Tip: use situation → action → result → learning.</p><textarea id="viAnswer" class="textarea" placeholder="Type your answer here...">${esc(prev)}</textarea></div><div class="camera-wrap" style="margin-top:10px"><video id="viCamera" autoplay muted playsinline></video><div id="viCameraPlaceholder" class="camera-placeholder">Camera is optional.<br>Enable it for a more realistic practice session.</div></div><div class="interview-toolbar"><button class="btn secondary" onclick="startVICamera()">Enable camera</button><button class="btn secondary" onclick="stopVICamera()">Stop camera</button><span class="pill" style="margin-left:auto">Evidence available: ${extraCount()+(state.evidence.documents?.length||0)}</span></div>`,`<button class="btn secondary" onclick="closeModal();stopVICamera()">Exit practice</button><button class="btn primary" onclick="submitVirtualAnswer()">${i===qs.length-1?'Finish practice':'Next question →'}</button>`);
}
renderVirtualInterviewModal=finalRenderVirtualInterviewModalStrict;

function finalOpenHelpDeskStrict(){
  const missing=missingCoreFiles(); const context=STEPS[currentIndex()]?.short||'Journey'; const readiness=germanyReadinessScore(); const q=state.qualification;
  const message=missing.length?`I found ${missing.length} core evidence gap${missing.length>1?'s':''}. I will keep the qualification blocked until these are resolved.`:'Your current core evidence looks complete. I will still check profile integrity, consistency and pathway fit.';
  openModal('Magnus AI Help Desk',`<div class="assistant-head">${roboHTML('large')}<div><span class="pill">MAGNUS AI</span><h3 style="margin:7px 0 4px">Hi! I’m Magnus.</h3><div class="robo-status"><span class="dot"></span>Online · live assistant animation</div><p class="small">Current stage: <b>${esc(context)}</b> · Germany readiness: <b>${readiness}/100</b></p></div></div><div class="chat" style="margin-top:14px"><div class="chat-row"><div class="chat-bubble">${esc(message)}</div></div><div class="chat-row"><div class="chat-bubble">I can explain missing files, qualification gaps, the readiness score, what-if scenarios and interview practice.</div></div>${q?.missing?.length?`<div class="chat-row"><div class="chat-bubble">Latest qualification result: <b>${esc(q.status)}</b> with ${q.missing.length} unresolved gate${q.missing.length>1?'s':''}.</div></div>`:''}</div>${missing.length?`<div style="margin-top:12px"><div class="missing-banner"><b>Missing evidence</b>${missing.map(m=>`<div class="assistant-missing"><b>${esc(m.label)}</b><span>${esc(m.detail)}</span></div>`).join('')}</div></div>`:''}<div class="grid3" style="margin-top:12px"><button class="btn secondary" onclick="openWhyNotEligible()">Why not eligible?</button><button class="btn secondary" onclick="openWhatIf()">What-if career</button><button class="btn secondary" onclick="closeModal();openMissingFilesQuick()">${missing.length?`Missing files (${missing.length})`:'Check files'}</button></div><div class="grid3" style="margin-top:9px"><button class="btn secondary" onclick="openProtectionCenter()">🛡 Protection</button><button class="btn secondary" onclick="closeModal();go('qualification')">Qualification</button><button class="btn secondary" onclick="closeModal();openVirtualInterview()">Practice interview</button></div>`,`<button class="btn primary" onclick="closeModal()">Done</button>`);
}
openHelpDesk=finalOpenHelpDeskStrict;

/* Override final fresh-open behavior without destroying saved applicant data. */
try { state.current='start'; safeSave(); } catch(e) {}
render();

/* Qualification gate fix: a failed/blocked qualification never unlocks Next Step. */
function finalDoneStrict(i){
  if(i===0) return finalHasProfileStrict();
  if(i===1) return !!state.protection?.evidenceReview && state.evidence.documents.length>0;
  if(i===2) return !!state.video?.analyzed;
  if(i===3) return state.video?.analyzed===true;
  if(i===4) return state.qualification?.status==='QUALIFIED';
  if(i===5) return state.qualification?.status==='QUALIFIED';
  if(i===6) return state.resumeApproved===true;
  if(i===7) return state.educaroForwarded===true;
  if(i===8) return state.notified===true;
  return false;
}
done = finalDoneStrict;

function finalUnlockedStrict(id){
  if(id==='start') return true;
  const idx=STEPS.findIndex(s=>s.id===id);
  if(idx<0) return false;
  if(idx===1 && state.current==='start') return true;
  for(let i=0;i<idx;i++) if(!done(i)) return false;
  return true;
}
unlocked = finalUnlockedStrict;

function finalGoStrict(id){
  if(id!=='start' && id!==state.current && !unlocked(id)){
    toast('This step is locked. Finish the previous requirement first.');
    return;
  }
  state.current=id;
  safeSave();
  render();
}
go = finalGoStrict;

render();

/* Navigation map fix: each step unlocks from the milestone immediately before it. */
function finalDoneMilestones(i){
  if(i===0 || i===1) return finalHasProfileStrict();
  if(i===2) return !!state.protection?.evidenceReview;
  if(i===3) return !!state.video?.analyzed;
  if(i===4 || i===5) return state.qualification?.status==='QUALIFIED';
  if(i===6) return state.resumeApproved===true;
  if(i===7) return state.educaroForwarded===true;
  if(i===8) return state.notified===true;
  return false;
}
done=finalDoneMilestones;
function finalUnlockedMilestones(id){
  const idx=STEPS.findIndex(s=>s.id===id);
  if(idx<0) return false;
  if(idx===0 || idx===1) return true;
  if(idx===2) return finalHasProfileStrict();
  if(idx===3) return !!state.protection?.evidenceReview;
  if(idx===4) return !!state.video?.analyzed;
  if(idx===5) return state.qualification?.status==='QUALIFIED';
  if(idx===6) return state.qualification?.status==='QUALIFIED';
  if(idx===7) return state.resumeApproved===true;
  if(idx===8) return state.educaroForwarded===true;
  return false;
}
unlocked=finalUnlockedMilestones;
function finalProgressMilestones(){
  const checkpoints=[finalHasProfileStrict(),!!state.protection?.evidenceReview,!!state.video?.analyzed,state.qualification?.status==='QUALIFIED',state.resumeApproved===true,state.educaroForwarded===true,state.notified===true];
  return Math.round(checkpoints.filter(Boolean).length/checkpoints.length*100);
}
progress=finalProgressMilestones;
function finalGoMilestones(id){
  if(id!=='start' && id!==state.current && !unlocked(id)){toast('This step is locked. Complete the previous requirement first.');return;}
  state.current=id; safeSave(); render();
}
go=finalGoMilestones;
render();

/* Upload modal stability: never render over the validation dialog. */
function finalHandleFilesStrict(files){
  const bad=[]; const accepted=[];
  [...(files||[])].forEach(f=>{
    const okType=/^(application\/pdf|application\/msword|application\/vnd\.openxmlformats-officedocument\.wordprocessingml\.document|image\/png|image\/jpeg)$/.test(f.type) || /\.(pdf|doc|docx|png|jpg|jpeg)$/i.test(f.name);
    if(!okType || !f.size){bad.push(`${f.name}: unsupported or empty file`);return;}
    if(f.size>15*1024*1024){bad.push(`${f.name}: file is larger than 15 MB`);return;}
    if(/(fake|sample|dummy|test|invalid|template)/i.test(f.name)){bad.push(`${f.name}: filename suggests a placeholder/test document`);return;}
    const category=classifyDocument(f.name);
    accepted.push({name:f.name,type:/\.pdf$/i.test(f.name)?'PDF':/\.(png|jpg|jpeg)$/i.test(f.name)?'Image':'Document',verified:false,category,reviewed:false});
  });
  accepted.forEach(d=>{state.evidence.documents.push(d);log('Accepted evidence file: '+d.name)});
  if(accepted.length){smartDocumentIntelligence(); safeSave(); render(); toast(`${accepted.length} file${accepted.length>1?'s':''} accepted`);}
  else {safeSave(); render();}
  if(bad.length){
    setTimeout(()=>openModal('File check stopped these uploads',`<div class="missing-banner"><b>The system did not accept these files.</b>${bad.map(x=>`<div class="assistant-missing"><span>${esc(x)}</span></div>`).join('')}</div><p class="small">Use the original document files. This prototype checks file type, size and obvious placeholder/test naming; production document AI should inspect the document content itself.</p>`,`<button class="btn primary" onclick="closeModal()">Okay</button>`),20);
  }
}
handleFiles=finalHandleFilesStrict;
render();

/* Evidence stage refinement: analysis and human review are separate actions. */
function coreEvidenceReviewReady(){
  const edu=reviewedDoc('education');
  const lang=reviewedDoc('language');
  const exp=reviewedDoc('experience')||reviewedDoc('internship');
  if(state.goal==='Employment') return edu&&exp;
  return edu&&lang;
}
function openRequiredEvidenceReview(key){
  const aliases=key==='experience'?['experience','internship']:[key];
  const docs=state.evidence.smartDocuments||[];
  const index=docs.findIndex(d=>aliases.includes(d.category)&&(!d.reviewed||(d.flags||[]).length>0));
  if(index>=0){openDocumentInspector(index);return;}
  const target=document.querySelector('.upload-area');
  const labels={education:'education / qualification',language:'language',experience:'employment / experience'};
  const label=labels[key]||'required';
  if(target){target.scrollIntoView({behavior:'smooth',block:'center'});target.classList.add('robo-focus');setTimeout(()=>target.classList.remove('robo-focus'),6500);}
  if(typeof roboSetAttention==='function')roboSetAttention(`Missing ${label} evidence. Upload the source document here.`,'.upload-area');
  toast(`No analysed ${label} document is available yet. Upload it first.`);
}
function completeEvidenceReview(){
  const gaps=[];
  if(!reviewedDoc('education'))gaps.push({key:'education',label:'Education / qualification document',detail:'Upload it if missing, then inspect and mark the document reviewed.'});
  if(state.goal==='Employment'){
    if(!reviewedDoc('experience')&&!reviewedDoc('internship'))gaps.push({key:'experience',label:'Employment / experience document',detail:'A reviewed experience letter is required for this employment route.'});
  }else if(!reviewedDoc('language')){
    gaps.push({key:'language',label:'Language evidence',detail:'Upload the relevant language proof, then inspect and mark the document reviewed.'});
  }
  if(gaps.length){
    const items=gaps.map(g=>`<div class="assistant-missing"><b>${esc(g.label)}</b><span>${esc(g.detail)}</span><button class="btn secondary" style="margin-top:7px;padding:6px 9px" onclick="closeModal();openRequiredEvidenceReview('${g.key}')">Show me this item →</button></div>`).join('');
    openModal('Evidence review is not complete',`<div class="missing-banner"><b>The next step is available after the required source evidence has been reviewed.</b>${items}</div><p class="small">This does not reject your application. It keeps the qualification path honest until the required evidence can be reviewed.</p>`,`<button class="btn primary" onclick="closeModal()">Keep reviewing</button>`);
    return;
  }
  state.protection=state.protection||{};
  state.protection.evidenceReview=true;
  log('Evidence review completed and human review confirmed');
  safeSave();
  go('video');
}
function finalPageEvidenceStrict(){
  const core=[
    ['education','Degree / qualification evidence','A reviewed education document is required.'],
    ['language','Language evidence','A reviewed language document is required for Study and Vocational Training.'],
    ['experience','Experience evidence','A reviewed experience/internship document is required for Employment.']
  ];
  const statusHtml=(key)=>{
    const reviewed=key==='experience' ? (reviewedDoc('experience')||reviewedDoc('internship')) : reviewedDoc(key);
    const needed=key!=='experience' || state.goal==='Employment';
    if(!needed)return '<span class="status pending">Not mandatory</span>';
    return `<span class="status ${reviewed?'verified':'blocked'}">${reviewed?'✓ Reviewed':'Review needed'}</span>`;
  };
  document.getElementById('app').innerHTML=`<div class="section-head"><div><span class="pill">STEP 3 · EVIDENCE LOCKER</span><h2 style="margin-top:9px">Upload, analyse, then review the evidence.</h2><p>Wrong files and unreviewed evidence cannot silently become qualification passes.</p></div><span class="pill blue">${state.evidence.documents.length} DOCUMENTS</span></div>
  <div class="grid2"><div><div class="card"><h3>Core evidence</h3>${core.map(([key,label,detail])=>`<div class="rule"><div class="rule-main"><b>${label}</b><span>${esc(detail)}</span></div>${statusHtml(key)}</div>`).join('')}
  <div class="upload-area" style="margin-top:12px"><b style="font-size:11px">Add original documents</b><div class="muted" style="margin:5px 0 10px">PDF, DOC/DOCX or JPG/PNG. Max 15 MB each. Placeholder/test names are rejected.</div><label class="upload-btn" for="fileInput">＋ Choose files</label><input id="fileInput" type="file" multiple accept=".pdf,.png,.jpg,.jpeg,.doc,.docx" onchange="handleFiles(this.files)"></div></div>
  <div class="card" style="margin-top:14px"><h3>Extra evidence</h3>${extraEvidenceRows()}<div class="line"></div><p class="small">Courses, internships, projects, certifications, awards and volunteering improve the evidence-backed resume and readiness signal. They never replace a mandatory gate.</p></div>
  </div><div>
  <div class="card"><div style="display:flex;justify-content:space-between;align-items:center;gap:10px"><h3>Smart Document Intelligence</h3><span class="pill ai">AI + HUMAN REVIEW</span></div>${smartDocListHTML()}<div class="actions"><button class="btn secondary" ${state.evidence.documents.length?'':'disabled'} onclick="runSmartAnalysisOnly()">Run / refresh analysis ↻</button></div></div>
  <div class="card" style="margin-top:12px"><h3>Document review checks</h3>${['Qualification titles are readable','Language proof is identifiable'].map((x,i)=>`<label class="check"><input type="checkbox" ${[state.checks.education,state.checks.language][i]?'checked':''} onchange="toggleCheck('${['education','language'][i]}',this.checked);safeSave();render()">${x}</label>`).join('')}<div class="guard-note">These checks cover document readability and language evidence. Core qualification still requires reviewed source documents.</div></div>
  <div class="card" style="margin-top:12px"><h3>Evidence gate</h3><div class="notice" style="border-left-color:${coreEvidenceReviewReady()?'#39a47a':'#c2892d'};background:${coreEvidenceReviewReady()?'#effaf5':'#fff8e8'};color:${coreEvidenceReviewReady()?'#257357':'#7a5a16'}">${coreEvidenceReviewReady()?'✓ Core evidence has been analysed and reviewed.':'Review the required source documents to unlock Magnus’s HR introduction interview.'}</div><div class="actions"><button class="btn primary" onclick="completeEvidenceReview()">Continue to Magnus HR introduction interview →</button></div></div>
  </div></div>`;
}
pageEvidence=finalPageEvidenceStrict;
function runSmartAnalysisOnly(){smartDocumentIntelligence();safeSave();render();toast('Smart Document Intelligence refreshed — inspect each document before continuing')}
analyzeEvidence=runSmartAnalysisOnly;
render();

/* Smart Document Intelligence stability: re-analysis preserves human review state. */
function smartDocumentIntelligenceStable(){
  const previous=Object.fromEntries((state.evidence.smartDocuments||[]).map(d=>[d.name,{reviewed:!!d.reviewed,verified:!!d.verified}]));
  state.evidence.smartDocuments=(state.evidence.documents||[]).map(doc=>{
    const category=doc.category||classifyDocument(doc.name); const name=doc.name;
    let confidence=78, fields=[], flags=[];
    if(category==='education'){confidence=95;fields=[['Qualification',state.profile.education||'Education evidence'],['Graduation',state.profile.graduation||'Not extracted']];}
    else if(category==='experience'){confidence=92;fields=[['Role',state.profile.experienceRole||'Not extracted'],['Experience',state.profile.experienceYears?state.profile.experienceYears+' years':'Not extracted']];}
    else if(category==='language'){confidence=94;fields=[['Language level',state.profile.languageLevel||'Not extracted'],['Evidence type','Language certificate / language proof']];}
    else if(category==='cv'){confidence=96;fields=[['Applicant','CV / resume structure'],['Target role',state.profile.occupation||state.profile.field||'Not extracted']];}
    else if(category==='internship'){confidence=90;fields=[['Evidence type','Internship placement / duration'],['Role',state.profile.experienceRole||'Not extracted']];}
    else if(category==='project'){confidence=88;fields=[['Evidence type','Portfolio / project evidence'],['Target field',state.profile.field||'Not extracted']];}
    else if(category==='course'){confidence=86;fields=[['Evidence type','Course / training evidence']];}
    else {fields=[['Review','Supporting document — manual review recommended']];}
    if(/fake|sample|dummy|test|invalid|template/i.test(name)) flags.push('Possible placeholder/test document name');
    const old=previous[name]||{};
    return {...doc,category,confidence,fields,flags,signals:{education:'Qualification / education signals',experience:'Employer / role / date signals',language:'Language proof signals',cv:'Resume structure',internship:'Internship placement / duration',project:'Portfolio / project evidence',course:'Course / training evidence',supporting:'Supporting document'}[category],analyzed:true,reviewed:!!old.reviewed,verified:!!old.verified};
  });
  state.checks.education=state.evidence.smartDocuments.some(d=>d.category==='education');
  state.checks.experience=state.evidence.smartDocuments.some(d=>['experience','internship'].includes(d.category));
  state.checks.language=state.evidence.smartDocuments.some(d=>d.category==='language');
  state.checks.documentCompleteness=missingCoreFiles().length===0;
  safeSave();
}
smartDocumentIntelligence=smartDocumentIntelligenceStable;
render();


/* =========================================================
   MAGNUS HELP DESK V2
   Open-by-default assistant, minimize behavior, contextual
   actions, missing-file navigation, proactive alerts, and
   animated robot moods.
   ========================================================= */

function roboContextKey(){
  return STEPS[currentIndex()]?.short || 'Journey';
}
function roboMood(){
  if(state.notified) return 'success';
  if((state.qualification && state.qualification.status && state.qualification.status!=='QUALIFIED') || roboMissing().length) return 'attention';
  if(state.video?.analyzed || state.qualification) return 'thinking';
  return 'ready';
}
function roboMissing(){
  // Before the applicant chooses a pathway, avoid confusing them with document gaps.
  if(!state.goal) return [];
  return missingCoreFiles();
}
function roboNextAction(){
  if(!finalHasProfileStrict()) return {label:'Complete your profile',desc:'Choose the pathway and fill the required applicant information.',step:'profile'};
  if(!state.protection?.evidenceReview) return {label:'Review your evidence',desc:'Open the Evidence Locker and review the required documents.',step:'evidence'};
  if(!state.video?.analyzed) return {label:'Complete your introduction video',desc:'Add and analyse your short introduction.',step:'video'};
  if(!state.qualification) return {label:'Run qualification',desc:'Check the pathway-specific qualification gates.',step:'qualification'};
  if(state.qualification.status!=='QUALIFIED') return {label:'Resolve qualification gaps',desc:'Fix the exact requirements shown by the qualification engine.',step:'qualification'};
  if(!state.resumeApproved) return {label:'Review your verified resume',desc:'Approve the evidence-backed resume before routing.',step:'resume'};
  if(!state.outreachSent) return {label:'Review Educaro routing',desc:'Complete the protection gates before sending the profile to Educaro.',step:'outreach'};
  if(!state.educaroForwarded) return {label:'Complete Educaro forwarding',desc:'Educaro receives and routes the approved profile to a matched company.',step:'outreach'};
  if(!state.interviewOffer) return {label:'Monitor for interview response',desc:'The interview stage is active after Educaro forwarding.',step:'interview'};
  if(!state.notified) return {label:'Open interview notification',desc:'Review the detected interview date, time and format.',step:'interview'};
  return {label:'Journey complete',desc:'Your current demo journey has reached interview follow-up.',step:'interview'};
}
function roboStageMessage(){
  const next=roboNextAction();
  const m=roboMissing();
  if(m.length) return `I found ${m.length} core evidence gap${m.length>1?'s':''}. I can take you directly to the missing item.`;
  if(roboMood()==='attention') return 'Something needs your attention. I can explain the blocker and show the recovery step.';
  if(roboMood()==='success') return 'Nice — the current journey has reached the interview follow-up stage.';
  return `Your next best action is: ${next.label}.`;
}
function roboHTML(size='large'){
  return `<div class="robot-stage robot-${size} robo-mood-${roboMood()}" aria-label="Magnus AI assistant" role="img"><div class="robo-character"><span class="robo-glow"></span><span class="robo-head"><i class="robo-face-line"></i><i class="robo-eye left"></i><i class="robo-eye right"></i></span><span class="robo-body"><i class="robo-chest"></i></span><i class="robo-arm left"></i><i class="robo-arm right"><i class="robo-hand"></i></i></div></div>`;
}
function openRoboModal(title,body,actions=''){
  const root=document.getElementById('modalRoot');
  root.innerHTML=`<div class="modal-backdrop show robo-modal-backdrop" onclick="if(event.target===this)minimizeRoboAssistant()"><div class="modal robo-assistant-modal"><div class="modal-head"><div style="display:flex;align-items:center;gap:8px"><span class="pill">MAGNUS AI</span><span class="muted">Live journey assistant</span></div><div class="robo-head-actions"><button class="robo-minimize" aria-label="Minimize Magnus" title="Minimize" onclick="minimizeRoboAssistant()">—</button><button class="modal-close" onclick="minimizeRoboAssistant()" aria-label="Close">×</button></div></div><div class="modal-body">${body}</div><div class="modal-actions">${actions}</div></div></div>`;
  const fab=document.getElementById('roboFab'); if(fab) fab.classList.remove('robo-alert');
}
function minimizeRoboAssistant(){
  const root=document.getElementById('modalRoot'); if(root) root.innerHTML='';
  const fab=document.getElementById('roboFab'); if(fab){fab.classList.add('robo-alert');fab.title='Magnus is minimized — click to open';}
}
function openRoboNext(){
  const n=roboNextAction(); minimizeRoboAssistant(); go(n.step); if(n.step==='evidence'){setTimeout(()=>roboFocusFirstMissing(),180)}
}
function openRoboMissingList(){
  const missing=roboMissing();
  if(!missing.length){
    openRoboModal('Magnus AI Help Desk',`<div class="assistant-head">${roboHTML('large')}<div><h3 style="margin:0 0 5px">No core files are currently missing.</h3><div class="robo-status"><span class="dot"></span>Ready</div><p class="small">I can still take you to Smart Document Intelligence to inspect what you already uploaded.</p></div></div>`,`<button class="btn secondary" onclick="minimizeRoboAssistant();go('evidence')">Open Evidence Locker →</button><button class="btn primary" onclick="minimizeRoboAssistant()">Done</button>`);
    return;
  }
  const items=missing.map(m=>`<div class="robo-missing-item" data-missing-key="${esc(m.key)}"><div class="robo-arrow">!</div><div class="rmi-main"><b>${esc(m.label)}</b><span>${esc(m.detail)}</span></div><button class="btn secondary" style="padding:7px 9px" onclick="roboShowMissing('${esc(m.key)}')">Show me</button></div>`).join('');
  openRoboModal('Magnus • Missing evidence',`<div class="missing-banner"><b>${missing.length} core evidence item${missing.length>1?'s':''} need attention.</b><span>Click <b>Show me</b> and I will take you to the exact place in the Evidence Locker.</span></div><div class="robo-missing-list">${items}</div>`,`<button class="btn secondary" onclick="minimizeRoboAssistant()">Minimize</button><button class="btn primary" onclick="roboShowMissing('${esc(missing[0].key)}')">Show first gap →</button>`);
}
function roboShowMissing(key){
  state.roboFocus=key; safeSave(); minimizeRoboAssistant();
  state.current='evidence'; safeSave(); render();
  setTimeout(()=>{
    const el=document.querySelector('[data-evidence-key="'+CSS.escape(key)+'"]');
    if(el){el.scrollIntoView({behavior:'smooth',block:'center'});el.classList.add('robo-focus');setTimeout(()=>el.classList.remove('robo-focus'),5200);}
  },120);
}
function roboFocusFirstMissing(){const m=roboMissing()[0];if(m)roboShowMissing(m.key)}
function openRoboQualification(){minimizeRoboAssistant();go('qualification')}
function openRoboChat(){
  const input=document.getElementById('roboQuestion'); const q=(input?.value||'').trim(); if(!q){toast('Ask Magnus a question first');return}
  const lower=q.toLowerCase(); let reply='I can help with your current journey stage, missing evidence, qualification, next steps, What-If scenarios or interview practice.';
  if(/missing|document|file|upload/.test(lower)) reply=roboMissing().length?`I found ${roboMissing().length} core evidence gap${roboMissing().length>1?'s':''}. Click “Missing files” and I will show you where.`:'I do not see a core file gap right now.';
  else if(/next|what should|do now|continue/.test(lower)) reply=`Your next action is: ${roboNextAction().label}.`;
  else if(/eligible|qualif|blocked|why/.test(lower)) reply=state.qualification?`Latest qualification: ${state.qualification.status}. I can open the exact gates and recovery actions.`:'Qualification has not been run yet.';
  else if(/interview|practice/.test(lower)) reply='I can open a 5-question Magnus practice interview using your own background, courses, internships and projects.';
  else if(/readiness|score/.test(lower)) reply=`Your Germany Readiness Score is ${germanyReadinessScore()}/100. It is a prototype readiness indicator, not a legal or hiring decision.`;
  const chat=document.getElementById('roboChatLog'); if(chat){chat.insertAdjacentHTML('beforeend',`<div class="chat-row user"><div class="chat-bubble">${esc(q)}</div></div><div class="chat-row"><div class="chat-bubble">🤖 ${esc(reply)}</div></div>`);chat.scrollTop=chat.scrollHeight;}
  if(input) input.value='';
}
function openHelpDesk(){
  const missing=roboMissing(); const next=roboNextAction(); const context=roboContextKey(); const readiness=germanyReadinessScore(); const q=state.qualification;
  const proactive=missing.length?`I noticed ${missing.length} evidence gap${missing.length>1?'s':''}. I can take you there now.`:(q&&q.status!=='QUALIFIED'?`Your latest qualification result is ${q.status}. I can explain exactly why and what to do next.`:`You are on ${context}. I’m ready to help with the next step.`);
  const moodLabel=roboMood()==='attention'?'Attention needed':roboMood()==='thinking'?'Checking your journey':roboMood()==='success'?'Journey complete':'Ready to help';
  openRoboModal('Magnus AI Help Desk',`
    <div class="assistant-head">${roboHTML('large')}<div><h3 style="margin:0 0 5px">Hi! I’m Magnus.</h3><div class="robo-status"><span class="dot"></span>${moodLabel} · ${esc(context)} · ${readiness}/100 readiness</div><p class="small" style="margin-top:7px">I stay with you through the journey and explain what to do next.</p></div></div>
    <div class="robo-proactive">${roboHTML('small')}<div><b>${esc(proactive)}</b><span>${esc(next.desc)}</span></div></div>
    <div class="robo-context"><div class="robo-context-card"><h4>What should I do next?</h4><p>${esc(next.label)} — ${esc(next.desc)}</p><button class="btn secondary" style="margin-top:8px" onclick="openRoboNext()">Take me there →</button></div><div class="robo-context-card"><h4>Current stage</h4><p><b>${esc(context)}</b><br>${esc(STEPS[currentIndex()]?.title||'Journey')}</p></div></div>
    <div id="roboChatLog" class="chat" style="margin-top:12px"><div class="chat-row"><div class="chat-bubble">🤖 ${esc(roboStageMessage())}</div></div></div>
    <div class="robo-action-grid">
      <button class="robo-action" onclick="openRoboMissingList()"><b>📄 Missing files</b><span>${missing.length?`${missing.length} item${missing.length>1?'s':''} need attention — I’ll show you where.`:'Check the Evidence Locker.'}</span></button>
      <button class="robo-action" onclick="openWhyNotEligible()"><b>❓ Why am I not eligible?</b><span>See the exact qualification gate and recovery action.</span></button>
      <button class="robo-action" onclick="openWhatIf()"><b>🔮 What-If Career</b><span>Test a scenario without changing your real profile.</span></button>
      <button class="robo-action" onclick="minimizeRoboAssistant();openVirtualInterview()"><b>🎤 Practice Interview</b><span>Train with Magnus using your own evidence.</span></button>
      <button class="robo-action" onclick="openRoboQualification()"><b>✅ Qualification standards</b><span>See the pathway rules and what is still unresolved.</span></button>
      <button class="robo-action" onclick="openProtectionCenter()"><b>🛡 Protection</b><span>Review identity, evidence and consent gates.</span></button>
    </div>
    <div class="robo-chat-compose"><input id="roboQuestion" placeholder="Ask Magnus about your current journey…" onkeydown="if(event.key==='Enter')openRoboChat()"><button class="btn primary" onclick="openRoboChat()">Ask</button></div>
  `,`<button class="btn secondary" onclick="minimizeRoboAssistant()">Minimize Magnus</button><button class="btn primary" onclick="openRoboNext()">Continue with my journey →</button>`);
}

/* Evidence Locker: Magnus focus mode. */
function pageEvidenceWithRoboFocus(){
  const core=[
    ['education','Degree / qualification evidence','A reviewed education document is required.'],
    ['language','Language evidence','A reviewed language document is required for Study and Vocational Training.'],
    ['experience','Experience / internship evidence','Add a reviewed experience letter or internship document; required for Employment and useful supporting evidence for other pathways.']
  ];
  const statusHtml=(key)=>{
    const reviewed=key==='experience'?(reviewedDoc('experience')||reviewedDoc('internship')):reviewedDoc(key);
    const needed=key!=='experience' || state.goal==='Employment';
    if(!needed)return '<span class="status pending">Not mandatory</span>';
    return `<span class="status ${reviewed?'verified':'blocked'}">${reviewed?'✓ Reviewed':'Review needed'}</span>`;
  };
  const focused=state.roboFocus||'';
  const roboHint=focused?`<div class="robo-proactive" style="margin-bottom:12px">${roboHTML('small')}<div><b>Magnus is showing you: ${esc((core.find(x=>x[0]===focused)||[])[1]||'this evidence item')}</b><span>Complete or review this item, then return to the journey. The highlight will clear when you leave this page.</span></div></div>`:'';
  document.getElementById('app').innerHTML=`<div class="section-head"><div><span class="pill">STEP 3 · EVIDENCE LOCKER</span><h2 style="margin-top:9px">Upload, analyse, then review the evidence.</h2><p>Magnus can point you directly to any missing core item.</p></div><span class="pill blue">${state.evidence.documents.length} DOCUMENTS</span></div>
  ${roboHint}
  <div class="grid2"><div><div class="card"><h3>Core evidence</h3>${core.map(([key,label,detail])=>`<div class="rule ${focused===key&&!((key==='experience'&&state.goal!=='Employment')||(!state.goal&&key==='language'))?'robo-focus':''}" data-evidence-key="${key}"><div class="rule-main"><b>${label}</b><span>${esc(detail)}</span>${!((key==='experience'&&state.goal!=='Employment'))&&!reviewedDoc(key) ? `<button class="btn secondary" style="margin-top:7px;padding:5px 8px" onclick="openRoboMissingList()">Ask Magnus</button>`:''}</div>${statusHtml(key)}</div>`).join('')}
  <div class="upload-area" style="margin-top:12px"><b style="font-size:11px">Add original documents</b><div class="muted" style="margin:5px 0 10px">PDF, DOC/DOCX or JPG/PNG. Max 15 MB each. Placeholder/test names are rejected.</div><label class="upload-btn" for="fileInput">＋ Choose files</label><input id="fileInput" type="file" multiple accept=".pdf,.png,.jpg,.jpeg,.doc,.docx" onchange="handleFiles(this.files)"></div></div>
  <div class="card" style="margin-top:14px"><h3>Extra evidence</h3>${extraEvidenceRows()}<div class="line"></div><p class="small">Courses, internships, projects, certifications, awards and volunteering strengthen the evidence-backed profile. They never replace a mandatory qualification gate.</p></div></div>
  <div><div class="card"><div style="display:flex;justify-content:space-between;align-items:center;gap:10px"><h3>Smart Document Intelligence</h3><span class="pill ai">AI + HUMAN REVIEW</span></div>${smartDocListHTML()}<div class="actions"><button class="btn secondary" ${state.evidence.documents.length?'':'disabled'} onclick="runSmartAnalysisOnly()">Run / refresh analysis ↻</button></div></div>
  <div class="card" style="margin-top:12px"><h3>Document review checks</h3>${['Qualification titles are readable','Language proof is identifiable'].map((x,i)=>`<label class="check"><input type="checkbox" ${[state.checks.education,state.checks.language][i]?'checked':''} onchange="toggleCheck('${['education','language'][i]}',this.checked);safeSave();render()">${x}</label>`).join('')}<div class="guard-note">Smart Document Intelligence suggests signals; human review remains required before evidence can unlock qualification.</div></div>
  <div class="card" style="margin-top:12px"><h3>Evidence gate</h3><div class="notice" style="border-left-color:${coreEvidenceReviewReady()?'#39a47a':'#c2892d'};background:${coreEvidenceReviewReady()?'#effaf5':'#fff8e8'};color:${coreEvidenceReviewReady()?'#257357':'#7a5a16'}">${coreEvidenceReviewReady()?'✓ Core evidence has been analysed and reviewed.':'Review the required source documents to unlock Magnus’s HR introduction interview.'}</div><div class="actions"><button class="btn primary" onclick="completeEvidenceReview()">Continue to Magnus HR introduction interview →</button></div></div></div></div>`;
  // One-time focus: clear persisted highlight after it is shown.
  if(focused){setTimeout(()=>{state.roboFocus='';safeSave()},6500)}
}
pageEvidence=pageEvidenceWithRoboFocus;

/* Open Magnus automatically when the website is freshly loaded. Minimize keeps the FAB available. */
if(!window.__roboInitialOpened){
  window.__roboInitialOpened=true;
  setTimeout(()=>{try{if(state.current==='start')openHelpDesk()}catch(e){}},420);
}
render();

/* FINAL OVERRIDE: bind Magnus V2 after all earlier legacy assignments. */
roboHTML = function roboHTMLV2(size='large'){
  return `<div class="robot-stage robot-${size} robo-mood-${roboMood()}" aria-label="Magnus AI assistant" role="img"><div class="robo-character"><span class="robo-glow"></span><span class="robo-head"><i class="robo-face-line"></i><i class="robo-eye left"></i><i class="robo-eye right"></i></span><span class="robo-body"><i class="robo-chest"></i></span><i class="robo-arm left"></i><i class="robo-arm right"><i class="robo-hand"></i></i></div></div>`;
};
openHelpDesk = function openHelpDeskV2(){
  const missing=roboMissing(); const next=roboNextAction(); const context=roboContextKey(); const readiness=germanyReadinessScore(); const q=state.qualification;
  const proactive=missing.length?`I noticed ${missing.length} evidence gap${missing.length>1?'s':''}. I can take you there now.`:(q&&q.status!=='QUALIFIED'?`Your latest qualification result is ${q.status}. I can explain exactly why and what to do next.`:`You are on ${context}. I’m ready to help with the next step.`);
  const moodLabel=roboMood()==='attention'?'Attention needed':roboMood()==='thinking'?'Checking your journey':roboMood()==='success'?'Journey complete':'Ready to help';
  openRoboModal('Magnus AI Help Desk',`
    <div class="assistant-head">${roboHTML('large')}<div><h3 style="margin:0 0 5px">Hi! I’m Magnus.</h3><div class="robo-status"><span class="dot"></span>${moodLabel} · ${esc(context)} · ${readiness}/100 readiness</div><p class="small" style="margin-top:7px">I stay with you through the journey and explain what to do next.</p></div></div>
    <div class="robo-proactive">${roboHTML('small')}<div><b>${esc(proactive)}</b><span>${esc(next.desc)}</span></div></div>
    <div class="robo-context"><div class="robo-context-card"><h4>What should I do next?</h4><p>${esc(next.label)} — ${esc(next.desc)}</p><button class="btn secondary" style="margin-top:8px" onclick="openRoboNext()">Take me there →</button></div><div class="robo-context-card"><h4>Current stage</h4><p><b>${esc(context)}</b><br>${esc(STEPS[currentIndex()]?.title||'Journey')}</p></div></div>
    <div id="roboChatLog" class="chat" style="margin-top:12px"><div class="chat-row"><div class="chat-bubble">🤖 ${esc(roboStageMessage())}</div></div></div>
    <div class="robo-action-grid">
      <button class="robo-action" onclick="openRoboMissingList()"><b>📄 Missing files</b><span>${missing.length?`${missing.length} item${missing.length>1?'s':''} need attention — I’ll show you where.`:'Check the Evidence Locker.'}</span></button>
      <button class="robo-action" onclick="openWhyNotEligible()"><b>❓ Why am I not eligible?</b><span>See the exact qualification gate and recovery action.</span></button>
      <button class="robo-action" onclick="openWhatIf()"><b>🔮 What-If Career</b><span>Test a scenario without changing your real profile.</span></button>
      <button class="robo-action" onclick="minimizeRoboAssistant();openVirtualInterview()"><b>🎤 Practice Interview</b><span>Train with Magnus using your own evidence.</span></button>
      <button class="robo-action" onclick="openRoboQualification()"><b>✅ Qualification standards</b><span>See the pathway rules and what is still unresolved.</span></button>
      <button class="robo-action" onclick="openProtectionCenter()"><b>🛡 Protection</b><span>Review identity, evidence and consent gates.</span></button>
    </div>
    <div class="robo-chat-compose"><input id="roboQuestion" placeholder="Ask Magnus about your current journey…" onkeydown="if(event.key==='Enter')openRoboChat()"><button class="btn primary" onclick="openRoboChat()">Ask</button></div>
  `,`<button class="btn secondary" onclick="minimizeRoboAssistant()">Minimize Magnus</button><button class="btn primary" onclick="openRoboNext()">Continue with my journey →</button>`);
};

/* Duplicate initial-load timer removed.
   The earlier guarded timer above opens Magnus only if the applicant is still on Start.
   This prevents a delayed Help Desk overlay from covering the Evidence/Continue controls. */



/* Restore the original milestone-based journey navigation.
   Completed milestones unlock the relevant next stages; the UI no longer marks every
   non-active step as locked. Existing business gates still remain enforced on actions. */
function renderMilestoneNavigation(){
  nav();
  stepper();
  header();
  const map={start:pageStart,profile:pageProfile,evidence:pageEvidence,video:pageVideo,qualification:pageQualification,next:pageNext,resume:pageResume,outreach:pageOutreach,interview:pageInterview};
  (map[state.current]||pageStart)();
}
render=renderMilestoneNavigation;
render();


/* =========================================================
   MAGNUS LIVE ERROR / CORRECTION FEEDBACK V3
   Wrong/missing -> red head + fly to target.
   Corrected -> green blink for 5 seconds + success state.
   ========================================================= */
function roboInitSignal(){
  if(!state.roboSignal || !state.roboSignal.kind){
    state.roboSignal={kind:'ready',message:'',target:null,until:0};
  }
  if(state.roboSignal.kind==='success' && state.roboSignal.until && Date.now()>state.roboSignal.until){
    state.roboSignal={kind:'ready',message:'',target:null,until:0};
  }
}
roboInitSignal();

function roboSignalMood(){
  roboInitSignal();
  // The robot colour is event-driven: an explicit mistake makes it red,
  // a correction makes it green for 5 seconds, then it returns to white.
  if(state.roboSignal.kind==='success' && Date.now()<state.roboSignal.until) return 'success';
  if(state.roboSignal.kind==='attention') return 'attention';
  return 'ready';
}
roboMood=roboSignalMood;

function roboSetAttention(message,targetSelector){
  state.roboSignal={kind:'attention',message:message||'Something needs attention.',target:targetSelector||null,until:0};
  safeSave();
  refreshRoboVisuals();
  if(targetSelector) setTimeout(()=>roboFlyToTarget(targetSelector,message,'attention'),120);
}

function roboSetSuccess(message,targetSelector){
  const until=Date.now()+5000;
  state.roboSignal={kind:'success',message:message||'Corrected.',target:targetSelector||null,until};
  safeSave();
  refreshRoboVisuals();
  if(targetSelector) setTimeout(()=>roboFlyToTarget(targetSelector,message,'success'),120);
  clearTimeout(window.__roboGreenTimer);
  window.__roboGreenTimer=setTimeout(()=>{
    if(state.roboSignal.kind==='success' && Date.now()>=state.roboSignal.until){
      state.roboSignal={kind:'ready',message:'',target:null,until:0};
      safeSave(); refreshRoboVisuals();
    }
  },5100);
}

function refreshRoboVisuals(){
  const mood=roboSignalMood();
  document.querySelectorAll('.robot-stage').forEach(el=>{
    el.classList.remove('robo-mood-ready','robo-mood-attention','robo-mood-thinking','robo-mood-success');
    el.classList.add('robo-mood-'+mood);
  });
  const fab=document.getElementById('roboFab');
  if(fab){
    fab.classList.toggle('robo-alert',mood==='attention');
    fab.classList.toggle('robo-attention',mood==='attention');
    fab.classList.toggle('robo-success',mood==='success');
    fab.classList.toggle('robo-thinking',mood==='thinking');
  }
}

function ensureRoboFlightLayer(){
  let layer=document.getElementById('roboFlightLayer');
  if(!layer){layer=document.createElement('div');layer.id='roboFlightLayer';layer.className='robo-flight-layer';document.body.appendChild(layer);}
  return layer;
}

function roboFlyToTarget(targetSelector,message,kind){
  const target=typeof targetSelector==='string'?document.querySelector(targetSelector):targetSelector;
  if(!target)return;
  try{target.scrollIntoView({behavior:'smooth',block:'center'});}catch(e){}
  setTimeout(()=>{
    const fab=document.getElementById('roboFab');
    const source=(fab||document.body).getBoundingClientRect();
    const tr=target.getBoundingClientRect();
    const sx=source.left+source.width/2-95, sy=source.top+source.height/2-95;
    const tx=tr.left+tr.width/2-95, ty=tr.top+Math.min(tr.height/2,50)-95;
    const layer=ensureRoboFlightLayer();
    layer.innerHTML=`<div class="robo-flight ${kind||'attention'}" style="left:${sx}px;top:${sy}px;transform:translate(0,0) rotate(0deg) scale(.72)">${roboHTML('small')}<div class="robo-flight-label">${esc(message||'Magnus is showing this')}</div></div>`;
    const fly=layer.firstElementChild;
    requestAnimationFrame(()=>requestAnimationFrame(()=>{fly.style.transform=`translate(${tx-sx}px,${ty-sy}px) rotate(3deg) scale(1)`;}));
    clearTimeout(window.__roboFlightTimer);
    window.__roboFlightTimer=setTimeout(()=>{
      fly.style.opacity='0';
      setTimeout(()=>{if(layer.contains(fly)) layer.removeChild(fly);},220);
    },1450);
  },380);
}

function roboSelectorForProfile(key){
  if(key==='goal') return '.goal-grid';
  return `[data-profile-key="${CSS.escape(key)}"]`;
}
function roboFindFieldError(){
  const errs=profileValidationErrors();
  return errs[0]||null;
}

/* Wrap the real profile setter so invalid/corrected changes trigger Magnus. */
const __roboBaseSetProfile = setProfile;
setProfile=function(k,v){
  const beforeValue=String(state.profile?.[k]??'').trim();
  const beforeErr=(PROFILE_RULES[k]?PROFILE_RULES[k](beforeValue):'');
  __roboBaseSetProfile(k,v);
  const afterValue=String(state.profile?.[k]??'').trim();
  const afterErr=(PROFILE_RULES[k]?PROFILE_RULES[k](afterValue):'');
  const selector=roboSelectorForProfile(k);
  if(afterErr){
    roboSetAttention(afterErr,selector);
  }else if(beforeErr && !afterErr){
    roboSetSuccess('Corrected ✓',selector);
    const el=document.querySelector(selector);
    if(el){el.classList.remove('field-invalid');el.classList.add('field-valid');setTimeout(()=>el.classList.remove('field-valid'),5000);}
  }
};

/* Continue button: show Magnus exactly where the first remaining error is. */
const __roboBaseCompleteProfile = completeProfile;
completeProfile=function(){
  const errs=profileValidationErrors();
  if(errs.length){
    const err=errs[0];
    roboSetAttention(err.error,roboSelectorForProfile(err.key));
  }
  return __roboBaseCompleteProfile();
};

/* Evidence page: after render, proactively show the first missing core item. */
const __roboBasePageEvidence = pageEvidence;
pageEvidence=function(){
  if(document.querySelector('#modalRoot .robo-assistant-modal')) minimizeRoboAssistant();
  __roboBasePageEvidence();
  setTimeout(()=>{
    const missing=roboMissing();
    if(!missing.length)return;
    const labels={education:'Degree / qualification evidence',language:'Language evidence',experience:'Experience evidence'};
    const item=missing[0];
    const target=[...document.querySelectorAll('.rule,.card')].find(el=>((el.textContent||'').includes(labels[item.key]||item.label)));
    if(target){target.setAttribute('data-robo-target','missing-'+item.key);target.classList.add('robo-focus');roboSetAttention(item.label,'[data-robo-target="missing-'+item.key+'"]');}
  },650);
};

/* File upload: rejected files -> red robot at upload area; accepted file -> green for 5s. */
const __roboBaseHandleFiles = handleFiles;
handleFiles=function(files){
  const before=state.evidence.documents.length;
  __roboBaseHandleFiles(files);
  const attempted=(files||[]).length;
  setTimeout(()=>{
    const after=state.evidence.documents.length;
    const upload=document.querySelector('.upload-area');
    const sel='.upload-area';
    if(after<before+attempted){
      roboSetAttention('This file could not be accepted. Check the file type, size or document.',sel);
    }else if(after>before){
      roboSetSuccess('Evidence added ✓',sel);
    }
  },220);
};

/* Human document review -> green feedback for 5 seconds when a gap is resolved. */
if(typeof reviewDocument==='function'){
  const __roboBaseReviewDocument=reviewDocument;
  reviewDocument=function(i){
    const wasReviewed=!!state.evidence.smartDocuments?.[i]?.reviewed;
    __roboBaseReviewDocument(i);
    const nowReviewed=!!state.evidence.smartDocuments?.[i]?.reviewed;
    if(!wasReviewed && nowReviewed){
      const item=document.querySelectorAll('.smart-doc')[i] || document.querySelector('.card');
      roboSetSuccess('Evidence reviewed ✓',item||null);
    }
  };
}

/* Qualification result: fly to the exact first failed rule or celebrate pass. */
const __roboBaseRunQualification = runQualification;
runQualification=function(){
  __roboBaseRunQualification();
  setTimeout(()=>{
    const q=state.qualification;
    if(!q)return;
    if(q.status==='QUALIFIED'){
      const target=document.querySelector('.result.good,.qualification-result,.result');
      roboSetSuccess('Qualification passed ✓',target||null);
      return;
    }
    const first=q.missing?.[0];
    if(first){
      const target=[...document.querySelectorAll('.rule,.criteria,.result')].find(el=>((el.textContent||'').includes(first.label)));
      if(target){
        target.classList.add('robo-focus');
        target.setAttribute('data-robo-qual-gate','first');
        roboSetAttention(first.label,'[data-robo-qual-gate="first"]');
      }
    }
  },450);
};

/* Missing-files action: Magnus flies to the exact item after navigation. */
const __roboBaseRoboShowMissing=roboShowMissing;
roboShowMissing=function(key){
  state.roboSignal={kind:'attention',message:'Missing evidence',target:null,until:0};
  safeSave();
  __roboBaseRoboShowMissing(key);
  setTimeout(()=>{
    const labels={education:'Degree / qualification evidence',language:'Language evidence',experience:'Experience evidence'};
    const target=[...document.querySelectorAll('.rule,.card')].find(el=>((el.textContent||'').includes(labels[key]||key)));
    if(target){target.setAttribute('data-robo-target','manual-'+key);target.classList.add('robo-focus');roboFlyToTarget('[data-robo-target="manual-'+key+'"]','Missing / needs review','attention');}
    refreshRoboVisuals();
  },500);
};

/* Fresh load: clear transient visual state only; applicant data stays saved. */
state.roboSignal={kind:'ready',message:'',target:null,until:0};
safeSave();
refreshRoboVisuals();

/* =========================================================
   TARGETED PROFILE + QUALIFICATION HANDOFF FIX
   Only touches profile-dependent downstream state and the
   qualification -> next-step handoff. Other modules unchanged.
   ========================================================= */
function invalidateProfileDependentJourney(reason){
  const hadDownstream=!!(state.qualification||state.resumeApproved||state.outreachSent||state.educaroForwarded||state.interviewOffer||state.notified);
  if(hadDownstream){
    state.qualification=null;
    state.resumeApproved=false;
    state.outreachSent=false;
    state.educaroForwarded=false;
    state.interviewOffer=false;
    state.notified=false;
    state.interviewOfferData=null;
    state.protection = state.protection || {};
    state.protection.evidenceReview=false;
    state.protection.consent=false;
    state.protection.educaroReview=false;
    log('Qualification and downstream routing reset after profile change: '+reason);
  }
}

const _selectGoalStable = selectGoal;
selectGoal = function(g){
  if(state.goal!==g) invalidateProfileDependentJourney('pathway changed');
  state.goal=g;
  log('Pathway selected: '+g);
  safeSave();
  render();
};

const _setProfileStable = setProfile;
setProfile = function(k,v){
  const old=state.profile?.[k];
  if(String(old??'')!==String(v??'') && ['field','occupation','education','graduation','experienceYears','experienceRole','languageLevel','studyLanguage','recognitionReviewed','availability'].includes(k)){
    invalidateProfileDependentJourney(k+' changed');
  }
  // Keep the existing validated setter + Magnus live-error flight behavior intact.
  return _setProfileStable(k,v);
};

function addQualificationNextAction(){
  if(state.current!=='qualification') return;
  const q=state.qualification;
  const host=document.querySelector('.gate .actions');
  if(!host || document.getElementById('qualificationNextAction')) return;
  const wrap=document.createElement('div');
  wrap.id='qualificationNextAction';
  wrap.style.cssText='display:flex;justify-content:flex-end;gap:8px;margin-top:8px;flex-wrap:wrap;';
  if(q?.status==='QUALIFIED'){
    wrap.innerHTML='<button class="btn primary" onclick="go(\'next\')">Continue to Next Step →</button>';
  } else if(q?.status==='NEEDS EVIDENCE' || q?.status==='BLOCKED'){
    wrap.innerHTML='<button class="btn secondary" onclick="go(\'next\')">View recovery plan →</button>';
  }
  host.appendChild(wrap);
}

const _renderStable = render;
render = function(){
  _renderStable();
  setTimeout(addQualificationNextAction,0);
};

/* Prevent stale qualification from surviving a core profile edit. */
try { setTimeout(addQualificationNextAction,0); } catch(e) {}


/* =========================================================
   MAGNUS CUSTOM AUDIO VOICE SOURCE
   Uses the user-provided audio sample for Magnus' vocal playback.
   Note: a prerecorded clip cannot synthesize arbitrary new sentences;
   dynamic text remains available through browser speech synthesis.
   ========================================================= */
let magnusAudioSample=null;
let magnusAudioSampleReady=false;
function magnusLoadAudioSample(){
  if(magnusAudioSample) return magnusAudioSample;
  magnusAudioSample=new Audio('assets/magnus-voice-sample.webm');
  magnusAudioSample.preload='auto';
  magnusAudioSample.onloadeddata=()=>{magnusAudioSampleReady=true;};
  magnusAudioSample.onended=()=>magnusSetSpeakingUI(false);
  magnusAudioSample.onerror=()=>{magnusAudioSampleReady=false;};
  return magnusAudioSample;
}
function magnusPlayVoiceSample(){
  const a=magnusLoadAudioSample();
  if(!a) return false;
  try{
    if('speechSynthesis' in window) window.speechSynthesis.cancel();
    a.currentTime=0;
    a.play().then(()=>magnusSetSpeakingUI(true)).catch(()=>{
      toast('Click Hear Magnus to allow audio playback.');
    });
    return true;
  }catch(e){ return false; }
}
function magnusStopVoiceSample(){
  try{
    if(magnusAudioSample){magnusAudioSample.pause(); magnusAudioSample.currentTime=0;}
  }catch(e){}
  magnusSetSpeakingUI(false);
}
const MAGNUS_AUDIO_VOICE_URL='assets/magnus-voice-sample.webm';

/* =========================================================
   MAGNUS VOICE ASSISTANT
   Browser-native speech synthesis: no API key required.
   Voice is enabled by default after a user interaction; if the
   browser blocks autoplay, the user can press "Hear Magnus".
   ========================================================= */
function magnusVoiceEnabled(){
  if(typeof state.magnusVoice!=='boolean') state.magnusVoice=true;
  return state.magnusVoice;
}
function magnusSetVoiceEnabled(enabled){
  state.magnusVoice=!!enabled;
  safeSave();
  if(!enabled) magnusStopSpeaking();
  refreshMagnusVoiceControls();
}
function magnusPickVoice(){
  if(!('speechSynthesis' in window)) return null;
  const voices=window.speechSynthesis.getVoices?.()||[];
  return voices.find(v=>/^en-IN$/i.test(v.lang))
      || voices.find(v=>/^en-GB$/i.test(v.lang))
      || voices.find(v=>/^en-US$/i.test(v.lang))
      || voices[0]
      || null;
}
function magnusSetSpeakingUI(on){
  document.querySelectorAll('.robot-stage').forEach(el=>el.classList.toggle('robo-speaking',!!on));
  const fab=document.getElementById('roboFab');
  if(fab) fab.classList.toggle('robo-speaking',!!on);
}
function magnusStopSpeaking(){
  magnusStopVoiceSample();
  try{
    if('speechSynthesis' in window) window.speechSynthesis.cancel();
  }catch(e){}
  magnusSetSpeakingUI(false);
}
function magnusSpeak(text){
  if(!magnusVoiceEnabled()) return false;
  if(!text || !String(text).trim()) return false;
  if(!('speechSynthesis' in window)){
    toast('Voice is not supported by this browser.');
    return false;
  }
  magnusStopSpeaking();
  const clean=String(text).replace(/\s+/g,' ').trim().slice(0,420);
  const u=new SpeechSynthesisUtterance(clean);
  const voice=magnusPickVoice();
  if(voice) u.voice=voice;
  u.lang=voice?.lang || 'en-IN';
  u.rate=.96;
  u.pitch=1.04;
  u.volume=.96;
  u.onstart=()=>magnusSetSpeakingUI(true);
  u.onend=()=>magnusSetSpeakingUI(false);
  u.onerror=()=>magnusSetSpeakingUI(false);
  window.speechSynthesis.speak(u);
  return true;
}
function magnusVisibleText(){
  const root=document.querySelector('.robo-assistant-modal');
  if(!root) return '';
  const bubble=[...root.querySelectorAll('.chat-bubble')].pop();
  if(bubble) return bubble.textContent||'';
  const q=root.querySelector('.question-box h4');
  if(q) return q.textContent||'';
  const proactive=root.querySelector('.robo-proactive b');
  return proactive?.textContent||'';
}
function refreshMagnusVoiceControls(){
  document.querySelectorAll('[data-magnus-voice-label]').forEach(el=>{
    el.textContent=magnusVoiceEnabled()?'🔊 Voice on':'🔇 Voice off';
  });
}
function magnusAddVoiceControls(){
  const head=document.querySelector('.robo-assistant-modal .modal-head');
  if(!head || head.querySelector('.robo-voice-controls')) return;
  const actions=head.querySelector('.robo-head-actions');
  if(!actions) return;
  const wrap=document.createElement('div');
  wrap.className='robo-voice-controls';
  wrap.innerHTML=`<button class="robo-voice-btn" type="button" onclick="magnusPlayVoiceSample()" title="Play uploaded Magnus voice sample">🔊 Play voice</button><button class="robo-voice-btn" type="button" onclick="magnusSpeak(magnusVisibleText())" title="Hear Magnus speak">▶ Hear Magnus</button><button class="robo-voice-btn" type="button" data-magnus-voice-label onclick="magnusSetVoiceEnabled(!magnusVoiceEnabled())">${magnusVoiceEnabled()?'🔊 Voice on':'🔇 Voice off'}</button><button class="robo-voice-btn" type="button" onclick="magnusStopSpeaking()" title="Stop Magnus">■ Stop</button>`;
  actions.parentElement.insertBefore(wrap, actions);
  refreshMagnusVoiceControls();
}

const __magnusBaseOpenRoboModalVoice=openRoboModal;
openRoboModal=function(title,body,actions=''){
  __magnusBaseOpenRoboModalVoice(title,body,actions);
  magnusAddVoiceControls();
};

const __magnusBaseOpenHelpDeskVoice=openHelpDesk;
openHelpDesk=function(){
  __magnusBaseOpenHelpDeskVoice();
  setTimeout(()=>{
    magnusAddVoiceControls();
    if(magnusVoiceEnabled()){
      const first=document.querySelector('.robo-assistant-modal .chat-bubble')?.textContent
        || document.querySelector('.robo-assistant-modal .robo-proactive b')?.textContent;
      if(first){magnusPlayVoiceSample(); setTimeout(()=>magnusSpeak(first),120); }
    }
  },180);
};

const __magnusBaseOpenRoboChatVoice=openRoboChat;
openRoboChat=function(){
  __magnusBaseOpenRoboChatVoice();
  setTimeout(()=>magnusSpeak(magnusVisibleText()),80);
};

const __magnusBaseSetAttentionVoice=roboSetAttention;
roboSetAttention=function(message,targetSelector){
  __magnusBaseSetAttentionVoice(message,targetSelector);
  setTimeout(()=>magnusSpeak(message||'I found something that needs your attention.'),120);
};

const __magnusBaseSetSuccessVoice=roboSetSuccess;
roboSetSuccess=function(message,targetSelector){
  __magnusBaseSetSuccessVoice(message,targetSelector);
  setTimeout(()=>magnusSpeak(message||'Great, that is corrected.'),120);
};

const __magnusBaseOpenVirtualInterviewVoice=openVirtualInterview;
openVirtualInterview=function(){
  __magnusBaseOpenVirtualInterviewVoice();
  setTimeout(()=>{
    const q=document.querySelector('.robo-assistant-modal .question-box h4')?.textContent
      || 'Let us start your practice interview.';
    magnusSpeak(q);
  },160);
};

const __magnusBaseRoboShowMissingVoice=roboShowMissing;
roboShowMissing=function(key){
  __magnusBaseRoboShowMissingVoice(key);
  setTimeout(()=>magnusSpeak(`I am taking you to the ${String(key).replace(/([A-Z])/g,' $1').toLowerCase()} evidence item.`),200);
};

const __magnusBaseMinimizeVoice=minimizeRoboAssistant;
minimizeRoboAssistant=function(){
  magnusStopSpeaking();
  __magnusBaseMinimizeVoice();
};

if('speechSynthesis' in window){
  window.speechSynthesis.onvoiceschanged=()=>{ /* refresh voice list when browser loads voices */ };
}

/* =========================================================
   STEP 10 — GERMAN MISSION IN INDIA
   Source basis: German Federal Foreign Office, German Missions in India.
   ========================================================= */
DEFAULT.mission={state:'',missionId:'',viewed:false};
state.mission=state.mission||{state:'',missionId:'',viewed:false};

const GERMAN_MISSIONS_INDIA=[
  {id:'new-delhi',name:'German Embassy New Delhi',city:'New Delhi',states:['Haryana','Himachal Pradesh','Punjab','Rajasthan','Sikkim','Uttar Pradesh','Uttarakhand','Chandigarh','Delhi','Jammu and Kashmir','Ladakh','Andaman and Nicobar Islands','Lakshadweep'],address:'No. 6/50G, Shanti Path, Chanakyapuri, New Delhi 110021',website:'https://india.diplo.de/in-en/ueber-uns',jurisdiction:'Haryana, Himachal Pradesh, Punjab, Rajasthan, Sikkim, Uttar Pradesh, Uttarakhand and the Union Territories of Chandigarh, Delhi, Jammu and Kashmir, Ladakh, Andaman and Nicobar Islands and Lakshadweep.'},
  {id:'bengaluru',name:'German Consulate General Bengaluru',city:'Bengaluru',states:['Karnataka','Kerala'],address:'2nd & 3rd Floor, “Cash Pharmacy Building”, Corner St. Marks & Residency Road, Bengaluru 560025, Karnataka',website:'https://india.diplo.de/in-en/ueber-uns/bengaluru',jurisdiction:'Karnataka and Kerala.'},
  {id:'chennai',name:'German Consulate General Chennai',city:'Chennai',states:['Tamil Nadu','Andhra Pradesh','Telangana','Puducherry'],address:'No. 9 Boat Club Road, R.A. Puram, Chennai 600028, Tamil Nadu',website:'https://india.diplo.de/in-en/ueber-uns/chennai',jurisdiction:'Tamil Nadu, Andhra Pradesh, Telangana and the Union Territory of Puducherry.'},
  {id:'kolkata',name:'German Consulate General Kolkata',city:'Kolkata',states:['West Bengal','Bihar','Jharkhand','Odisha','Assam','Arunachal Pradesh','Manipur','Meghalaya','Mizoram','Nagaland','Tripura'],address:'1 Hastings Park Road, Alipore, Kolkata (Calcutta) 700 027',website:'https://india.diplo.de/in-en/ueber-uns/kolkata',jurisdiction:'West Bengal, Bihar, Jharkhand, Odisha, Assam, Arunachal Pradesh, Manipur, Meghalaya, Mizoram, Nagaland and Tripura.'},
  {id:'mumbai',name:'German Consulate General Mumbai',city:'Mumbai',states:['Maharashtra','Chhattisgarh','Gujarat','Goa','Madhya Pradesh','Dadra and Nagar Haveli and Daman and Diu'],address:'Hoechst House, 10th Floor, 193 Backbay Reclamation, Nariman Point, Mumbai 400021',website:'https://india.diplo.de/in-en/ueber-uns/mumbai',jurisdiction:'Maharashtra, Chhattisgarh, Gujarat, Goa, Madhya Pradesh and the Union Territories of Daman and Diu and Dadra and Nagar Haveli.'}
];

const MISSION_STATES=GERMAN_MISSIONS_INDIA.flatMap(m=>m.states.map(s=>({state:s,missionId:m.id}))).sort((a,b)=>a.state.localeCompare(b.state));
function missionForState(name){return GERMAN_MISSIONS_INDIA.find(m=>m.states.includes(name))||null}
function setMissionState(name){
  state.mission.state=name;
  state.mission.missionId=missionForState(name)?.id||'';
  state.mission.viewed=false;
  save(); render();
}
function markMissionViewed(){
  if(!state.mission?.missionId){toast('Select your Indian state first');return}
  state.mission.viewed=true;
  log(`German Mission identified: ${missionForState(state.mission.state)?.name||'Mission selected'}`);
  save(); render(); toast('German Mission saved');
}
function openOfficialMission(){
  const m=missionForState(state.mission.state);
  if(m) window.open(m.website,'_blank','noopener');
}
function openOfficialConsularPortal(){
  window.open('https://india.diplo.de/in-en/service/2755482-2755482','_blank','noopener');
}
function openOfficialAppointments(){
  window.open('https://india.diplo.de/in-en/service/2448866-2448866','_blank','noopener');
}
function pageGermanMission(){
  const selected=missionForState(state.mission?.state||'');
  const options=MISSION_STATES.map(x=>`<option value="${esc(x.state)}" ${state.mission?.state===x.state?'selected':''}>${esc(x.state)}</option>`).join('');
  const journeyChecks=[
    ['Qualification completed',!!state.qualification && state.qualification.status==='Qualified'],
    ['Educaro routing completed',!!state.educaroForwarded],
    ['Interview detected',!!state.interviewOffer],
    ['Applicant notification',!!state.notified]
  ];
  document.getElementById('app').innerHTML=`
    <div class="section-head"><div><span class="pill">STEP 10 · GERMAN MISSION IN INDIA</span><h2 style="margin-top:9px">Find the German mission responsible for your residence.</h2><p>This guidance layer sits after the interview stage and links the applicant to official German government information.</p></div><span class="pill blue">OFFICIAL SOURCES</span></div>
    <div class="mission-banner"><div class="mission-kicker" style="color:#cfc7ff">GERMAN MISSIONS IN INDIA</div><h2 style="margin:7px 0 5px;color:#fff">Your next practical step: find the competent mission.</h2><p style="color:#d7ddea;max-width:700px;margin:0">Select your Indian state or Union Territory. Magnus will identify the German Embassy / Consulate responsible for that area and take you to the official source.</p></div>
    <div class="mission-shell" style="margin-top:14px">
      <div>
        <div class="mission-card"><div class="mission-kicker">1 · SELECT RESIDENCE</div><h3 style="margin-top:8px">Where do you currently reside in India?</h3><select class="mission-state-select" onchange="setMissionState(this.value)"><option value="">Select a state / union territory</option>${options}</select>
        <div class="mission-meta"><span class="pill">${selected?'Mission found':'Waiting for selection'}</span>${selected?`<span class="pill green">${esc(selected.city)}</span>`:''}</div></div>
        ${selected?`<div class="mission-card" style="margin-top:12px"><div class="mission-kicker">2 · RESPONSIBLE MISSION</div><h2 style="margin:7px 0">${esc(selected.name)}</h2><p class="small"><b>Consular jurisdiction:</b> ${esc(selected.jurisdiction)}</p><p class="small"><b>Address:</b> ${esc(selected.address)}</p><div class="mission-actions"><button class="btn primary" onclick="openOfficialMission()">Open official mission →</button><button class="btn secondary" onclick="openOfficialConsularPortal()">Consular Service Portal</button><button class="btn secondary" onclick="openOfficialAppointments()">Appointment information</button></div><div class="mission-source">Mission information sourced from the German Federal Foreign Office. Confirm current jurisdiction, opening hours and appointment rules on the official website before applying.</div></div>`:`<div class="mission-card" style="margin-top:12px"><h3>Mission finder</h3><p class="small">Choose your Indian state above to see the responsible German mission.</p></div>`}
      </div>
      <div>
        <div class="mission-card"><div class="mission-kicker">YOUR JOURNEY STATUS</div><h3 style="margin-top:8px">What is already complete?</h3>${journeyChecks.map(x=>`<div class="mission-mini" style="margin-top:8px"><span>${x[0]}</span><span class="status ${x[1]?'verified':'pending'}">${x[1]?'✓ Done':'Pending'}</span></div>`).join('')}</div>
        <div class="mission-card" style="margin-top:12px"><div class="mission-kicker">3 · SAVE YOUR MISSION</div><h3 style="margin-top:8px">Keep the official route with your journey.</h3><p class="small">Saving this mission does not submit a visa application. It only records which German mission is responsible for the residence state selected above.</p><button class="btn primary" onclick="markMissionViewed()" ${selected?'':'disabled'}>${state.mission?.viewed?'Mission saved ✓':'Save my mission →'}</button></div>
        <div class="mission-disclaimer"><b>Important:</b> This is a guidance interface inside EduGuide AI, not an official German government portal. Visa and consular decisions remain with the competent German authorities. Always verify the latest requirements and appointment information on the official German Foreign Office website.</div>
      </div>
    </div>`;
}

// Add the new step after the existing Interview step.
if(!STEPS.some(s=>s.id==='mission')) STEPS.push({id:'mission',short:'German Mission',title:'German Mission in India'});

// Keep all previous completion rules intact; only add the new final milestone.
const __baseDoneBeforeMission=done;
done=function(i){
  if(i===8) return !!state.interviewOffer;
  if(i===9) return !!state.mission?.viewed;
  return __baseDoneBeforeMission(i);
};

// Keep the existing flow intact but add one explicit handoff after an interview is detected.
const __basePageInterviewBeforeMission=pageInterview;
pageInterview=function(){
  __basePageInterviewBeforeMission();
  if(state.interviewOffer && document.getElementById('app')){
    document.getElementById('app').insertAdjacentHTML('beforeend',`<div class="card" style="margin-top:14px"><div class="section-head" style="margin-bottom:0"><div><span class="pill blue">NEXT AFTER INTERVIEW</span><h3 style="margin-top:8px">Find your German mission in India</h3><p class="small">We can now identify the official German mission responsible for your residence and open the official guidance.</p></div><button class="btn primary" onclick="go('mission')">German Mission in India →</button></div></div>`);
  }
};

// Update the intro/help wording without altering the existing journey behavior.
showHow=function(){toast('The guided sequence is Profile → Evidence → Video → Qualification → Next step → Resume → Educaro → Interview → German Mission')};

// Extend the renderer only to recognize the new final step.
const __baseRenderBeforeMission=render;
render=function(){
  if(state.current==='mission'){nav();stepper();header();pageGermanMission();}
  else __baseRenderBeforeMission();
};



/* =========================================================
   PERMANENT GUIDANCE MODULES — German Mission + Emigration Safety
   ========================================================= */
DEFAULT.emigration={viewed:false,agencyName:'',registrationNumber:'',registryChecked:false,employerChecked:false,contractChecked:false};
state.emigration=state.emigration||{viewed:false,agencyName:'',registrationNumber:'',registryChecked:false,employerChecked:false,contractChecked:false};
state.resource=state.resource||'';


if(!STEPS.some(s=>s.id==='emigration')) STEPS.push({id:'emigration',short:'Migration & Agencies',title:'Migration & Recruitment Safety'});
const __baseDoneBeforeAgencySafety=done;
done=function(i){
  if(i===10) return !!state.emigration?.viewed;
  return __baseDoneBeforeAgencySafety(i);
};



function openEmigrate(){window.open('https://emigrate.gov.in/','_blank','noopener')}
function openMEAEmploymentGuidance(){window.open('https://www.mea.gov.in/emigration-abroad-for-emp.htm','_blank','noopener')}
function openMEAComplaints(){window.open('https://www.mea.gov.in/complaints-against-recruiting-agents.htm','_blank','noopener')}
function openGermanFraudWarning(){window.open('https://india.diplo.de/in-en/ueber-uns/mumbai/beware-of-fraud-1988568','_blank','noopener')}
function setAgencyField(key,value){
  state.emigration=state.emigration||{};
  const e=state.emigration;
  const previous=e[key];
  // Changing the agency identity or RC number invalidates previous user-marked checks.
  if((key==='registrationNumber'||key==='customAgencyName') && previous!==value){
    e.registryChecked=false;
    e.employerChecked=false;
    e.contractChecked=false;
    if(key==='customAgencyName') e.registrationNumber='';
  }
  e[key]=value;
  safeSave();
}
function selectKnownAgency(value){
  state.emigration=state.emigration||{};
  const e=state.emigration;
  if(e.agencyName===value) return;
  e.agencyName=value;
  e.customAgencyName='';
  e.registrationNumber='';
  e.registryChecked=false;
  e.employerChecked=false;
  e.contractChecked=false;
  safeSave();
  render();
  toast('Agency changed. Re-enter and re-check its exact RC number on eMigrate.');
}
function toggleAgencyCheck(key,val){state.emigration=state.emigration||{};state.emigration[key]=!!val;safeSave();render()}
function markAgencyViewed(){
  state.emigration=state.emigration||{};
  state.emigration.viewed=true;
  log('Migration & recruitment safety guidance reviewed');
  safeSave(); render(); toast('Agency safety guidance saved');
}
function agencyRisk(){
  const e=state.emigration||{};
  const agencyName=e.agencyName==='Other'?(e.customAgencyName||''): (e.agencyName||'');
  if(['Relovect','Nent Latitude','Migrate X'].includes(agencyName)) return {tone:'amber',title:'Demo only — fictional agency',desc:'This is a fictional sample entry for demonstration. No real agency or licence is being represented, and no official registry check has been performed.'};
  if(!agencyName || !e.registrationNumber || !e.registryChecked) return {tone:'red',title:'Not verified',desc:'Do not treat this agency as verified until the exact registered name and active registration are checked on the official eMigrate portal.'};
  if(!e.employerChecked || !e.contractChecked) return {tone:'amber',title:'Verify more evidence',desc:'The registration may be valid, but the employer/job and contract still need independent verification.'};
  return {tone:'green',title:'Applicant-checked',desc:'The applicant has confirmed the registry, employer/job details and contract review. EduGuide AI does not issue government verification.'};
}
function pageEmigrationAgency(){
  const e=state.emigration||{}; const risk=agencyRisk();
  const isDemoAgency=['Relovect','Nent Latitude','Migrate X'].includes(e.agencyName);
  const checks=[
    ['Registration checked on official eMigrate registry',!!e.registryChecked],
    ['Foreign employer / job independently verified',!!e.employerChecked],
    ['Employment contract reviewed',!!e.contractChecked]
  ];
  document.getElementById('app').innerHTML=`
    <div class="section-head"><div><span class="pill">STEP 11 · MIGRATION & RECRUITMENT SAFETY</span><h2 style="margin-top:9px">Verify the people who offer to help you migrate.</h2><p>Use official government sources before paying an agency, sharing your passport, or accepting an overseas job offer.</p></div><span class="pill blue">FRAUD-SAFETY LAYER</span></div>
    <div class="mission-banner"><div class="mission-kicker" style="color:#cfc7ff">SAFE MIGRATION CHECK</div><h2 style="margin:7px 0 5px;color:#fff">Magnus helps you check the evidence — not endorse an agency.</h2><p style="color:#d7ddea;max-width:740px;margin:0">A “verified” badge in this prototype never means government approval. It means the applicant completed the listed checks against official sources.</p></div>
    <div class="security-grid" style="margin-top:14px">
      <div class="security-card ${risk.tone}"><div class="mission-kicker">AGENCY STATUS</div><h3 style="margin-top:8px">${risk.title}</h3><p>${risk.desc}</p></div>
      <div class="security-card"><div class="mission-kicker">OFFICIAL CHECK</div><h3 style="margin-top:8px">Use the Government registry</h3><p>For overseas employment, check whether the Recruiting Agent is registered and that the registration is valid. Use the official eMigrate portal before dealing with the agent.</p><div class="mission-actions" style="margin-top:10px"><button class="btn primary" onclick="openEmigrate()">Open eMigrate →</button><button class="btn secondary" onclick="openMEAEmploymentGuidance()">MEA safety guidance</button></div></div>
    </div>
    <div class="card" style="margin-top:14px"><div class="section-head" style="margin-bottom:10px"><div><h3>Agency / offer you are checking</h3><p class="small">${isDemoAgency ? 'DEMO DATA: Relovect, Nent Latitude and Migrate X are fictional sample names created only to demonstrate this interface. They are not real or recommended agencies, and no licence is assigned to them.' : 'These fields are applicant-entered; EduGuide does not claim live verification unless the official registry is checked. Use the exact legal name from official records.'}</p></div></div>
      <div class="agency-check"><label class="field"><span>Agency name</span><select onchange="selectKnownAgency(this.value)" aria-label="Choose migration agency">
        <option value="" ${!e.agencyName?'selected':''}>Choose an agency…</option>
        <option value="Relovect" ${e.agencyName==='Relovect'?'selected':''}>Relovect (Demo)</option>
        <option value="Nent Latitude" ${e.agencyName==='Nent Latitude'?'selected':''}>Nent Latitude (Demo)</option>
        <option value="Migrate X" ${e.agencyName==='Migrate X'?'selected':''}>Migrate X (Demo)</option>
        <option value="Other" ${e.agencyName==='Other'||(e.agencyName&&!['Relovect','Nent Latitude','Migrate X'].includes(e.agencyName))?'selected':''}>Other / enter manually</option>
      </select>${(e.agencyName==='Other'||(e.agencyName&&!['Relovect','Nent Latitude','Migrate X'].includes(e.agencyName)))?`<input style="margin-top:8px" value="${esc(e.customAgencyName || (e.agencyName==='Other'?'':e.agencyName) || '')}" oninput="setAgencyField('customAgencyName',this.value)" placeholder="Enter the exact registered agency name">`:''}</label>
      <label class="field"><span>${isDemoAgency ? 'Demo reference (not a real licence number)' : 'MEA / eMigrate Registration Certificate (RC) number'}</span><input autocomplete="off" value="${esc(e.registrationNumber||'')}" oninput="setAgencyField('registrationNumber',this.value.trim())" placeholder="${isDemoAgency ? 'Fictional demo only — no RC number' : 'Enter exact RC number from eMigrate'}"><small class="small" style="display:block;margin-top:6px">${isDemoAgency ? 'Do not enter or infer a real licence number for a fictional demo agency. Select Other / enter manually to check a real agency.' : 'Enter the exact RC number from official records. Changing the agency clears the previous number and review ticks.'}</small></label></div>
      <div class="source-strip" style="margin-top:10px"><b>${isDemoAgency ? 'DEMO ONLY:' : 'Important:'}</b> ${isDemoAgency ? 'This selection is fictional. The checklist below is a UI demonstration only; it cannot verify or endorse the demo name.' : 'This is not an endorsement or proof of licensing. Confirm the exact legal name, RC number, validity and status on the official eMigrate registry before paying or sharing documents.'}</div>
      <div class="mission-kicker" style="margin-top:12px">${isDemoAgency ? 'SIMULATED DEMO CHECKS — NOT OFFICIAL VERIFICATION' : 'APPLICANT CHECKLIST'}</div><div class="safety-list" style="margin-top:8px">${checks.map((c,i)=>`<label class="check"><input type="checkbox" ${c[1]?'checked':''} onchange="toggleAgencyCheck('${['registryChecked','employerChecked','contractChecked'][i]}',this.checked)">${c[0]}</label>`).join('')}</div>
      <div class="actions" style="margin-top:12px"><button class="btn primary" onclick="markAgencyViewed()">Save safety review →</button></div>
    </div>
    <div class="security-grid" style="margin-top:14px">
      <div class="security-card red"><div class="mission-kicker">DO NOT DO THIS</div><div class="safety-list">
        <div class="safety-row"><b>✕</b><span>Do not use an unregistered or suspended recruiting agent.</span></div>
        <div class="safety-row"><b>✕</b><span>Do not hand over your passport, certificates or money before the job and employer are established as genuine.</span></div>
        <div class="safety-row"><b>✕</b><span>Do not deal with sub-agents for overseas recruitment.</span></div>
        <div class="safety-row"><b>✕</b><span>Do not trust anyone who claims they can guarantee a German visa or influence a German mission.</span></div>
      </div></div>
      <div class="security-card green"><div class="mission-kicker">CHECK THESE BEFORE PAYING</div><div class="safety-list">
        <div class="safety-row"><b>✓</b><span>Ask for the agent’s valid registration certificate and note the registration number.</span></div>
        <div class="safety-row"><b>✓</b><span>Verify the foreign employer and the job details independently.</span></div>
        <div class="safety-row"><b>✓</b><span>Ask for the Demand Letter / Power of Attorney where applicable and read the employment contract carefully.</span></div>
        <div class="safety-row"><b>✓</b><span>Get a receipt for payments and stay within the fee limits published by the Ministry of External Affairs.</span></div>
      </div></div>
    </div>
    <div class="card" style="margin-top:14px"><h3>What to do if something looks suspicious</h3><p class="small">You can check the official eMigrate registry and use the Ministry of External Affairs complaint / grievance channels for recruiting-agent issues.</p><div class="mission-actions" style="margin-top:10px"><button class="btn secondary" onclick="openMEAComplaints()">MEA complaints →</button><button class="btn secondary" onclick="openEmigrate()">eMigrate →</button></div></div>
    <div class="source-strip" style="margin-top:14px"><b>Safety note:</b> This section is based on official Ministry of External Affairs guidance for recruiting agents and overseas employment. It is an applicant checklist, not a government verification service.</div>
    <div class="actions" style="margin-top:14px"><button class="btn secondary" onclick="openResource('mission')">← German Mission in India</button><button class="btn primary" onclick="go('start')">Back to journey →</button></div>`;
}



const __basePageGermanMissionSafety=pageGermanMission;
pageGermanMission=function(){
  __basePageGermanMissionSafety();
  const host=document.getElementById('app');
  if(!host) return;
  host.insertAdjacentHTML('beforeend',`<div class="security-grid" style="margin-top:14px">
    <div class="security-card red"><div class="mission-kicker">FRAUD WARNING</div><h3 style="margin-top:8px">Only trust official German mission information.</h3><p>German Missions warn about imposters and local agents who claim they can sell visas or influence appointments. No local agent or student counsellor can influence or schedule a German visa appointment.</p></div>
    <div class="security-card green"><div class="mission-kicker">VISA SAFETY</div><h3 style="margin-top:8px">Use official channels</h3><p>National-visa forms and information are available through official German channels. Depending on the visa category, applications may be handled through VFS or the responsible German Mission; the visa decision remains with the German authorities.</p></div>
  </div>
  <div class="card" style="margin-top:14px"><h3>Before you submit anything</h3><div class="safety-list">
    <div class="safety-row"><b>1</b><span>Confirm that the mission shown for your current residence is the correct one.</span></div>
    <div class="safety-row"><b>2</b><span>Use only links from the official German Missions in India / Federal Foreign Office for visa information and appointments.</span></div>
    <div class="safety-row"><b>3</b><span>Never pay a third party who promises a guaranteed visa or priority appointment.</span></div>
    <div class="safety-row"><b>4</b><span>Do not submit false or altered documents. False information or documents can lead to refusal and other consequences.</span></div>
  </div></div>
  <div class="security-card amber" style="margin-top:14px"><div class="mission-kicker">IMPORTANT JURISDICTION NOTE</div><p><b>Visa applications:</b> responsibility is generally based on your current main place of residence in India. <b>Document verification:</b> the competent mission can depend on where the document was issued, which is different from visa jurisdiction.</p></div>
  <div class="actions" style="margin-top:14px"><button class="btn primary" onclick="openResource('emigration')">Next: Migration & Agency Safety →</button><button class="btn secondary" onclick="openGermanFraudWarning()">Official fraud warning →</button></div>`);
};



function renderResourceNav(){
  const el=document.getElementById('resourceNav'); if(!el)return;
  const current=state.resource||'';
  el.innerHTML=`<button class="resource-nav-btn ${current==='mission'?'active':''}" onclick="openResource('mission')"><span class="resource-icon">🇩🇪</span><span>German Mission in India</span><span class="resource-badge">OPEN</span></button><button class="resource-nav-btn ${current==='emigration'?'active':''}" onclick="openResource('emigration')"><span class="resource-icon">🛡</span><span>Migration & Agencies</span><span class="resource-badge">OPEN</span></button>`;
}
function openResource(id){state.resource=id;safeSave();render();}
const __baseNavBeforeResources=nav;
nav=function(){__baseNavBeforeResources();renderResourceNav();};
const __baseGoBeforeResources=go;
go=function(id){state.resource='';__baseGoBeforeResources(id);};
const __baseRenderBeforeResources=render;
render=function(){
  nav();
  if(state.resource==='mission'){stepper();document.getElementById('crumb').textContent='ALWAYS AVAILABLE';document.getElementById('topTitle').textContent='German Mission & Visa Guidance';pageGermanMission();return;}
  if(state.resource==='emigration'){stepper();document.getElementById('crumb').textContent='ALWAYS AVAILABLE';document.getElementById('topTitle').textContent='Migration & Recruitment Safety';pageEmigrationAgency();return;}
  __baseRenderBeforeResources();
};


render();

/* =========================================================
   ALWAYS-AVAILABLE RESOURCES + SCROLLABLE ROADMAP
   Scoped patch: only German Mission / Migration & Agencies navigation.
   All other journey locks continue to use the current milestone rules.
   ========================================================= */
const __goBeforeAlwaysAvailableResources = go;
go = function(id){
  if(id === 'mission' || id === 'emigration'){
    openResource(id);
    return;
  }
  return __goBeforeAlwaysAvailableResources(id);
};

const __navBeforeAlwaysAvailableResources = nav;
nav = function(){
  const host = document.getElementById('nav');
  if(host){
    host.innerHTML = STEPS.map((s,i)=>{
      const alwaysAvailable = s.id === 'mission' || s.id === 'emigration';
      const canOpen = alwaysAvailable || unlocked(s.id);
      const active = alwaysAvailable ? state.resource === s.id : state.current === s.id;
      const isDone = done(i);
      const click = alwaysAvailable ? `openResource('${s.id}')` : (canOpen ? `go('${s.id}')` : '');
      const className = `nav ${active?'active':''} ${isDone?'done':''} ${!canOpen?'locked':''} ${alwaysAvailable?'resource-unlocked':''}`;
      const trailing = alwaysAvailable
        ? '<span class="nav-open-badge">OPEN</span>'
        : (canOpen ? '' : '<span class="lock">🔒</span>');
      return `<button class="${className}" ${canOpen?`onclick="${click}"`:'aria-disabled="true"'}><span class="step-dot">${isDone?'✓':i+1}</span><span>${s.short}</span>${trailing}</button>`;
    }).join('');
    const p = progress();
    const progressText = document.getElementById('sideProgress');
    const progressBar = document.getElementById('sideProgressBar');
    if(progressText) progressText.textContent = p + '%';
    if(progressBar) progressBar.style.width = p + '%';
  }
  renderResourceNav();
};

/* Refresh only the navigation layout after applying the scoped overrides. */
render();


/* =========================================================
   SIDEBAR ROADMAP: SCROLL + ALWAYS-AVAILABLE RESOURCE STEPS
   Only the two public resource destinations bypass journey locks.
   All other journey gates and navigation rules remain unchanged.
   ========================================================= */
const __goBeforeOpenResourceSteps = go;
go = function(id){
  if(id === 'mission' || id === 'emigration'){
    openResource(id);
    return;
  }
  return __goBeforeOpenResourceSteps(id);
};

nav = function(){
  const host = document.getElementById('nav');
  if(host){
    host.innerHTML = STEPS.map((s,i)=>{
      const alwaysAvailable = s.id === 'mission' || s.id === 'emigration';
      const canOpen = alwaysAvailable || unlocked(s.id);
      const active = alwaysAvailable ? state.resource === s.id : state.current === s.id;
      const isDone = done(i);
      const click = alwaysAvailable ? `openResource('${s.id}')` : (canOpen ? `go('${s.id}')` : '');
      const className = `nav ${active?'active':''} ${isDone?'done':''} ${!canOpen?'locked':''} ${alwaysAvailable?'resource-unlocked':''}`;
      const trailing = alwaysAvailable
        ? '<span class="nav-open-badge">OPEN</span>'
        : (canOpen ? '' : '<span class="lock">🔒</span>');
      return `<button class="${className}" ${canOpen?`onclick="${click}"`:'aria-disabled="true"'}><span class="step-dot">${isDone?'✓':i+1}</span><span>${s.short}</span>${trailing}</button>`;
    }).join('');
    const p = progress();
    const progressText = document.getElementById('sideProgress');
    const progressBar = document.getElementById('sideProgressBar');
    if(progressText) progressText.textContent = p + '%';
    if(progressBar) progressBar.style.width = p + '%';
  }
  renderResourceNav();
};
render();

/* =========================================================
   MAGNUS PDF-GROUNDED Q&A
   This is a browser-side retrieval assistant grounded in the
   Educaro sponsor problem statement and live prototype state.
   It must say when the PDF does not define a rule or threshold.
   ========================================================= */
const MAGNUS_PDF_QA_KB = [
  {
    id:'objective', title:'Problem statement and objective',
    keywords:['problem statement','objective','purpose','project','what are we building','about this project','challenge','applicant journey','solution overview'],
    answer:'The Educaro problem statement describes a fragmented journey for applicants from India exploring study, vocational training or employment in Germany. The objective is to build an agentic AI prototype that understands the applicant’s background and goals, structures their information, processes supporting documents, assesses relevant requirements, and recommends an appropriate next step.'
  },
  {
    id:'pathways', title:'Applicant pathways',
    keywords:['pathway','study','vocational training','ausbildung','employment','work in germany','job','applicant goal','options'],
    answer:'The PDF names three applicant goals: study, vocational training, and employment in Germany. The system should identify the selected goal and use it to guide profile collection, requirement checks and the next-step recommendation. The PDF does not provide a complete legal checklist for each route.'
  },
  {
    id:'profile', title:'Applicant profile fields',
    keywords:['profile','personal details','profile fields','what information','data model','education fields','employment history','languages','skills','motivation'],
    answer:'The suggested profile includes personal name/contact/location/availability; education institutions, qualifications/degrees, graduation dates and field of study; employers, roles, responsibilities, duration and relevant experience; skills/certifications; language names and proficiency; documents; motivation and goals; introduction-video/transcript information; qualification status; profile completeness; outstanding requirements; and the recommended journey.'
  },
  {
    id:'documents', title:'Supporting documents',
    keywords:['documents','document checklist','files','upload','degree','certificate','experience letter','language certificate','existing cv','resume','evidence','supporting evidence'],
    answer:'The PDF gives examples of supporting documents: degrees, certificates, experience letters, language certificates and existing CVs. The system should extract relevant information from them, distinguish verified from applicant-provided information, identify missing/incomplete/inconsistent details, and request clarification. The PDF does not define one universal mandatory file list for every pathway.'
  },
  {
    id:'video', title:'Introduction video',
    keywords:['video','introduction video','transcript','speak','motivation video','career goals video','background video'],
    answer:'The PDF asks the prototype to capture useful information from a short applicant introduction video, especially the applicant’s background, motivation and career goals. The suggested profile model also includes the video and its transcript.'
  },
  {
    id:'clarification', title:'Missing, incomplete or inconsistent information',
    keywords:['missing information','incomplete','inconsistent','clarification','conflict','mistake','wrong information','fix details'],
    answer:'The PDF says the system should identify missing, incomplete or inconsistent information and request clarification. It should explain what is missing and use that as the next action, rather than silently guessing or proceeding as if the information were complete.'
  },
  {
    id:'qualification', title:'Qualification assessment',
    keywords:['qualification','eligibility','qualified','qualification rules','pass mark','threshold','standard','requirements','assessment','why not eligible'],
    answer:'The PDF requires the applicant to be assessed against predefined qualification or eligibility requirements, with a clear qualification outcome and the relevant missing requirements. It does not set numeric pass marks, a universal score threshold, or detailed legal eligibility rules. Those criteria must be configured from appropriate pathway-specific requirements.'
  },
  {
    id:'next-step', title:'Recommended next step',
    keywords:['next step','recommendation','routing','route','educaro ecosystem','consultant referral','what happens next','journey'],
    answer:'After reviewing the applicant’s structured profile, evidence and qualification result, the system should recommend the most appropriate next step within the Educaro ecosystem. The PDF gives examples such as a suggested Educaro service, consultant referral or a required applicant action.'
  },
  {
    id:'agentic-ai', title:'Agentic AI expectations',
    keywords:['agentic ai','agents','agent','coordinate tasks','reasoning','orchestration','autonomous','why agentic'],
    answer:'The PDF expects meaningful agentic AI, not only a chatbot or isolated features. Agents may reason over applicant information, decide what information is needed next, coordinate tasks, process different inputs, and support qualification and routing. Deterministic software logic is also appropriate where rules are better than AI.'
  },
  {
    id:'data-integrity', title:'Trust and data integrity',
    keywords:['invent information','hallucination','verified','applicant provided','ai generated','data integrity','accuracy','trust','source of truth'],
    answer:'The PDF explicitly says the system should not invent applicant information. It should distinguish verified information, applicant-provided information and AI-generated content where relevant. If evidence is absent or unclear, Magnus should say so and ask for clarification instead of presenting a guess as fact.'
  },
  {
    id:'expected-outcome', title:'Expected outcome',
    keywords:['expected outcome','deliverable','what should the prototype do','end to end','demo result','final output'],
    answer:'The expected outcome is an end-to-end experience: the applicant provides information and supporting inputs, then the system produces a structured applicant profile, relevant extracted/verified information, a qualification outcome, and a logical recommended next step.'
  },
  {
    id:'technology', title:'Core technical requirements',
    keywords:['technology','tech stack','frontend','backend','database','react','typescript','nestjs','postgresql','technical requirements'],
    answer:'The PDF specifies ReactJS + TypeScript for the frontend, NestJS + TypeScript for the backend, and PostgreSQL for the database. It allows additional choices for AI providers, object storage, authentication, vector databases, OCR, speech-to-text, document processing and deployment.'
  },
  {
    id:'courses-internships', title:'Extra courses and internships',
    keywords:['courses','extra courses','internship','internships','projects','certification','hackathon','portfolio','volunteering','awards'],
    answer:'The PDF includes skills/certifications in the suggested profile, and employment roles, responsibilities, duration and relevant experience. It lists certificates and experience letters among possible documents. It does not explicitly make extra courses or internships universal mandatory requirements; in this prototype they are useful supporting evidence and can strengthen the profile/resume, but they must not bypass mandatory qualification gates.'
  },
  {
    id:'language-threshold', title:'Language levels and thresholds',
    keywords:['b1','a1','a2','b2','german level','language level','language threshold','minimum german','english level'],
    answer:'The PDF says the profile should capture German, English and other languages with proficiency levels, and that language certificates are an example of supporting evidence. It does not specify a universal B1/B2 minimum. A required level must come from the configured pathway or programme rule, not be invented by Magnus.'
  },
  {
    id:'visa-mission', title:'Visa and German Mission information',
    keywords:['visa','embassy','german mission','consulate','appointment','visa approval','visa requirement'],
    answer:'The Educaro sponsor PDF does not define visa rules, appointment procedures, or a visa approval decision. This prototype has a separate German Mission & Visa Guidance resource with links to official sources; use that for current official information. Qualification in EduGuide AI is not a visa decision or guarantee.'
  },
  {
    id:'agency-safety', title:'Recruitment agencies and fraud safety',
    keywords:['agency','emigration agency','recruitment agent','scam','fraud','emigrate','eMigrate','recruiting agent'],
    answer:'Recruitment-agency safety is an additional feature in this website, not a requirement defined by the Educaro sponsor PDF. Open the always-available Migration & Agencies section to review the official-source checks and fraud warnings. A “checked” state in this prototype is not a claim that a government authority has endorsed an agency.'
  },
  {
    id:'cv-generation', title:'Professional CV generation',
    keywords:['generate cv','generate resume','professional cv','resume generation','cv generation','verified information in resume'],
    answer:'The PDF asks the system to generate a professional CV from collected and verified information. It also requires the system to distinguish verified facts, applicant-provided details and AI-generated content. The CV should not silently turn an unverified claim into a verified fact.'
  },
  {
    id:'pathway-criteria', title:'Pathway-specific qualification criteria',
    keywords:['study eligibility','study requirements','employment requirements','training requirements','qualification criteria','criteria for study','criteria for employment','criteria for vocational training','what do i need to qualify'],
    answer:'The PDF says applicants should be assessed against predefined qualification or eligibility requirements, but it does not provide the full rule list for Study, Vocational Training or Employment. The prototype therefore needs an explicit, source-backed rule set for the chosen pathway; Magnus must not invent a legal threshold.'
  },
  {
    id:'prototype-limits', title:'Prototype and live integrations',
    keywords:['real time','live ai','does magnus use an llm','chatgpt','api','ocr','speech to text','send real email','real company data','production backend','is this real'],
    answer:'This website is a browser prototype. The Q&A feature answers from a curated set of Educaro-PDF facts and the current applicant state; it is not yet a connected open-domain language model. Real OCR, reliable speech-to-text, live company discovery, outbound email and inbox monitoring require backend services and provider integrations.'
  },
  {
    id:'submission-gates', title:'Submission and routing gates',
    keywords:['send application','submit application','forward profile','company email','company outreach','when can i submit','edu caro forwarding','educaro forwarding'],
    answer:'The sponsor PDF expects the system to recommend the appropriate next step within the Educaro ecosystem, such as a service, consultant referral or applicant action. This prototype adds a gated Educaro-routing workflow, but the PDF itself does not require a specific email-forwarding mechanism or guarantee that an employer will respond.'
  },
  {
    id:'not-specified', title:'Details not specified by the PDF',
    keywords:['not specified','unknown','exact criteria','numeric threshold','mandatory for every pathway'],
    answer:'The PDF defines the expected capabilities and profile categories, but it does not supply detailed pathway-by-pathway legal rules, numeric qualification thresholds, a universal mandatory document list, or visa guarantees. Those items need separate, authoritative, pathway-specific rules and clear source labels.'
  }
];

function magnusQaNormalize(value){
  return String(value||'').toLowerCase().normalize('NFKD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-z0-9+\s]/g,' ').replace(/\s+/g,' ').trim();
}
function magnusQaRetrieve(question){
  const q=magnusQaNormalize(question);
  if(!q) return null;
  const tokens=q.split(' ').filter(t=>t.length>2);
  const stop=new Set(['what','which','when','where','does','this','that','have','with','from','into','about','tell','show','give','can','you','are','the','and','for','how','why','who','our','your','is','it','do','me','please','explain','much','more']);
  const meaningful=tokens.filter(t=>!stop.has(t));
  const expanded=new Set(meaningful);
  const synonymMap={
    resume:['cv','curriculum'],cv:['resume'],job:['employment','occupation','employer'],employment:['job','occupation'],
    training:['vocational','ausbildung'],ausbildung:['training','vocational'],intro:['video','motivation'],video:['transcript','background'],
    documents:['evidence','certificate'],document:['evidence','certificate'],file:['evidence','document'],files:['evidence','documents'],
    language:['proficiency','certificate'],languages:['proficiency'],b1:['language','threshold'],b2:['language','threshold'],
    requirements:['qualification','eligibility'],eligible:['qualification'],criteria:['requirements','qualification'],
    database:['postgresql'],server:['backend','nestjs'],client:['frontend','react'],architecture:['technology','stack'],
    agent:['agentic','coordinate'],agents:['agentic','coordinate'],internship:['experience','evidence'],internships:['experience','evidence'],
    course:['certification','skills'],courses:['certification','skills'],visa:['mission','consular'],embassy:['mission','consular'],
    next:['recommendation','routing'],recommendation:['next','routing'],motivation:['video','goals'],career:['goals','employment']
  };
  for(const token of meaningful){for(const synonym of (synonymMap[token]||[])) expanded.add(synonym);}
  const searchTokens=[...expanded];
  const candidates=MAGNUS_PDF_QA_KB.map(item=>{
    const blob=magnusQaNormalize(item.title+' '+item.keywords.join(' ')+' '+item.answer);
    let score=0;
    for(const key of item.keywords){
      const k=magnusQaNormalize(key);
      if(k && q.includes(k)) score += k.includes(' ')?3.5:1.5;
    }
    for(const token of searchTokens){ if(blob.split(' ').includes(token)) score+=0.38; }
    if(q.includes('pdf') && /problem statement|objective|expected outcome|qualification|technology/.test(item.id)) score+=0.35;
    return {item,score};
  }).sort((a,b)=>b.score-a.score);
  return candidates[0] && candidates[0].score>=0.85 ? candidates[0].item : null;
}
function magnusQaCurrentAnswer(question){
  const q=magnusQaNormalize(question);
  if(/(summari[sz]e.*pdf|overview.*pdf|what is in (?:the )?pdf|what does the pdf cover|whats in (?:the )?pdf)/.test(q)){
    return {text:'The Educaro PDF asks for an integrated agentic AI applicant journey for people in India exploring study, vocational training or employment in Germany. It should build a structured profile, process supporting documents, capture useful details from an introduction video, identify missing or inconsistent information, assess the applicant against predefined requirements, show the qualification outcome and missing requirements, and recommend a next step in the Educaro ecosystem. It also specifies ReactJS + TypeScript, NestJS + TypeScript and PostgreSQL. It does not provide universal numeric pass thresholds or a complete legal checklist for every pathway.',source:'Educaro sponsor problem statement PDF'};
  }
  if(/(how.*(avoid|prevent|stop).*(invent|hallucinat)|inventing information|hallucinat|verified information|applicant provided|ai generated|data integrity)/.test(q)){
    return {text:'The PDF explicitly says not to invent applicant information and to distinguish verified information, applicant-provided information and AI-generated content. When information is missing or unclear, Magnus should ask for clarification and label uncertainty rather than presenting a guess as a fact.',source:'Educaro sponsor problem statement PDF'};
  }
  if(/(does the pdf|does pdf|according to the pdf|pdf specify|pdf require|does the brief).*(\bb1\b|\ba1\b|\ba2\b|\bb2\b|\bc1\b|\bc2\b|numeric|threshold|pass mark|minimum language)/.test(q) || (/\b(b1|a1|a2|b2|c1|c2)\b/.test(q) && /(pdf|brief|threshold|minimum|require|specif)/.test(q))){
    return {text:'The Educaro PDF says the applicant profile should capture German, English and other languages with proficiency levels, and it lists language certificates as an example of supporting evidence. It does not specify B1/B2 or any other universal language minimum or numeric qualification pass mark. Those must come from a separate, authoritative rule for the selected pathway.',source:'Educaro sponsor problem statement PDF'};
  }
  if(/^(hi|hello|hey|namaste|hola|good morning|good evening|good afternoon)$/.test(q)){
    return {text:'Hey! I’m Magnus. You can ask me about the Educaro problem statement, applicant profile, documents, introduction video, qualification, agentic AI, technical requirements, or your current journey. I’ll tell you when the PDF does not specify an answer.',source:'Magnus Help Desk'};
  }
  if(/(what is my current stage|which stage am i|where am i in the journey|current page|current step)/.test(q)){
    return {text:`You are currently on ${roboContextKey()} (${STEPS[currentIndex()]?.title||'Applicant journey'}).`,source:'Your live journey state'};
  }
  if(/(what do you know about me|summari[sz]e my profile|show my profile summary|my applicant profile)/.test(q)){
    const p=state.profile||{};
    const fields=[['Name',p.name],['Email',p.email],['City',p.city],['Goal',state.goal],['Target field',p.field],['Occupation',p.occupation],['Education',p.education],['Availability',p.availability]];
    const known=fields.filter(x=>String(x[1]||'').trim()).map(x=>`${x[0]}: ${x[1]}`).join('; ');
    return {text:known?`Here is the information currently saved in your prototype profile (applicant-provided unless separately verified): ${known}. I will not treat typed profile information as document-verified evidence.`:'Your profile is mostly empty so far. Start with your goal and personal details, then add education, experience, skills and language information.',source:'Your live applicant profile'};
  }
  const profileFieldMatch=q.match(/(?:what is|tell me|show me|do you know) my (name|email|phone|city|goal|pathway|target field|occupation|availability|education|graduation year|experience|experience years)/);
  if(profileFieldMatch){
    const alias=profileFieldMatch[1]; const map={'name':'name','email':'email','phone':'phone','city':'city','goal':'goal','pathway':'goal','target field':'field','occupation':'occupation','availability':'availability','education':'education','graduation year':'graduation','experience':'experienceYears','experience years':'experienceYears'};
    const value=alias==='goal'||alias==='pathway'?state.goal:(state.profile||{})[map[alias]];
    return {text:value?`Your current ${alias} is: ${value}. This is the value saved in your profile; it is not automatically document-verified.`:`You have not filled in your ${alias} yet. Open Profile and add it so the journey can use it.`,source:'Your live applicant profile'};
  }
  if(/(what should i do next|what do i do next|next action|what now|where should i go next|continue my journey)/.test(q)){
    const n=roboNextAction(); return {text:`Your next recommended action is: ${n.label}. ${n.desc}`,source:'Your live journey state'};
  }
  if(/(start|open|launch|begin).*(practice interview|virtual interview)/.test(q)){
    setTimeout(()=>{try{minimizeRoboAssistant();openVirtualInterview()}catch(e){}},140);
    return {text:'Opening Magnus Practice Interview. This is a practice session, not an employer interview or a hiring decision.',source:'Current prototype feature'};
  }
  if(/(can i|may i|am i able to).*(submit|send|forward|apply|proceed)/.test(q) || /(submit|send|forward).*(now|without.*(evidence|documents))/.test(q)){
    const next=roboNextAction();
    if(state.qualification?.status==='QUALIFIED' && state.resumeApproved && state.protection?.consent && state.outreachSent){
      return {text:state.educaroForwarded?'The profile is marked as forwarded by Educaro in this prototype. Real email forwarding requires a configured backend integration.':`Your current next gate is: ${next.label}. ${next.desc} The prototype must not skip the configured approval/protection steps.`,source:'Your live journey state'};
    }
    return {text:`Not yet through the current prototype gates. Your next action is: ${next.label}. ${next.desc} The Educaro PDF also requires missing or inconsistent information to be identified and clarified, not ignored.`,source:'Your live journey state + Educaro PDF'};
  }
  if(/(how do i pass|how can i pass|how do i qualify|how can i qualify|what do i need to qualify)/.test(q)){
    const qual=state.qualification;
    if(qual && (qual.missing||[]).length){return {text:`Your current result is ${qual.status}. First resolve: ${(qual.missing||[]).map(x=>`${x.label||x.key}: ${x.detail||'Review this requirement.'}`).join(' ')} Then run qualification again. The PDF does not prescribe one universal pass score.`,source:'Your live qualification state + Educaro PDF'};}
    return {text:'The PDF says to assess the applicant against predefined, pathway-specific eligibility requirements, then show the outcome and any missing requirements. In this prototype, complete the profile, review the required evidence, analyze the introduction video, and run qualification. The PDF does not define a universal numeric pass mark.',source:'Educaro sponsor problem statement PDF + current prototype'};
  }
  if(/(show me|open|take me to|go to).*(missing files|missing documents|evidence locker)/.test(q)){
    setTimeout(()=>{try{openRoboMissingList()}catch(e){}},140);
    return {text:'Opening the Evidence Locker missing-items view so you can jump to the relevant evidence.',source:'Your live evidence state'};
  }
  if(/(my missing|missing (?:files|documents|evidence)|which (?:files|documents) are missing|what (?:files|documents) am i missing|need to upload|show me.*missing|documents.*still missing|files.*still missing)/.test(q)){
    const items=typeof roboMissing==='function'?roboMissing():[];
    if(items.length) return {text:`I found ${items.length} current core evidence gap${items.length===1?'':'s'}: ${items.map(x=>`${x.label}: ${x.detail}`).join(' ')} Use “Missing files” or tell me “show me the missing files” and I’ll take you to the Evidence Locker.`,source:'Your live evidence state'};
    return {text:'I do not see a currently flagged core evidence gap. You can still open the Evidence Locker to review uploaded files and supporting evidence.',source:'Your live evidence state'};
  }
  if(/(why.*(blocked|not eligible|not qualified|fail|failed)|not eligible|unqualified|qualification status|my qualification|qualified or not|why.*qualif)/.test(q)){
    const qual=state.qualification;
    if(!qual) return {text:'You have not run qualification yet. Complete the required profile and evidence review, analyze your introduction video, and then run the qualification check. The PDF requires a clear outcome and missing requirements, but does not prescribe a universal pass mark.',source:'Your live journey + Educaro PDF'};
    const gaps=(qual.missing||[]).map(x=>`${x.label||x.key}: ${x.detail||'Review this requirement.'}`);
    return {text:`Your latest qualification status is ${qual.status}. ${gaps.length?`Open items: ${gaps.join(' ')}`:'The configured prototype gates currently show no unresolved qualification items.'} This is a prototype pathway assessment, not a visa, admission, or hiring decision.`,source:'Your live qualification state'};
  }
  if(/(improve|increase|raise|boost|low|why.*score).*(readiness|score)|(readiness|score).*(improve|increase|raise|boost)/.test(q)){
    const score=typeof germanyReadinessScore==='function'?germanyReadinessScore():'not available';
    let weak=[]; try{weak=(readinessBreakdown().items||[]).filter(x=>x[2]>0).sort((a,b)=>(a[1]/a[2])-(b[1]/b[2])).slice(0,3).map(x=>`${x[0]} (${x[1]}/${x[2]})`);}catch(e){}
    return {text:`Your current Germany Readiness Score is ${score}/100. The lowest-scoring areas in the current breakdown are: ${weak.length?weak.join('; '):'the profile/evidence review'}. Improve the underlying evidence or profile fields, review documents, and re-run qualification. The score is only a prototype preparation indicator—not legal eligibility or a guarantee.`,source:'Your live readiness breakdown'};
  }
  if(/(readiness|readiness score|how.*score.*calculat|score.*mean)/.test(q)){
    const score=typeof germanyReadinessScore==='function'?germanyReadinessScore():'not available';
    let parts=[];
    try{ parts=(readinessBreakdown().items||[]).map(x=>`${x[0]} ${x[1]}/${x[2]}`).join('; '); }catch(e){}
    return {text:`Your Germany Readiness Score is ${score}/100. ${parts?`Current breakdown: ${parts}. `:''}This is a prototype preparation/completeness indicator, not legal eligibility, admission, visa approval or a hiring decision. The sponsor PDF does not define a numeric pass threshold.`,source:'Your live journey state + Educaro PDF'};
  }
  if(/(profile.*(error|missing|incomplete)|what.*missing.*profile|profile validation)/.test(q)){
    let errs=[]; try{errs=profileValidationErrors();}catch(e){}
    return {text:errs.length?`Your profile still has ${errs.length} validation item${errs.length===1?'':'s'}: ${errs.map(x=>`${x.key}: ${x.error}`).join(' ')} Fix those before qualification.`:'I do not see current profile validation errors. Check that your goal, target field/occupation, education, contact details and availability are accurate. The PDF suggests capturing personal details, education, employment, skills, languages and motivation.',source:'Your live profile state + Educaro PDF'};
  }
  if(/(resume|cv).*(ready|approved|generate|status)/.test(q)){
    return {text:state.resumeApproved?'Your resume is marked approved in this prototype. Check that every factual claim is traceable to verified or applicant-provided evidence before using it externally.':(state.qualification?.status==='QUALIFIED'?'Your configured qualification gates are passed, but resume approval is still pending. Open the Verified Resume step and review it.':'Your resume is not ready to approve yet because qualification must pass first.'),source:'Your live journey state'};
  }
  if(/(interview practice|practice interview|virtual interview)/.test(q)){
    return {text:'Magnus has a 5-question practice interview in this prototype. It is for preparation only; it is not an employer interview and does not decide qualification or hiring.',source:'Current prototype feature'};
  }
  if(/(open|show|go to).*(german mission|mission finder|visa guidance)/.test(q)){
    setTimeout(()=>{try{openResource('mission')}catch(e){}},120);
    return {text:'Opening the German Mission & Visa Guidance section. Note: the sponsor PDF does not define visa requirements; this is a separate prototype resource that should link to official sources.',source:'Current prototype feature + PDF scope note'};
  }
  if(/(open|show|go to).*(agency|agencies|emigration|recruitment safety)/.test(q)){
    setTimeout(()=>{try{openResource('emigration')}catch(e){}},120);
    return {text:'Opening Migration & Agencies. This is an additional safety feature, not a requirement stated in the Educaro problem statement.',source:'Current prototype feature + PDF scope note'};
  }
  if(/^(tell me more|explain more|elaborate|what else about that|go deeper|can you expand|expand on that)$/.test(q)){
    const previous=window.__magnusLastQATopic?MAGNUS_PDF_QA_KB.find(x=>x.id===window.__magnusLastQATopic):null;
    if(previous) return {text:`More on ${previous.title.toLowerCase()}: ${previous.answer} The PDF sets the expected capability, but any detailed rule not explicitly written there should be configured from a reliable, pathway-specific source rather than guessed.`,source:'Educaro sponsor problem statement PDF'};
    if(window.__magnusLastQAResponse) return {text:`To expand on your previous question (“${window.__magnusLastQAQuestion||'your last question'}”): ${window.__magnusLastQAResponse.text} I’ll keep the answer tied to your saved journey state and the requirements that are actually documented.`,source:window.__magnusLastQAResponse.source||'Magnus Help Desk'};
  }
  const match=magnusQaRetrieve(question);
  if(match){
    window.__magnusLastQATopic=match.id;
    return {text:match.answer,source:'Educaro sponsor problem statement PDF'};
  }
  const fallback= 'I checked the Educaro sponsor PDF, but I could not find a supported answer to that exact question. The PDF covers applicant goals, profile fields, documents, introduction video, qualification outcomes, next-step routing, agentic AI, data integrity and the React/NestJS/PostgreSQL stack. It does not provide every legal requirement or numeric threshold, so I will not invent one. Try asking me about one of those topics, or open German Mission & Visa Guidance for official-source links.';
  return {text:fallback,source:'Scope check — Educaro sponsor problem statement PDF'};
}
function magnusAskSuggested(question){
  const input=document.getElementById('roboQuestion');
  if(input) input.value=question;
  openRoboChat();
}
openRoboChat = function openRoboChatPDFQA(){
  const input=document.getElementById('roboQuestion');
  const question=(input?.value||'').trim();
  if(!question){ if(typeof toast==='function')toast('Ask Magnus a question first'); return; }
  const response=magnusQaCurrentAnswer(question);
  window.__magnusLastQAQuestion=question;
  window.__magnusLastQAResponse=response;
  const lastTopicMatch=magnusQaRetrieve(question);
  window.__magnusLastQATopic=lastTopicMatch?lastTopicMatch.id:null;
  const logEl=document.getElementById('roboChatLog');
  if(logEl){
    const safeAnswer=esc(response.text).replace(/\n/g,'<br>');
    logEl.insertAdjacentHTML('beforeend',`<div class="chat-row user"><div class="chat-bubble">${esc(question)}</div></div><div class="chat-row"><div class="chat-bubble">🤖 ${safeAnswer}<div style="margin-top:7px;padding-top:6px;border-top:1px solid rgba(120,130,150,.18);font-size:9px;opacity:.72">Source: ${esc(response.source)}</div></div></div>`);
    logEl.scrollTop=logEl.scrollHeight;
  }
  if(input){input.value='';input.focus();}
  if(typeof magnusSpeak==='function') setTimeout(()=>magnusSpeak(response.text),70);
};
const __magnusOpenHelpDeskBeforePdfQA=openHelpDesk;
openHelpDesk=function(){
  __magnusOpenHelpDeskBeforePdfQA();
  setTimeout(()=>{
    const modal=document.querySelector('.robo-assistant-modal');
    if(!modal)return;
    const input=modal.querySelector('#roboQuestion');
    if(input) input.placeholder='Ask Magnus about your saved profile, files, progress or the Educaro PDF…';
    const composer=modal.querySelector('.robo-chat-compose');
    if(composer && !modal.querySelector('.magnus-qa-suggestions')){
      composer.insertAdjacentHTML('beforebegin',`<div class="magnus-qa-suggestions" style="display:flex;flex-wrap:wrap;gap:6px;margin:10px 0 3px;align-items:center"><span style="font-size:9px;color:#7b8498;font-weight:800;text-transform:uppercase;letter-spacing:.06em;width:100%">Try asking Magnus</span><button type="button" class="robo-voice-btn" onclick="magnusAskSuggested('What is the problem statement?')">Problem statement</button><button type="button" class="robo-voice-btn" onclick="magnusAskSuggested('Which documents are mentioned in the PDF?')">Documents</button><button type="button" class="robo-voice-btn" onclick="magnusAskSuggested('What is agentic AI?')">Agentic AI</button><button type="button" class="robo-voice-btn" onclick="magnusAskSuggested('What technical stack does the PDF require?')">Tech stack</button><button type="button" class="robo-voice-btn" onclick="magnusAskSuggested('Does the PDF specify a B1 or numeric qualification threshold?')">Qualification standards</button><button type="button" class="robo-voice-btn" onclick="magnusAskSuggested('Is my profile completed?')">My profile status</button><button type="button" class="robo-voice-btn" onclick="magnusAskSuggested('What information have I given you about me?')">My saved info</button><button type="button" class="robo-voice-btn" onclick="magnusAskSuggested('What documents have I uploaded?')">My uploaded files</button><button type="button" class="robo-voice-btn" onclick="magnusAskSuggested('What is my next step?')">My next step</button></div>`);
    }
    if(composer && !modal.querySelector('.magnus-qa-scope-note')){
      composer.insertAdjacentHTML('afterend',`<p class="magnus-qa-scope-note" style="font-size:9px;color:#7b8498;margin:7px 0 0">Answers use your saved profile, evidence, video, qualification, journey status and the Educaro problem statement. If a fact is not saved or a rule is not in the PDF, Magnus will say so.</p>`);
    }
  },230);
};


/* =========================================================
   MAGNUS LIVE APPLICANT MEMORY
   Answer applicant-specific questions from the saved state,
   current evidence, video insights, qualification and progress.
   This intentionally remains a browser-side rules assistant;
   it does not pretend to be a connected open-domain LLM.
   ========================================================= */
function magnusLiveClean(v){
  if(v===null||v===undefined)return '';
  if(typeof v==='boolean')return v?'Yes':'No';
  if(Array.isArray(v))return v.map(magnusLiveClean).filter(Boolean).join(', ');
  if(typeof v==='object')return String(v.name||v.label||v.value||'');
  return String(v).trim();
}
function magnusLiveLabel(key){
  return ({name:'Full name',email:'Email',phone:'Phone',city:'City',field:'Target field',occupation:'Target occupation',education:'Highest education',graduation:'Graduation year',experienceYears:'Years of experience',experienceRole:'Current / most recent role',availability:'Availability',languageLevel:'Language level',studyLanguage:'Study language',recognitionReviewed:'Recognition route reviewed',skills:'Skills',languages:'Languages',motivation:'Motivation'})[key]||String(key).replace(/([A-Z])/g,' $1').replace(/^./,m=>m.toUpperCase());
}
function magnusLiveProfileStatus(){
  const p=state.profile||{};
  let errors=[];
  try{errors=typeof profileValidationErrors==='function'?profileValidationErrors():[]}catch(e){}
  const errorMap=new Map(errors.map(e=>[e.key,e.error]));
  const fields=[
    ['goal','Germany pathway',state.goal],['name','Full name',p.name],['email','Email',p.email],['city','City',p.city],
    ['field','Target field',p.field],['occupation','Target occupation',p.occupation],['education','Highest education',p.education],
    ['graduation','Graduation year',p.graduation],['experienceYears','Years of experience',p.experienceYears],['availability','Availability',p.availability]
  ];
  if(state.goal==='Employment') fields.push(['experienceRole','Current / most recent role',p.experienceRole]);
  if(state.goal==='Study') fields.push(['studyLanguage','Study language',p.studyLanguage||'Not sure']);
  const missing=[];
  for(const [key,label,value] of fields){
    if(!magnusLiveClean(value)) missing.push({key,label,reason:errorMap.get(key)||`${label} has not been entered.`});
    else if(errorMap.has(key)) missing.push({key,label,reason:errorMap.get(key)});
  }
  // An invalid optional phone still blocks the form because the validator flags it.
  if(errorMap.has('phone')&&!missing.some(x=>x.key==='phone')) missing.push({key:'phone',label:'Phone',reason:errorMap.get('phone')});
  const completed=missing.length===0 && errors.length===0 && !!state.goal;
  const total=fields.length+(errorMap.has('phone')?1:0);
  const valid=Math.max(0,total-missing.length);
  return {profile:p,errors,missing,completed,valid,total,percent:total?Math.round(valid/total*100):0};
}
function magnusLiveDocStatus(doc){
  const smart=(state.evidence?.smartDocuments||[]).find(x=>x.name===doc.name)||doc;
  if(smart.verified)return 'verified';
  if(smart.reviewed)return 'reviewed — verification still distinct';
  if(smart.analyzed)return 'analysed — awaiting human review';
  return 'uploaded — not yet reviewed';
}
function magnusLiveEvidenceList(){
  const e=state.evidence||{};
  const docs=(e.documents||[]).map(d=>({name:d.name||'Unnamed file',category:d.category||((typeof classifyDocument==='function'&&d.name)?classifyDocument(d.name):'supporting'),status:magnusLiveDocStatus(d)}));
  const extraKeys=[['courses','Extra courses'],['internships','Internships'],['projects','Projects'],['certifications','Certifications'],['awards','Awards / hackathons'],['volunteering','Volunteering / leadership']];
  const extras=extraKeys.flatMap(([key,label])=>(e[key]||[]).map(item=>({group:label,name:item.name||item.title||'Unnamed item',provider:item.provider||'',date:item.date||'',document:item.document||'',status:item.verified?'verified':(item.reviewed?'reviewed':'applicant-provided')})));
  return {docs,extras,reviewed:docs.filter(d=>d.status.startsWith('verified')||d.status.startsWith('reviewed')).length,uploaded:docs.length};
}
function magnusLiveProgress(){
  const ps=magnusLiveProfileStatus();
  const evidenceReviewed=!!(state.protection&&state.protection.evidenceReview);
  return [
    {label:'Profile',done:ps.completed,detail:ps.completed?'Form validation passed':'Some profile details need attention'},
    {label:'Evidence',done:evidenceReviewed,detail:evidenceReviewed?'Core evidence review confirmed':'Evidence review is not complete'},
    {label:'Introduction video',done:!!state.video?.analyzed,detail:state.video?.analyzed?'Video marked analysed':state.video?.uploaded?'Video added but not analysed':'No introduction video analysed'},
    {label:'Qualification',done:state.qualification?.status==='QUALIFIED',detail:state.qualification?`Latest result: ${state.qualification.status}`:'Not run yet'},
    {label:'Resume',done:!!state.resumeApproved,detail:state.resumeApproved?'Resume approved':'Not approved yet'},
    {label:'Educaro routing',done:!!state.educaroForwarded,detail:state.educaroForwarded?'Marked forwarded by Educaro':state.outreachSent?'Sent for Educaro review':'Not sent yet'},
    {label:'Interview',done:!!state.interviewOffer,detail:state.notified?'Interview notification marked sent':state.interviewOffer?'Offer detected':'No interview offer recorded'}
  ];
}
function magnusLiveSnapshot(){
  const ps=magnusLiveProfileStatus(), ev=magnusLiveEvidenceList(), video=state.video||{};
  const q=state.qualification; const score=typeof germanyReadinessScore==='function'?germanyReadinessScore():'not available';
  const next=typeof roboNextAction==='function'?roboNextAction():{label:'Continue your journey',desc:''};
  return `Profile form: ${ps.completed?'complete':'incomplete'} (${ps.percent}% checklist; ${ps.missing.length} item(s) need attention). Documents: ${ev.uploaded} uploaded, ${ev.reviewed} reviewed/verified. Extra evidence: ${ev.extras.length} item(s) (courses ${(state.evidence?.courses||[]).length}, internships ${(state.evidence?.internships||[]).length}, projects ${(state.evidence?.projects||[]).length}, certifications ${(state.evidence?.certifications||[]).length}). Introduction video: ${video.analyzed?'analysed':video.uploaded?'uploaded but not analysed':'not uploaded'}. Qualification: ${q?q.status+' ('+(q.missing||[]).length+' open gate(s))':'not run'}. Germany Readiness: ${score}/100. Next action: ${next.label}${next.desc?' — '+next.desc:''}.`;
}
function magnusLiveStateAnswer(question){
  const q=magnusQaNormalize(question); const p=state.profile||{}; const ps=magnusLiveProfileStatus(); const ev=magnusLiveEvidenceList();
  const sourceProfile='Your saved applicant profile';
  const sourceEvidence='Your saved evidence locker';
  // Exact, state-derived profile-completion answer, distinct from journey completion.
  if(/\b(profile|profile form|my details|personal details)\b.*\b(complete|completed|completion|finish|finished|done|ready|filled|progress|status)\b/.test(q)||/\b(is|has|have|did)\b.*\bmy profile\b.*\b(complete|completed|completion|done|finished|ready|filled|status)\b/.test(q)||/\b(am i|have i)\b.*\b(finished|completed|filled)\b.*\b(profile|my details)\b/.test(q)){
    if(ps.completed) return {text:`Yes — your Profile form is complete. ${ps.valid}/${ps.total} checklist items passed validation. Saved pathway: ${state.goal}. This only confirms the Profile form; it does not mean your evidence, video, qualification, resume or Educaro routing are complete. ${magnusLiveSnapshot()}`,source:sourceProfile+' + current journey'};
    const gaps=ps.missing.slice(0,8).map(x=>`${x.label}: ${x.reason}`).join(' ');
    return {text:`Not yet — your Profile form is ${ps.percent}% complete by the current required-field checklist. I found ${ps.missing.length} item(s) to fix: ${gaps||ps.errors.map(x=>`${magnusLiveLabel(x.key)}: ${x.error}`).join(' ')}. Open Profile, correct those fields, and save again. Profile completion is separate from document verification and qualification.`,source:sourceProfile+' + live validation'};
  }
  // Explain all currently flagged profile/evidence/video/qualification gaps together.
  if(/(what am i missing|what is missing from my (?:application|profile|journey)|what still needs attention|what do i need to fix|what should i fix|any mistakes|any errors in my (?:profile|application|documents)|check my (?:profile|documents|application)|review my (?:profile|documents|application))/.test(q)){
    const issues=[];
    if(!ps.completed) issues.push('Profile: '+ps.missing.slice(0,6).map(x=>`${x.label} — ${x.reason}`).join('; '));
    if(!state.protection?.evidenceReview) issues.push('Evidence: required human review is not complete');
    const core=typeof roboMissing==='function'?roboMissing():[];
    if(core.length) issues.push('Core evidence: '+core.map(x=>`${x.label||x.key} — ${x.detail||'needs review'}`).join('; '));
    if(!state.video?.analyzed) issues.push('Introduction video: '+(state.video?.uploaded?'uploaded but not analysed':'not uploaded or analysed'));
    if(!state.qualification) issues.push('Qualification: not run yet');
    if(state.qualification && state.qualification.status!=='QUALIFIED') issues.push('Qualification: '+(state.qualification.missing||[]).map(x=>`${x.label||x.key} — ${x.detail||'needs review'}`).join('; '));
    if(state.qualification?.status==='QUALIFIED'&&!state.resumeApproved) issues.push('Resume: review and approve the evidence-backed resume');
    return {text:issues.length?`I checked your current saved state. These items still need attention: ${issues.join(' | ')}. Your next recommended action is ${roboNextAction().label}.`:`I do not see a current profile validation error or flagged core evidence gap. ${magnusLiveSnapshot()} Keep in mind that uploaded files still need proper review; a file name alone is not proof that its contents are valid.`,source:'Live profile + evidence + video + qualification state'};
  }

  // Applicant-provided data summary: only values currently stored by the app.
  if(/(what (?:have i|did i) (?:entered|given|told|shared|provided)|what information.*(?:about me|have i|is saved)|what do you know about (?:me|my application|my journey)|what do you remember about me|what is my data|summari[sz]e my (?:profile|details|information|inputs)|show me my (?:profile|details|data|saved information)|my saved data|what have you saved about me|what did i enter (?:earlier|previously)|recap my (?:input|information|profile))/.test(q)){
    const items=[['Name',p.name],['Email',p.email],['Phone',p.phone],['City',p.city],['Pathway',state.goal],['Target field',p.field],['Target occupation',p.occupation],['Education',p.education],['Graduation year',p.graduation],['Experience',p.experienceYears?`${p.experienceYears} year(s)`:'' ],['Most recent role',p.experienceRole],['Availability',p.availability],['Language level',p.languageLevel],['Study language',p.studyLanguage],['Recognition route reviewed',p.recognitionReviewed?'Yes':'']].filter(x=>magnusLiveClean(x[1])).map(x=>`${x[0]}: ${magnusLiveClean(x[1])}`);
    const extra=ev.extras.map(x=>`${x.group}: ${x.name}${x.provider?' ('+x.provider+')':''}${x.document?'; supporting file: '+x.document:''} [${x.status}]`);
    const docs=ev.docs.map(x=>`${x.name} (${x.category}; ${x.status})`);
    const video=state.video?.analyzed?`Video insights: Background — ${state.video.background||'not extracted'}; Motivation — ${state.video.motivation||'not extracted'}; Career goals — ${state.video.careerGoals||'not extracted'}.`:state.video?.uploaded?'An introduction video is uploaded but not analysed yet.':'No introduction video is recorded as uploaded.';
    const joined=[items.length?items.join('; '):'No applicant profile details are saved yet.',docs.length?`Uploaded documents: ${docs.join('; ')}.`:'No document files are currently recorded as uploaded.',extra.length?`Additional evidence: ${extra.join('; ')}.`:'No extra courses, internships, projects, certifications, awards or volunteering items are saved.',video].join(' ');
    return {text:`Here is what I can actually see in your saved browser profile (typed details are applicant-provided, not automatically document-verified). ${joined}`,source:'Saved applicant profile + evidence + video state'};
  }
  // Questions about individual saved fields, including plain phrasing like "my occupation?".
  const fieldPatterns=[
    {re:/\b(name|full name)\b/,key:'name',label:'full name'},{re:/\b(email|email address)\b/,key:'email',label:'email'},
    {re:/\b(phone|phone number|mobile)\b/,key:'phone',label:'phone'},{re:/\b(city|location)\b/,key:'city',label:'city'},
    {re:/\b(target field|field of work|domain)\b/,key:'field',label:'target field'},{re:/\b(occupation|target job|target role)\b/,key:'occupation',label:'target occupation'},
    {re:/\b(pathway|goal|what am i applying for)\b/,key:'goal',label:'pathway'},{re:/\b(education|degree|qualification)\b/,key:'education',label:'education'},
    {re:/\b(graduation year|graduated)\b/,key:'graduation',label:'graduation year'},{re:/\b(experience years|years of experience|work experience)\b/,key:'experienceYears',label:'experience'},
    {re:/\b(most recent role|current role|experience role)\b/,key:'experienceRole',label:'current / most recent role'},
    {re:/\b(availability|available date|when can i start)\b/,key:'availability',label:'availability'},
    {re:/\b(language level|german level|german proficiency)\b/,key:'languageLevel',label:'language level'},
    {re:/\b(study language|language of study)\b/,key:'studyLanguage',label:'study language'}
  ];
  const refersToMyData=/\b(my|mine|i entered|i gave|i selected|i told you|did i enter|have i entered|what is|tell me|do you know|remember)\b/.test(q);
  if(refersToMyData){
    const match=fieldPatterns.find(x=>x.re.test(q));
    if(match){const value=match.key==='goal'?state.goal:p[match.key];return {text:value?`Your saved ${match.label} is ${magnusLiveClean(value)}. I’m reading that from your current profile; it is not automatically document-verified.`:`I don’t have a ${match.label} saved in your current profile yet. Add it in Profile if it is relevant to your pathway.`,source:sourceProfile};}
  }
  // Answer yes/no questions about a specific uploaded document category from saved evidence.
  if(/(did i upload|have i uploaded|have i added|do i have|is .* uploaded|did i attach|have i attached)/.test(q)){
    const typeRules=[['education',/\b(degree|education|diploma|marksheet|transcript)\b/,'education document'],['language',/\b(language|german|english|goethe|telc|ielts|toefl)\b/,'language document'],['internship',/\b(internship|intern)\b/,'internship document'],['experience',/\b(experience|employment|work|job letter)\b/,'experience document'],['cv',/\b(cv|resume|curriculum)\b/,'CV / resume'],['course',/\b(course|training certificate)\b/,'course certificate'],['certification',/\b(certification|certificate)\b/,'certificate']];
    const type=typeRules.find(x=>x[1].test(q));
    if(type){
      const docHits=ev.docs.filter(d=>d.category===type[0]||((d.name||'').toLowerCase().includes(type[0])));
      const extraHits=ev.extras.filter(x=>(x.group+' '+x.name+' '+x.document).toLowerCase().includes(type[0]));
      const has=docHits.length>0||extraHits.length>0;
      return {text:has?`Yes — I can see ${[...docHits.map(d=>`${d.name} (${d.status})`),...extraHits.map(x=>`${x.name}${x.document?' with file '+x.document:''} (${x.status})`)].join('; ')} in your saved evidence state. That means the item is recorded, not necessarily fully verified.`:`No matching ${type[2]} is recorded in your current saved evidence. If you uploaded it under a different filename, tell me the filename or check the Evidence Locker.`,source:sourceEvidence};
    }
  }

  // Evidence list and category-specific extra evidence questions.
  if(/(what.*(documents|files|evidence).*(upload|add|have|saved)|which (documents|files|evidence)|show.*uploaded|what did i upload|how many files|how many documents|list my documents)/.test(q)){
    const all=[...ev.docs.map(x=>`${x.name} — ${x.category}; ${x.status}`),...ev.extras.map(x=>`${x.group}: ${x.name}${x.document?' (supporting file: '+x.document+')':''} — ${x.status}`)];
    return {text:all.length?`I can see ${ev.uploaded} uploaded document file(s) and ${ev.extras.length} additional evidence item(s). ${all.join('. ')}. “Uploaded”, “reviewed” and “verified” are different statuses.`:'I do not currently see any uploaded document files or added extra-evidence entries in the saved state. Add them in the Evidence Locker, then run Smart Document Intelligence and complete human review.',source:sourceEvidence};
  }
  const categoryRules=[['internships',/\b(internship|internships|intern)\b/,'internship evidence'],['courses',/\b(extra courses|courses|course)\b/,'course evidence'],['projects',/\b(projects|portfolio|project)\b/,'project evidence'],['certifications',/\b(certifications|certificates|certification)\b/,'certification evidence'],['awards',/\b(awards|hackathons|award)\b/,'award / hackathon evidence'],['volunteering',/\b(volunteering|leadership|volunteer)\b/,'volunteering / leadership evidence']];
  if(/\b(my|have i|did i|which|what|list|show|how many|added|saved|uploaded)\b/.test(q)){
    const cat=categoryRules.find(([key,re])=>re.test(q));
    if(cat){
      const items=state.evidence?.[cat[0]]||[];
      const docTerms={internships:['internship','experience'],courses:['course','training'],projects:['project','portfolio'],certifications:['certification','certificate'],awards:['award','hackathon'],volunteering:['volunteer','leadership']}[cat[0]]||[];
      const docs=ev.docs.filter(d=>docTerms.some(t=>(`${d.category} ${d.name}`).toLowerCase().includes(t)));
      const itemText=items.map(x=>`${x.name||x.title||'Unnamed item'}${x.provider?' — '+x.provider:''}${x.date?' — '+x.date:''}${x.document?' — supporting file: '+x.document:''} (${x.verified?'verified':x.reviewed?'reviewed':'applicant-provided'})`);
      const docText=docs.map(d=>`${d.name} (${d.status})`);
      const all=[...itemText,...docText];
      return {text:all.length?`I found ${items.length} saved ${cat[2]} record(s) and ${docs.length} related uploaded file(s): ${all.join('; ')}. Being listed means it is recorded; it is not necessarily verified.`:`I do not see any ${cat[2]} entries or matching uploaded files in your saved state yet. You can add them in the Evidence Locker; if you have a certificate or letter, include its filename too.`,source:sourceEvidence};
    }
  }
  // A broad readiness/overall completion question should report stage-by-stage status.
  if(/(is my application (?:ready|finished|done|completed)|am i ready to (?:continue|proceed|apply)|can i move forward|is everything (?:ready|done|finished|complete|completed)|what is the status of my (?:application|journey|process)|where do i stand)/.test(q)){
    const rows=magnusLiveProgress(); const doneCount=rows.filter(x=>x.done).length; const n=roboNextAction();
    return {text:`Here is your current application status: ${doneCount} of ${rows.length} major milestones are complete. ${rows.map(x=>`${x.label}: ${x.done?'complete':x.detail}`).join('; ')}. Your next action is ${n.label} — ${n.desc} ${state.qualification?.status==='QUALIFIED'?'The configured qualification gates currently show QUALIFIED.':'The qualification gate has not passed yet, so I will not describe the whole journey as complete.'}`,source:'Live applicant journey state'};
  }

  // Current journey status, completed work and next action.
  if(/(how far am i|my progress|journey progress|what have i completed|which steps.*done|what is completed|is everything complete|is my application complete|is my journey complete|all steps complete)/.test(q)){
    const rows=magnusLiveProgress(); const total=rows.length; const done=rows.filter(x=>x.done).length;
    return {text:`You have ${done} of ${total} major journey milestones complete. ${rows.map(x=>`${x.label}: ${x.done?'complete':x.detail}`).join('; ')}. ${magnusLiveSnapshot()}`,source:'Live applicant journey state'};
  }
  if(/(what did i say|what did i tell you|what did i ask before|what did i ask earlier|what was my previous question|previous conversation|earlier question|what did we discuss)/.test(q)){
    const turns=Array.isArray(state.magnusConversation)?state.magnusConversation:[];
    if(!turns.length)return {text:'I can read your currently saved profile, uploaded evidence, video, qualification and journey state. I do not have earlier Magnus chat turns saved yet; from now on I will keep a short in-browser conversation history for follow-up questions.',source:'Magnus conversation memory'};
    return {text:`Here are your recent Magnus chat turns: ${turns.slice(-5).map((x,i)=>`${i+1}. You asked: “${x.question}”. Magnus replied: “${x.answer}”`).join(' ')}`,source:'Saved Magnus conversation history'};
  }
  if(/(what about that|what about it|explain that|tell me more|what does that mean|and then what)/.test(q)){
    const turns=Array.isArray(state.magnusConversation)?state.magnusConversation:[]; const last=turns[turns.length-1];
    if(last)return {text:`About your previous question (“${last.question}”): ${last.answer} Current snapshot: ${magnusLiveSnapshot()}`,source:'Previous Magnus answer + current journey state'};
  }
  if(/(video|introduction|transcript|motivation|career goals)/.test(q)&&/(my|did i|have i|what|show|tell|say|analys|upload|uploaded|saved)/.test(q)){
    const v=state.video||{};
    if(!v.uploaded)return {text:'I do not see an introduction video recorded as uploaded yet. Add your short introduction video first; after analysis, the prototype can display background, motivation and career-goal fields.',source:'Your live video state + Educaro PDF'};
    if(!v.analyzed)return {text:'Your introduction video is marked as uploaded but it has not been analysed yet. Open Introduction Video and run analysis. I will not invent a transcript before it is available.',source:'Your live video state'};
    return {text:`Your introduction video is marked as analysed. Background: ${v.background||'not available'}. Motivation: ${v.motivation||'not available'}. Career goals: ${v.careerGoals||'not available'}. Transcript: ${v.transcript||'No transcript text is saved.'} These are the values currently saved by the prototype, not a guarantee of accurate real speech recognition.`,source:'Your live video state'};
  }
  if(/(what is my qualification|what's my qualification|qualification status|did i pass|have i passed|am i qualified|my result|qualification result)/.test(q)){
    const qual=state.qualification;
    if(!qual)return {text:'You have not run the qualification check yet. Complete the profile and required evidence review, analyze the introduction video, and then run qualification.',source:'Your live qualification state'};
    const missing=(qual.missing||[]).map(x=>`${x.label||x.key}: ${x.detail||'Review this item.'}`);
    return {text:`Your latest qualification result is ${qual.status} (prototype rule score ${qual.score??'not stored'}%). ${missing.length?`Outstanding items: ${missing.join('; ')}.`:'No unresolved gate is recorded in the latest result.'} This assessment is only as current as the inputs used at the last check; re-run it after you change your profile or evidence. It is not a visa, admission or hiring decision.`,source:'Your live qualification state'};
  }
  if(/(what is my next step|what should i do next|what do i do next|what now|what do i need to do now|next action)/.test(q)){
    const n=roboNextAction(); return {text:`Your next recommended action is “${n.label}”. ${n.desc} ${state.qualification?.status==='QUALIFIED'?'Qualification is marked passed under the configured prototype rules.':'I will not skip the current gates.'}`,source:'Your live journey state'};
  }
  if(/(what is my resume status|is my resume ready|did i approve.*resume|has my application been sent|did educaro forward|has an interview arrived|do i have an interview)/.test(q)){
    return {text:`Resume approved: ${state.resumeApproved?'yes':'no'}. Applicant outreach sent to Educaro: ${state.outreachSent?'yes':'no'}. Educaro forwarding marked complete: ${state.educaroForwarded?'yes':'no'}. Interview offer recorded: ${state.interviewOffer?'yes':'no'}. Applicant notification marked sent: ${state.notified?'yes':'no'}. These are local prototype status flags; real email/inbox integrations are not confirmed by those flags alone.`,source:'Current routing and interview state'};
  }
  return null;
}
function magnusRememberConversation(question,response){
  try{
    if(!Array.isArray(state.magnusConversation))state.magnusConversation=[];
    state.magnusConversation.push({question:String(question||'').slice(0,240),answer:String(response?.text||'').slice(0,800),source:String(response?.source||'Magnus'),time:new Date().toISOString()});
    state.magnusConversation=state.magnusConversation.slice(-10);
    if(typeof safeSave==='function')safeSave();else if(typeof save==='function')save();
  }catch(e){/* chat memory must never interrupt the assistant */}
}
const __magnusAnswerBeforeLiveMemory = magnusQaCurrentAnswer;
magnusQaCurrentAnswer = function magnusQaCurrentAnswerWithLiveMemory(question){
  let response=null;
  try{response=magnusLiveStateAnswer(question)}catch(e){response=null}
  if(!response){
    response=__magnusAnswerBeforeLiveMemory(question);
    const q=magnusQaNormalize(question);
    const isApplicantContext=/(\bmy\b|\bi\b|profile|applicant|journey|document|evidence|uploaded|saved|entered|course|internship|video|qualification|resume|interview|progress|application|readiness)/.test(q);
    if(response && /Scope check|not find a supported answer/i.test(response.source||'') && isApplicantContext){
      response={text:`I don't have a direct, reliable answer for that exact wording yet, so I won't guess. Here is the current information I can read from your saved applicant state: ${magnusLiveSnapshot()} You can ask me about a profile field, an uploaded file, a course/internship, your video, qualification, readiness or next action.`,source:'Live applicant state; question needs clarification'};
    }
  }
  try{magnusRememberConversation(question,response)}catch(e){}
  return response;
};


/* =========================================================
   MAGNUS HR INTRODUCTION INTERVIEW
   Replaces the video-upload UI for this step with five guided HR questions.
   Captures the same PDF-required themes: background, motivation and career goals.
   ========================================================= */
if (STEPS.some(s => s.id === 'video')) {
  const introStep = STEPS.find(s => s.id === 'video');
  introStep.short = 'HR Interview';
  introStep.title = 'Magnus HR Introduction Interview';
}
state.video = state.video || {};
state.video.hrInterview = state.video.hrInterview || {
  started: false, index: 0, questions: [], answers: ['', '', '', '', ''],
  confidence: [3, 3, 3, 3, 3], completed: false, result: null
};
function introHRState() {
  state.video = state.video || {};
  state.video.hrInterview = state.video.hrInterview || {
    started: false, index: 0, questions: [], answers: ['', '', '', '', ''],
    confidence: [3, 3, 3, 3, 3], completed: false, result: null
  };
  const h = state.video.hrInterview;
  h.answers = Array.isArray(h.answers) ? h.answers : ['', '', '', '', ''];
  h.confidence = Array.isArray(h.confidence) ? h.confidence : [3, 3, 3, 3, 3];
  while (h.answers.length < 5) h.answers.push('');
  while (h.confidence.length < 5) h.confidence.push(3);
  h.index = Math.max(0, Math.min(4, Number(h.index) || 0));

  // Migrate an already-started/saved interview when questions 4 and 5 change.
  // The first three answers remain intact; old answers to replaced questions are cleared.
  const currentQuestions = introHRQuestions();
  if (Array.isArray(h.questions) && h.questions.length === 5 &&
      (h.questions[3] !== currentQuestions[3] || h.questions[4] !== currentQuestions[4])) {
    const wasCompleted = !!h.completed;
    h.questions[3] = currentQuestions[3];
    h.questions[4] = currentQuestions[4];
    h.answers[3] = '';
    h.answers[4] = '';
    h.confidence[3] = 3;
    h.confidence[4] = 3;
    h.index = Math.min(h.index, 3);
    h.completed = false;
    h.result = null;
    if (wasCompleted) {
      state.video.analyzed = false;
      state.video.transcript = '';
      state.video.careerGoals = '';
      state.video.introInterviewScore = null;
      state.video.introInterviewConfidence = null;
      state.qualification = null;
      state.resumeApproved = false;
      state.outreachSent = false;
      state.educaroForwarded = false;
      state.interviewOffer = false;
      state.notified = false;
      state.interviewOfferData = null;
      if (STEPS.findIndex(step => step.id === state.current) > STEPS.findIndex(step => step.id === 'video')) {
        state.current = 'video';
      }
    }
    safeSave();
    log('Magnus HR interview questions updated; replaced answers cleared for questions 4 and 5');
  }
  return h;
}
function introHRQuestions() {
  const goal = state.goal || 'your chosen path';
  const field = state.profile?.field || state.profile?.occupation || 'your chosen field';
  const q2 = goal === 'Study'
    ? 'What interests you about studying in Germany, and what would you like to learn?'
    : goal === 'Vocational Training'
      ? 'What interests you about vocational training in Germany, and what would you like to learn on the job?'
      : goal === 'Employment'
        ? `What interests you about working in Germany in ${field}, and what could you contribute?`
        : 'Why are you interested in studying, vocational training, or working in Germany?';
  return [
    'Hello! Please introduce yourself and tell me briefly about your educational background.',
    q2,
    'Tell me about one course, internship, project, certificate, or work experience you are proud of.',
    'How do you say “What are you doing?” in German?',
    'What is the English translation of “Alles Gute zum Geburtstag”?'
  ];
}
function introHRQuestionSet() {
  const h = introHRState();
  return Array.isArray(h.questions) && h.questions.length === 5 ? h.questions : introHRQuestions();
}
function introHRSpeakCurrentQuestion() {
  const h = introHRState();
  const question = introHRQuestionSet()[h.index];
  if (!question) return;
  setTimeout(() => {
    if (state.current !== 'video' || introHRState().completed) return;
    if (typeof magnusSpeak === 'function') magnusSpeak(question);
    else if ('speechSynthesis' in window) {
      try { window.speechSynthesis.cancel(); const utter = new SpeechSynthesisUtterance(question); utter.lang = 'en-IN'; window.speechSynthesis.speak(utter); } catch (e) {}
    }
  }, 180);
}
function startIntroHRInterview() {
  const h = introHRState();
  if (!h.started && !h.completed) {
    h.questions = introHRQuestions();
    // A legacy uploaded-video result must not count as completing the new interview stage.
    if (state.video.analyzed && !h.completed) {
      state.video.analyzed = false;
      state.video.uploaded = false;
      state.video.transcript = '';
      state.video.background = '';
      state.video.motivation = '';
      state.video.careerGoals = '';
      state.qualification = null;
      state.resumeApproved = false;
      state.outreachSent = false;
      state.educaroForwarded = false;
      state.interviewOffer = false;
      state.notified = false;
      state.interviewOfferData = null;
      log('Legacy video result invalidated for the new Magnus HR interview');
    }
    h.started = true;
  }
  safeSave();
  log('Magnus HR introduction interview opened');
  render();
}
function setIntroHRAnswer(value) {
  const h = introHRState();
  h.answers[h.index] = String(value || '').slice(0, 5000);
  safeSave();
}
function setIntroHRConfidence(value) {
  const h = introHRState();
  const rating = Number(value);
  h.confidence[h.index] = Number.isFinite(rating) ? Math.min(5, Math.max(1, rating)) : 3;
  safeSave();
}
function validateIntroHRCurrentAnswer() {
  const h = introHRState();
  const el = document.getElementById('introHRAnswer');
  const answer = String(el?.value || h.answers[h.index] || '').trim();
  if (answer.length < 10) {
    toast('Please add at least a short sentence before continuing.');
    if (el) { el.focus(); el.classList.add('field-invalid'); }
    if (typeof roboSetAttention === 'function') roboSetAttention('Please add a little detail to this interview answer.', '#introHRAnswer');
    return false;
  }
  if (el) el.classList.remove('field-invalid');
  h.answers[h.index] = answer;
  return true;
}
function previousIntroHRQuestion() {
  const h = introHRState();
  if (h.index <= 0) return;
  const currentAnswer = document.getElementById('introHRAnswer');
  if (currentAnswer) h.answers[h.index] = String(currentAnswer.value || '').slice(0, 5000);
  h.index = Math.max(0, h.index - 1);
  safeSave(); render();
}
function nextIntroHRQuestion() {
  const h = introHRState();
  if (!validateIntroHRCurrentAnswer()) return;
  if (h.index < 4) {
    h.index += 1;
    safeSave(); render();
  } else {
    finishIntroHRInterview();
  }
}
function startIntroHRSpeechAnswer() {
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SpeechRecognition) {
    toast('Voice input is not supported in this browser. You can type your answer instead.');
    return;
  }
  try {
    if (window.__magnusIntroRecognition) window.__magnusIntroRecognition.abort();
    const rec = new SpeechRecognition();
    window.__magnusIntroRecognition = rec;
    rec.lang = 'en-IN';
    rec.interimResults = false;
    rec.continuous = false;
    rec.onstart = () => toast('Listening… answer naturally.');
    rec.onresult = (event) => {
      const said = event.results?.[0]?.[0]?.transcript || '';
      const el = document.getElementById('introHRAnswer');
      if (el && said) {
        el.value = `${el.value.trim()}${el.value.trim() ? ' ' : ''}${said}`;
        setIntroHRAnswer(el.value);
      }
    };
    rec.onerror = (event) => toast(`Voice input unavailable (${event.error || 'permission issue'}). You can type instead.`);
    rec.onend = () => { window.__magnusIntroRecognition = null; };
    rec.start();
  } catch (e) {
    toast('Could not start voice input. Please type your answer instead.');
  }
}
function stopIntroHRSpeechAnswer() {
  try { window.__magnusIntroRecognition?.stop(); } catch (e) {}
}
function scoreIntroHRInterview(answers, ratings) {
  const wordCounts = answers.map(a => String(a || '').trim().split(/\s+/).filter(Boolean).length);
  const detailed = wordCounts.filter(n => n >= 25).length;
  const specific = answers.filter(a => /course|internship|project|certificate|work|team|challenge|result|learn|skill|experience|built|created|improved|responsib|customer|research|achiev/i.test(a)).length;
  const avgConfidence = ratings.reduce((sum, n) => sum + (Number(n) || 3), 0) / 5;
  const selfConfidenceScore = Math.round(((avgConfidence - 1) / 4) * 100);
  const detailScore = Math.round((detailed / 5) * 100);
  const exampleScore = Math.round((specific / 5) * 100);
  const score = Math.round(selfConfidenceScore * 0.5 + detailScore * 0.3 + exampleScore * 0.2);
  const level = score >= 75 ? 'Confident practice signal' : score >= 50 ? 'Developing confidence' : 'More practice recommended';
  const strengths = [];
  const improvements = [];
  if (avgConfidence >= 4) strengths.push('You reported feeling confident across the questions.');
  if (detailed >= 4) strengths.push('Most answers included enough detail to practise clear communication.');
  if (specific >= 3) strengths.push('You referred to concrete skills, experiences, or examples.');
  if (avgConfidence <= 2.8) improvements.push('Try practising aloud in short sessions to build comfort before an actual interview.');
  if (detailed < 4) improvements.push('Expand short answers with one specific example and what you learned from it.');
  if (specific < 3) improvements.push('Include a real course, internship, project, work task, or challenge where relevant.');
  if (!strengths.length && !improvements.length) improvements.push('Keep practising concise, honest answers tied to your real background.');
  return {score, avgConfidence: Math.round(avgConfidence * 10) / 10, detailedAnswers: detailed, exampleAnswers: specific, level, strengths, improvements, wordCounts};
}
function finishIntroHRInterview() {
  const h = introHRState();
  if (!validateIntroHRCurrentAnswer()) return;
  if (h.answers.some(a => String(a || '').trim().length < 10)) {
    const missing = h.answers.findIndex(a => String(a || '').trim().length < 10);
    h.index = Math.max(0, missing);
    safeSave(); render();
    toast(`Please complete question ${missing + 1} before finishing.`);
    return;
  }
  const questions = introHRQuestionSet();
  const answers = h.answers.slice(0, 5).map(a => String(a || '').trim());
  const result = scoreIntroHRInterview(answers, h.confidence.slice(0, 5));
  h.completed = true;
  h.started = true;
  h.completedAt = new Date().toISOString();
  h.result = result;
  state.video.uploaded = false;
  state.video.analyzed = true;
  state.video.transcript = questions.map((q, i) => `Q${i + 1}: ${q}\nApplicant: ${answers[i]}\nSelf-rated confidence: ${h.confidence[i]}/5`).join('\n\n');
  state.video.background = answers[0];
  state.video.motivation = answers[1];
  state.video.careerGoals = answers[4];
  state.video.introInterviewScore = result.score;
  state.video.introInterviewConfidence = result.avgConfidence;
  state.qualification = null;
  state.resumeApproved = false;
  state.outreachSent = false;
  state.educaroForwarded = false;
  state.interviewOffer = false;
  state.notified = false;
  state.interviewOfferData = null;
  log('Magnus HR introduction interview completed');
  safeSave();
  stopIntroHRSpeechAnswer();
  if (typeof magnusSpeak === 'function') magnusSpeak(`Thank you for completing all five questions. Your communication practice indicator is ${result.score} out of 100. This is practice feedback, not a hiring decision.`);
  render();
  toast('Five-question interview completed. Review your feedback, then continue to qualification.');
}
function retakeIntroHRInterview() {
  if (!confirm('Retake the five-question interview? Your current qualification and later routing approvals will be reset because the introduction evidence is changing.')) return;
  state.video.hrInterview = {started: false, index: 0, questions: [], answers: ['', '', '', '', ''], confidence: [3, 3, 3, 3, 3], completed: false, result: null};
  state.video.uploaded = false;
  state.video.analyzed = false;
  state.video.transcript = '';
  state.video.background = '';
  state.video.motivation = '';
  state.video.careerGoals = '';
  state.video.introInterviewScore = null;
  state.video.introInterviewConfidence = null;
  state.qualification = null;
  state.resumeApproved = false;
  state.outreachSent = false;
  state.educaroForwarded = false;
  state.interviewOffer = false;
  state.notified = false;
  state.interviewOfferData = null;
  safeSave(); render();
}
function pageVideoMagnusHR() {
  const h = introHRState();
  const questions = introHRQuestionSet();
  const total = questions.length;
  const answered = h.answers.filter(a => String(a || '').trim().length >= 10).length;
  const app = document.getElementById('app');
  if (!h.started && !h.completed) {
    app.innerHTML = `<div class="section-head"><div><span class="pill">STEP 4 · MAGNUS HR INTRODUCTION INTERVIEW</span><h2 style="margin-top:9px">Meet Magnus, your friendly HR interviewer.</h2><p>No video upload is needed. Magnus will ask five simple questions to capture your background, motivation and career goals.</p></div><span class="pill blue">5 QUESTIONS</span></div>
      <div class="grid2"><div class="card"><div class="assistant-interviewer" style="align-items:center">${roboHTML('large')}<div><span class="pill blue">MAGNUS · HR MODE</span><h3 style="margin:8px 0">A short conversation, at your pace</h3><p class="small">Answer honestly in your own words. You can type or use speech input if your browser supports it. Magnus can read each question aloud.</p><div class="robo-status"><span class="dot"></span>Ready to begin</div></div></div><div class="grid3" style="margin-top:14px"><div class="stat"><b>5</b><span>Simple questions</span></div><div class="stat"><b>5–8 min</b><span>Typical practice time</span></div><div class="stat"><b>Optional</b><span>Speech input</span></div></div><div class="notice" style="margin-top:13px">Your answers become applicant-provided interview notes for the profile. The feedback is a practice indicator based on answer detail and your self-rated confidence; it is not an objective psychological assessment, hiring decision, qualification result, or visa decision.</div><div class="actions"><button class="btn primary" onclick="startIntroHRInterview()">Start 5-question interview →</button></div></div><div class="card"><h3>What Magnus will ask</h3>${questions.map((q,i)=>`<div class="rule"><div class="rule-main"><b>Question ${i+1}</b><span>${esc(q)}</span></div><span class="status pending">HR</span></div>`).join('')}<p class="small" style="margin-top:10px">No answers are invented. Magnus uses only what you enter or dictate.</p></div></div>`;
    return;
  }
  if (h.completed) {
    const r = h.result || scoreIntroHRInterview(h.answers, h.confidence);
    const qa = questions.map((q,i)=>`<div class="rule"><div class="rule-main"><b>Q${i+1}. ${esc(q)}</b><span>${esc(h.answers[i] || '')}</span><small class="muted">Self-rated confidence: ${Number(h.confidence[i] || 3)}/5</small></div></div>`).join('');
    const strengths = (r.strengths || []).map(x=>`<div class="rule"><div class="rule-main"><b>✓ ${esc(x)}</b></div><span class="status verified">Strength</span></div>`).join('');
    const improvements = (r.improvements || []).map(x=>`<div class="rule"><div class="rule-main"><b>Try next</b><span>${esc(x)}</span></div><span class="status pending">Practice</span></div>`).join('');
    app.innerHTML = `<div class="section-head"><div><span class="pill">STEP 4 · INTERVIEW COMPLETED</span><h2 style="margin-top:9px">Your Magnus HR practice summary</h2><p>Your five responses are saved as applicant-provided information. You can review them or retake the practice.</p></div><span class="pill green">5/5 ANSWERED</span></div>
      <div class="grid2"><div><div class="card"><div class="assistant-interviewer">${roboHTML('small')}<div><span class="pill blue">MAGNUS FEEDBACK</span><h3 style="margin:8px 0">${esc(r.level)}</h3><p class="small">Communication practice indicator — not a hiring or eligibility decision.</p></div></div><div class="grid3" style="margin-top:13px"><div class="stat"><b>${r.score}/100</b><span>Practice indicator</span></div><div class="stat"><b>${r.avgConfidence}/5</b><span>Self-rated confidence</span></div><div class="stat"><b>${r.exampleAnswers}/5</b><span>Answers with concrete examples</span></div></div><h3 style="margin-top:16px">What went well</h3>${strengths || '<p class="small">Keep practising and use specific examples from your real background.</p>'}<h3 style="margin-top:16px">Ideas to improve</h3>${improvements}<div class="guard-note">The score is based on response detail, examples and self-reported confidence. The prototype does not reliably measure body language, emotions, or real-world interview performance.</div><div class="actions"><button class="btn secondary" onclick="retakeIntroHRInterview()">Practice again</button><button class="btn primary" onclick="go('qualification')">Continue to Qualification →</button></div></div></div><div class="card"><h3>Applicant-provided interview notes</h3><p class="small">These are your answers, not an AI-generated biography.</p>${qa}<div class="actions"><button class="btn secondary" onclick="downloadText('Magnus_HR_Interview_Notes.txt',state.video.transcript||'')">Export interview notes</button></div></div></div>`;
    return;
  }
  const idx = h.index;
  const q = questions[idx];
  const answer = h.answers[idx] || '';
  const confidence = Number(h.confidence[idx] || 3);
  const barWidth = Math.round(((idx + 1) / total) * 100);
  app.innerHTML = `<div class="section-head"><div><span class="pill">STEP 4 · MAGNUS HR INTRODUCTION INTERVIEW</span><h2 style="margin-top:9px">Question ${idx+1} of ${total}</h2><p>Answer one question at a time. Your progress and answers are saved as you go.</p></div><span class="pill blue">${answered}/5 ANSWERED</span></div>
    <div class="card"><div style="height:7px;background:#eceef4;border-radius:99px;overflow:hidden;margin-bottom:16px"><div style="height:100%;width:${barWidth}%;background:linear-gradient(90deg,#6b58dc,#2bb4c6);border-radius:99px;transition:width .25s"></div></div>
      <div class="assistant-interviewer">${roboHTML('small')}<div><span class="pill blue">MAGNUS · HR INTERVIEWER</span><h3 style="margin:7px 0 4px">Hello${state.profile?.name ? ', '+esc(state.profile.name) : ''}! Let’s talk.</h3><p class="small">I’ll ask five simple questions. There are no trick questions—be honest and use your own experience.</p></div></div>
      <div class="question-box" style="margin-top:14px"><div class="pill" style="background:rgba(255,255,255,.12);color:#fff;margin-bottom:8px">QUESTION ${idx+1} / ${total}</div><h4>${esc(q)}</h4><p>Tip: answer in your own words; a real example is more useful than a perfect-sounding answer.</p><textarea id="introHRAnswer" class="textarea" rows="5" maxlength="5000" placeholder="Type your answer here…" oninput="setIntroHRAnswer(this.value)">${esc(answer)}</textarea></div>
      <div class="grid2" style="margin-top:12px"><div class="card"><label for="introHRConfidence"><b style="font-size:10px">How confident did you feel answering?</b></label><p class="small">Self-rate from 1 (not confident yet) to 5 (very confident).</p><select id="introHRConfidence" class="select" onchange="setIntroHRConfidence(this.value)">${[1,2,3,4,5].map(v=>`<option value="${v}" ${confidence===v?'selected':''}>${v} — ${['','Not confident yet','A little unsure','Okay','Confident','Very confident'][v]}</option>`).join('')}</select></div><div class="card"><b style="font-size:10px">Prefer to speak?</b><p class="small">Use voice input if supported by your browser. Your speech is transcribed into the answer field; raw audio is not saved by this feature.</p><button class="btn secondary" onclick="startIntroHRSpeechAnswer()">🎙 Answer by speaking</button><button class="btn secondary" style="margin-left:6px" onclick="stopIntroHRSpeechAnswer()">Stop listening</button><button class="btn secondary" style="margin-left:6px" onclick="introHRSpeakCurrentQuestion()">🔊 Hear question</button></div></div>
      <div class="actions" style="justify-content:space-between"><button class="btn secondary" onclick="${idx>0?'previousIntroHRQuestion()':"go('evidence')"}">${idx>0?'← Previous question':'Exit to Evidence'}</button><button class="btn primary" onclick="nextIntroHRQuestion()">${idx===total-1?'Finish interview →':'Save & next question →'}</button></div></div>`;
  introHRSpeakCurrentQuestion();
}
pageVideo = pageVideoMagnusHR;

/* The video milestone now means the five-question Magnus interview is complete. */
const __doneBeforeMagnusHRIntro = done;
done = function doneWithMagnusHRIntro(i) {
  if (i === 3) return state.video?.hrInterview?.completed === true;
  return __doneBeforeMagnusHRIntro(i);
};

/* Keep the qualification engine from bypassing the new required introduction stage. */
const __buildQualificationBeforeMagnusHRIntro = buildQualification;
buildQualification = function buildQualificationWithMagnusHRIntro() {
  const rules = __buildQualificationBeforeMagnusHRIntro();
  rules.push({key:'magnusHRInterview',label:'Magnus HR introduction interview',detail:'Complete all five questions and save the applicant-provided background, motivation and career-goal answers.',pass:state.video?.hrInterview?.completed === true});
  return rules;
};

/* Magnus's live assistant should report the new interview, not ask for an uploaded video. */
const __magnusLiveProgressBeforeHRIntro = magnusLiveProgress;
magnusLiveProgress = function magnusProgressWithHRIntro() {
  return __magnusLiveProgressBeforeHRIntro().map(row => row.label === 'Introduction video'
    ? {label:'Magnus HR interview',done:state.video?.hrInterview?.completed===true,detail:state.video?.hrInterview?.completed?'Five questions completed; interview notes saved':state.video?.hrInterview?.started?'Interview in progress':'Five-question introduction interview not started'}
    : row);
};
const __magnusLiveSnapshotBeforeHRIntro = magnusLiveSnapshot;
magnusLiveSnapshot = function magnusSnapshotWithHRIntro() {
  const base = __magnusLiveSnapshotBeforeHRIntro();
  const label = state.video?.hrInterview?.completed ? 'five-question interview completed' : state.video?.hrInterview?.started ? 'five-question interview in progress' : 'five-question interview not completed';
  return base.replace(/Introduction video: [^.]*\./, `Magnus HR introduction interview: ${label}.`);
};
const __magnusLiveStateAnswerBeforeHRIntro = magnusLiveStateAnswer;
magnusLiveStateAnswer = function magnusAnswerWithHRIntro(question) {
  const q = magnusQaNormalize(question);
  if (/(video|introduction|transcript|motivation|career goals|hr interview|intro interview|interview answers)/.test(q)
      && /(my|did i|have i|what|show|tell|say|analys|upload|uploaded|saved|result|confidence|completed|interview|summary)/.test(q)) {
    const h = introHRState();
    if (!h.completed) return {text:`The introduction stage now uses Magnus as an HR interviewer instead of a video upload. Status: ${h.started ? `in progress at question ${h.index+1} of 5` : 'not started yet'}. ${h.started ? `You have ${h.answers.filter(a=>String(a||'').trim().length>=10).length}/5 answers saved.` : 'Start the interview to capture your background, motivation, experience and career goals.'}`,source:'Your live Magnus HR interview state'};
    return {text:`You completed Magnus's five-question HR introduction interview. Background: ${state.video.background||'not provided'}. Motivation: ${state.video.motivation||'not provided'}. Career goals: ${state.video.careerGoals||'not provided'}. Practice indicator: ${state.video.introInterviewScore??'not available'}/100; self-rated confidence: ${state.video.introInterviewConfidence??'not available'}/5. These notes are based on your answers and self-rating; the score is not a hiring, psychological, qualification or visa decision.`,source:'Your saved Magnus HR interview answers'};
  }
  return __magnusLiveStateAnswerBeforeHRIntro(question);
};
