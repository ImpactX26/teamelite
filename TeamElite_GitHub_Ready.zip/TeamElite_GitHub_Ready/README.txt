EduGuide AI — Germany Applicant Journey Prototype

What was fixed in this build
- Fresh browser opens always start at the Start screen; saved applicant data is preserved.
- Profile uses dropdowns for target field, target occupation, and availability.
- Real-time profile validation blocks obviously invalid data (email, phone, graduation year, experience, missing selections, etc.).
- Evidence uploads reject empty/unsupported files and obvious placeholder/test filenames.
- Smart Document Intelligence keeps AI analysis separate from human review; re-analysis preserves review status.
- Evidence review is a separate gate. Qualification cannot pass from typed profile information alone.
- A blocked/needs-evidence qualification cannot unlock Next Step, Resume, Educaro routing, or Interview.
- Magnus is a CSS-built animated robot inspired by the supplied reference image; no static robot image is used in the UI.
- Magnus help desk opens in a popup from the bottom-right and can explain missing files, qualification gaps, readiness, what-if scenarios, protection, and interview practice.
- Virtual Interview works directly from the Start screen and uses the animated Magnus character.

Prototype note
This is still a browser prototype. Real OCR, speech-to-text, live external company data, real outbound email, and inbox monitoring need production backend integrations. Smart Document Intelligence in this build uses demo-level browser signals and requires human review before core evidence is trusted.
