# Contributing / Hackathon Notes

1. Make small, scoped changes and avoid replacing unrelated workflow handlers.
2. After a change, check `node --check app.js`, inspect the diff, and run a browser interaction test for the touched flow plus core regression paths.
3. Never commit `.env`, tokens, applicant documents, or private information.
4. Keep simulated data and fictional agencies explicitly labelled as demos.
5. If adding production integrations, document provider, required secrets, data retention and consent flow; keep secrets server-side.
