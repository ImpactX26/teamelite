# Release Checklist

- [ ] Validate Profile required fields and invalid-value paths.
- [ ] Validate evidence uploads, document review, and missing-file recovery.
- [ ] Validate Introduction HR Interview five questions and final qualification handoff.
- [ ] Validate qualification outcomes and gates for each pathway.
- [ ] Validate qualification-to-Next-Step-to-Resume progression and stale-state invalidation.
- [ ] Validate resume approval → Educaro routing → simulated forwarding → interview notification.
- [ ] Validate Magnus Q&A, voice controls, red/green/white state transitions, and navigation targets.
- [ ] Validate always-available German Mission and Migration & Agencies sections.
- [ ] Verify demo agency names cannot be mistaken for real/verified agencies.
- [ ] Verify official external links.
- [ ] Run JavaScript syntax check and browser E2E tests.
- [ ] Review diff; confirm only requested files changed.
- [ ] Confirm no secrets or private applicant data are included.
