# EduGuide AI — Germany Applicant Journey

EduGuide AI is a hackathon prototype inspired by the Educaro Deutschland GmbH sponsor problem statement. It guides applicants from India who are exploring study, vocational-training, or employment pathways in Germany.

## What it demonstrates

- Guided applicant profile with pathway-specific target fields and validation.
- Evidence Locker for education, language, experience, CV, courses, internships, projects, certifications and other supporting documents.
- Browser-side Smart Document Intelligence demo with explicit review gates.
- Magnus assistant with context-aware help, profile/journey Q&A, browser speech, an included voice sample, and a five-question HR-style introduction interview.
- Qualification framework with explicit blockers and next-step routing.
- Germany Readiness Score as a preparation indicator—not a visa, admission, employment, or legal eligibility decision.
- Evidence-backed resume preview and applicant-approval gates.
- Educaro-first routing and simulated company forwarding/interview flow.
- German Mission in India directory and official-source links.
- Migration/recruitment agency safety guidance with fictional demo entries (`Relovect`, `Nent Latitude`, `Migrate X`) clearly labelled as demo-only.
- What-if career simulator, interview practice, and user-facing fraud-prevention guidance.

## Run locally

This is currently a static browser prototype; no build step is required.

1. Extract/clone the repository.
2. Open `index.html` in a modern browser, or run a local static server from this directory:

   ```bash
   python -m http.server 8000
   ```

3. Open `http://localhost:8000`.

Browser-native speech features may need user interaction/permission and work differently across browsers. If opening via `file://` causes browser restrictions, use the local server.

## Important prototype limitations

This repository is **not a production recruitment, visa, or government portal**. Several integrations are demo-level/browser-side: document analysis is not production OCR; voice playback uses browser capabilities and a packaged sample; company matching/forwarding, actual outbound email, live inbox monitoring, and government application/appointment processes are not performed by this static app. Do not use demo agency names as real endorsements or assume any registration is verified. Official mission and eMigrate links are provided for independent checks.

For real deployment, add a backend and enforce server-side authentication, authorization, secure document storage, encryption, policy checks, audit logs, and a reviewed integration for OCR/speech-to-text/LLM/email. The sponsor PDF lists ReactJS + TypeScript, NestJS + TypeScript, and PostgreSQL as its core technical requirements; the current artifact is a frontend prototype, not that production stack.

## Documentation

- `docs/QUALIFICATION_FRAMEWORK.md` — readiness indicator, pathway gates, evidence hierarchy and safety rules.
- `docs/DEMO_FLOW.txt` — suggested hackathon demo sequence.
- `docs/GERMAN_MISSION_SOURCES.md` — official German Missions references.
- `docs/MISSION_AGENCY_SAFETY_SOURCES.md` — official visa/emigration safety references and demo-only agencies.
- `docs/MAGNUS_*.md` / `docs/MAGNUS_LIVE_FEEDBACK.txt` — Magnus voice and interaction notes.
- `docs/Educaro_Problem_Statement.pdf` — sponsor problem statement supplied for the project.
- `presentation/Educaro_Hackathon_5_Slides.pptx` — five-slide hackathon presentation.

## Privacy and repository hygiene

Do not commit applicant documents, resumes, recordings, `.env` files, API keys, access tokens, or private personal data. The included `.gitignore` excludes common local/private artifacts. The supplied Magnus voice sample is part of the demo asset bundle.
