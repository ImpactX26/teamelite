# Project Overview

## Problem
Applicants from India exploring study, vocational training, or work in Germany often face a fragmented journey across profile building, evidence collection, qualification checks and next-step decisions.

## Proposed journey
Start → Profile → Evidence Locker → Magnus introduction interview → Qualification → Next Step → Verified Resume → Educaro Routing → Interview → German Mission in India.

Migration & Agencies and German Mission guidance are also always available as reference/safety sections. The listed sample agencies are fictional demo entries only.

## Design principles
- Never let extra courses/internships silently replace mandatory qualification evidence.
- Distinguish document-backed, applicant-provided and AI-generated summaries.
- Do not turn a readiness indicator into an official qualification, visa or hiring decision.
- Show a specific recovery action when required evidence is missing.
- Route company-related activity through the Educaro step in this prototype.
- Direct applicants to official government sources for visa and recruitment-agent verification.
