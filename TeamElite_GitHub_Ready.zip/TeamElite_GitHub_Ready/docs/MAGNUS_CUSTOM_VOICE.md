# Magnus custom voice sample

The uploaded user-provided WebM/Opus audio has been packaged as `assets/magnus-voice-sample.webm` and wired to Magnus' voice controls.

Important implementation detail: a prerecorded audio clip cannot synthesize arbitrary new sentences in the browser. The site therefore uses the uploaded sample as Magnus' voice playback/reference and keeps browser-native speech synthesis available for dynamic messages. A true custom-voice TTS/voice-cloning service would be required to make every generated Magnus sentence sound like the supplied speaker.
