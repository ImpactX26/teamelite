# German Mission in India — Sources

The German Mission step uses current public information from the German Federal Foreign Office:

- German Missions in India overview: https://india.diplo.de/in-en/ueber-uns
- German Embassy New Delhi: https://india.diplo.de/in-en/ueber-uns
- German Consulate General Bengaluru: https://india.diplo.de/in-en/ueber-uns/bengaluru
- German Consulate General Chennai: https://india.diplo.de/in-en/ueber-uns/chennai
- German Consulate General Kolkata: https://india.diplo.de/in-en/ueber-uns/kolkata
- German Consulate General Mumbai: https://india.diplo.de/in-en/ueber-uns/mumbai
- Consular Service Portal information: https://india.diplo.de/in-en/service/2755482-2755482
- Appointment information: https://india.diplo.de/in-en/service/2448866-2448866

The website presents this as guidance and links applicants to official sources; it is not an official government portal.
