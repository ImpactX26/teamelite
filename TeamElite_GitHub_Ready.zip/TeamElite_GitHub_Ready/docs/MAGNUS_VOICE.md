# Magnus Voice

Magnus now uses the browser's native Speech Synthesis API. The voice follows the current journey message, important error/correction events, the Help Desk conversation, missing-evidence navigation, and Virtual Interview questions. The robot's face line animates while speaking. No external voice API key is required.
