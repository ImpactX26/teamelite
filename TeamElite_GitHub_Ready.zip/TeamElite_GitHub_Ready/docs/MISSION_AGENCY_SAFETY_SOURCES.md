# German Mission + Migration Agency Safety Sources

The website uses current official sources for safety guidance and external links:

- German Missions in India / National Visa: https://india.diplo.de/in-en/service/2755482-2755482
- German Missions contact information: https://india.diplo.de/in-en/service/2343528-2343528
- German appointment information: https://india.diplo.de/in-en/service/2448866-2448866
- German Missions fraud warning: https://india.diplo.de/in-en/ueber-uns/mumbai/beware-of-fraud-1988568
- VFS and German Missions outsourcing FAQ: https://india.diplo.de/in-en/service/2554096-2554096
- German document verification guidance: https://india.diplo.de/in-en/service/2775256-2775256
- MEA overseas employment safety guidance: https://www.mea.gov.in/emigration-abroad-for-emp.htm
- MEA recruiting-agent complaints: https://www.mea.gov.in/complaints-against-recruiting-agents.htm
- MEA issues for intending emigrants: https://www.mea.gov.in/issues-of-intending-emigrants.htm
- Official eMigrate portal: https://emigrate.gov.in/

The prototype does not certify an agency or issue a visa decision. It guides the applicant to official sources and records applicant-completed checks as applicant-provided information.

## Demo-only agency dropdown values

`Relovect`, `Nent Latitude`, and `Migrate X` are fictional sample names provided only for demonstrating the website UI. They are not presented as real agencies, recommended agencies, registered recruiting agents, or licensed entities. No real registration/RC numbers are assigned to these names. Selecting them shows a demo-only status and the checklist is simulated, not a live official verification. To review a real agency, choose `Other / enter manually` and verify the exact legal name and active registration through the official eMigrate source.
