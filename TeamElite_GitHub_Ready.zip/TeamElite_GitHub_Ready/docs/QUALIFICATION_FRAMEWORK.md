# Qualification Framework

EduGuide AI uses two separate layers:

1. **Germany Readiness Score (0–100)** — a transparent preparation indicator.
2. **Qualification Gates** — the actual prototype decision. Mandatory gates must pass before the applicant can be routed forward.

The readiness score must never be used as a legal visa, admission, employment or hiring decision.

## Common gates
- Goal selected: Study / Vocational Training / Employment
- Education evidence identifiable and readable
- Required language evidence / requirement review
- Core evidence completeness
- Smart document review quality and human review status
- Pathway fit

## Pathway standards used by the prototype

### Study
The prototype checks for a suitable university-entrance qualification and programme-language evidence. Exact admission and language requirements remain programme/university specific. Study/visa routes may also require financial-resource evidence.

### Vocational Training
The prototype checks education evidence, pathway fit, and German-language evidence. For vocational-training visa routes, **B1 CEFR is commonly required** unless an applicable exception or sufficient training-provider language assessment applies. A training place and financial/livelihood evidence are important later in the actual route.

### Employment
The prototype checks role fit, relevant experience and the recognition/comparability route where applicable. Regulated professions generally require recognition/professional authorisation. For non-regulated professions, recognition is not universally mandatory, but comparability/proof may still matter depending on the route.

## Germany Readiness Score
Current prototype weighting:
- Profile completeness — 10
- Core evidence — 20
- Language / requirement review — 15
- Recognition / route review — 15
- Pathway fit — 15
- Smart document review — 10
- Extra evidence — 5
- Introduction video — 5
- Germany practical readiness — 5

Score bands are only UX guidance:
- 80–100: Strongly prepared
- 60–79: Progressing
- Below 60: Early stage

## Evidence hierarchy
1. Verified / document-backed
2. Applicant-provided
3. AI-generated summary
4. Conflict / unresolved — excluded from the verified resume until resolved

## Smart Document Intelligence
The prototype classifies uploaded files, infers likely document type, shows confidence, exposes extracted signals, flags possible duplicates/quality issues, and provides a human-review action. In production this should be backed by OCR/document AI and human verification.

## Extra evidence
Courses, internships, projects, certifications, awards and volunteering strengthen profile fit and resume richness. Each extra item can carry:
- name
- provider / organisation
- date or duration
- supporting document filename
- notes
- verification/review status

Extra evidence never replaces a mandatory qualification gate.

## Why am I not eligible?
The UI exposes each failed gate individually and explains a recovery action instead of hiding the decision behind a single score.

## What-if Career Simulator
The simulator lets an applicant change the pathway and test improvements such as language evidence, recognition review, extra internships/courses, video analysis, or core-document completion without changing the saved profile.

## Multi-layer protection
Before outbound routing, the prototype requires:
1. Identity confirmation
2. Evidence/qualification review
3. Explicit applicant consent
4. Educaro review/forwarding before company monitoring activates

This is a UX/security model only. A production deployment must enforce authentication, authorization, encryption, server-side policy checks and audit logs.

## Virtual Interview
The interview stage includes a five-question practice room, optional camera access, evidence-aware coaching feedback and a practice score. It is explicitly not a hiring decision and is not sent to employers by the prototype.

## Official reference points
- Make it in Germany — Requirements for studying: https://www.make-it-in-germany.com/en/study-vocational-training/studies-in-germany/requirements
- Make it in Germany — Requirements for vocational training: https://www.make-it-in-germany.com/en/study-vocational-training/training-in-germany/requirements-for-vocational-training
- Make it in Germany — Visa for vocational training: https://www.make-it-in-germany.com/en/visa-residence/types/training
- Make it in Germany — Who needs recognition?: https://www.make-it-in-germany.com/en/working-in-germany/recognition/who-needs

These sources are used as current reference points for the prototype rules. Exact legal, admission, employment and visa requirements vary by programme, occupation, nationality and residence route and must be checked with the responsible authority.

The sponsor problem statement does not itself define universal qualification thresholds, so the prototype intentionally avoids a single universal “pass percentage” rule.
